"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BookA, BookOpen, BookOpenCheck, Brain, Home, PenLine, Play, X } from "lucide-react";
import { playSound } from "@/lib/audio";
import type { Mode } from "@/lib/types";

const TABS = [
  { href: "/", label: "Accueil", icon: Home },
  { href: "/grammar", label: "Cours", icon: BookOpenCheck },
  { href: "/dictionary", label: "Dico", icon: BookA },
];

const MODES: {
  mode: Mode;
  name: string;
  tagline: string;
  icon: typeof BookOpen;
  color: string;
  shadow: string;
}[] = [
  { mode: "vocab", name: "Vocabulaire", tagline: "Adapté à ton niveau, ça pique", icon: BookOpen, color: "#8b7cff", shadow: "#5848b8" },
  { mode: "grammar", name: "Grammaire", tagline: "Jusqu'au niveau C2", icon: PenLine, color: "#5cd2ff", shadow: "#1f7fa4" },
  { mode: "match", name: "Memory", tagline: "Mode relax, sans pression", icon: Brain, color: "#ffc24b", shadow: "#92600e" },
  { mode: "comprehension", name: "Lecture", tagline: "Histoires qui montent en niveau", icon: Play, color: "#ff5ca8", shadow: "#a82863" },
];

export default function BottomNav() {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  if (pathname.startsWith("/play") || pathname.startsWith("/grammar/")) return null;

  const start = (mode: Mode) => {
    playSound("tap");
    setOpen(false);
    router.push(`/play/${mode}`);
  };

  return (
    <>
      {/* ---- mode picker sheet ---- */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: "110%" }}
              animate={{ y: 0 }}
              exit={{ y: "110%" }}
              transition={{ type: "spring", damping: 26, stiffness: 300 }}
              className="safe-bottom fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-md px-4"
            >
              <div className="card-night card-pop rounded-t-3xl p-5 pb-6">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="font-display text-xl font-bold">Choisis ta mission</h2>
                  <button
                    onClick={() => setOpen(false)}
                    className="grid size-9 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
                    aria-label="Fermer"
                  >
                    <X className="size-4" />
                  </button>
                </div>
                <div className="grid gap-3">
                  {MODES.map((m, i) => (
                    <motion.button
                      key={m.mode}
                      initial={{ opacity: 0, x: 30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * i }}
                      onClick={() => start(m.mode)}
                      className="btn3d flex items-center gap-4 rounded-2xl p-3 text-left"
                      style={{ backgroundColor: m.color, ["--sh" as string]: m.shadow }}
                    >
                      <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-white/25">
                        <m.icon className="size-6 text-white" strokeWidth={2.4} />
                      </span>
                      <span className="min-w-0">
                        <span className="block font-display text-lg font-bold leading-tight text-white">
                          {m.name}
                        </span>
                        <span className="block text-xs font-semibold text-white/80">{m.tagline}</span>
                      </span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ---- bottom bar ---- */}
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-md px-5">
        <div className="safe-bottom">
          <div className="card-night card-pop relative flex items-center justify-between rounded-3xl px-6 py-2.5">
            {TABS.slice(0, 1).map((t) => (
              <NavItem key={t.href} t={t} active={pathname === t.href} />
            ))}
            <NavItem t={TABS[1]} active={pathname === TABS[1].href} />

            {/* center action */}
            <button
              onClick={() => {
                playSound("tap");
                setOpen(true);
              }}
              aria-label="Jouer"
              className="btn3d relative -mt-9 grid size-16 place-items-center rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon"
              style={{ ["--sh" as string]: "#4c2a85" }}
            >
              <Play className="size-7 text-white" fill="currentColor" />
              <span className="absolute inset-0 -z-10 rounded-2xl bg-violet-neon/60 blur-xl" />
            </button>

            <NavItem t={TABS[2]} active={pathname === TABS[2].href} />
          </div>
        </div>
      </nav>
    </>
  );
}

function NavItem({ t, active }: { t: (typeof TABS)[number]; active: boolean }) {
  return (
    <Link
      href={t.href}
      onClick={() => playSound("tap")}
      className="flex flex-col items-center gap-0.5 px-2 py-1"
    >
      <t.icon
        className={`size-6 transition ${active ? "text-violet-neon" : "text-white/40"}`}
        strokeWidth={active ? 2.6 : 2}
      />
      <span
        className={`text-[10px] font-bold uppercase tracking-wide ${
          active ? "text-violet-neon" : "text-white/40"
        }`}
      >
        {t.label}
      </span>
      {active && (
        <motion.span layoutId="nav-dot" className="absolute mt-11 size-1.5 rounded-full bg-violet-neon" />
      )}
    </Link>
  );
}
