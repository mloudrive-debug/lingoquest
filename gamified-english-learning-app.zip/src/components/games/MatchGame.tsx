"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Feather, X } from "lucide-react";
import type { CefrGrade, SessionSummary } from "@/lib/types";
import { playSound, speak } from "@/lib/audio";
import { smallPop } from "@/lib/confetti";

type Card = { uid: string; itemId: number; side: "en" | "fr"; text: string };

export default function MatchGame({
  pairs,
  grade,
  onExit,
  onDone,
}: {
  pairs: { itemId: number; en: string; fr: string }[];
  grade: CefrGrade;
  onExit: () => void;
  onDone: (s: SessionSummary) => void;
}) {
  const cards = useMemo<Card[]>(() => {
    const list: Card[] = pairs.flatMap((p) => [
      { uid: `${p.itemId}-en`, itemId: p.itemId, side: "en", text: p.en },
      { uid: `${p.itemId}-fr`, itemId: p.itemId, side: "fr", text: p.fr },
    ]);
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
  }, [pairs]);

  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<Set<number>>(new Set());
  const [errors, setErrors] = useState(0);
  const [lock, setLock] = useState(false);
  const submittedRef = useRef(false);

  const submit = useCallback(async () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    playSound("win");
    const res = await fetch("/api/session/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode: "match",
        answers: pairs.map((p) => ({ itemId: p.itemId, correct: true })),
        perfectMatch: errors === 0,
      }),
    });
    if (res.ok) {
      const summary = (await res.json()) as SessionSummary;
      summary.correct = pairs.length;
      summary.total = pairs.length;
      summary.accuracy = errors === 0 ? 100 : Math.max(10, Math.round(100 - errors * 8));
      onDone(summary);
    }
  }, [pairs, errors, onDone]);

  useEffect(() => {
    if (matched.size === pairs.length && pairs.length > 0) {
      const t = setTimeout(() => void submit(), 900);
      return () => clearTimeout(t);
    }
  }, [matched, pairs.length, submit]);

  const flip = (card: Card) => {
    if (lock || flipped.includes(card.uid) || matched.has(card.itemId)) return;
    playSound("flip");
    setFlipped((f) => [...f, card.uid]);

    if (flipped.length === 1) {
      const first = cards.find((c) => c.uid === flipped[0]);
      if (!first) return;
      if (first.itemId === card.itemId && first.side !== card.side) {
        playSound("correct");
        smallPop(0.5, 0.5);
        if (card.side === "en") speak(card.text);
        else speak(first.text);
        setLock(true);
        setTimeout(() => {
          setMatched((m) => new Set(m).add(card.itemId));
          setFlipped([]);
          setLock(false);
        }, 450);
      } else {
        setErrors((e) => e + 1);
        playSound("wrong");
        setLock(true);
        setTimeout(() => {
          setFlipped([]);
          setLock(false);
        }, 800);
      }
    }
  };

  const progress = matched.size / pairs.length;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8">
      <div className="safe-top sticky top-0 z-30 -mx-5 bg-night-950/85 px-5 pb-2 pt-3 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onExit}
            aria-label="Quitter"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
          >
            <X className="size-4.5" />
          </button>
          <div className="track relative h-4 flex-1">
            <motion.div
              className="absolute inset-y-0 left-0 overflow-hidden rounded-full bg-gradient-to-r from-gold to-pink-neon"
              animate={{ width: `${Math.round(progress * 100)}%` }}
              transition={{ type: "spring", stiffness: 140, damping: 22 }}
            >
              <div className="fill-shine absolute inset-0" />
            </motion.div>
          </div>
          <span className="flex shrink-0 items-center gap-1.5 rounded-full bg-gold/15 px-2.5 py-1 text-xs font-extrabold text-gold ring-1 ring-gold/30">
            <Feather className="size-3.5" /> {grade} · relax
          </span>
        </div>
      </div>

      <div className="mt-4 text-center">
        <h2 className="font-display text-xl font-bold">Associe chaque mot à sa traduction</h2>
        <p className="mt-1 text-xs font-bold uppercase tracking-wider text-white/40">
          {matched.size}/{pairs.length} paires · {errors} erreur{errors > 1 ? "s" : ""}
        </p>
      </div>

      <div className="mt-5 grid grid-cols-4 gap-2.5">
        {cards.map((card, i) => {
          const isFlipped = flipped.includes(card.uid) || matched.has(card.itemId);
          const isMatched = matched.has(card.itemId);
          return (
            <motion.button
              key={card.uid}
              initial={{ opacity: 0, scale: 0.4, rotate: -6 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ delay: 0.05 * i, type: "spring", stiffness: 280, damping: 20 }}
              onClick={() => flip(card)}
              className="flip-scene aspect-[3/4] select-none"
              aria-label={isFlipped ? card.text : "Carte cachée"}
            >
              <div className={`flip-inner relative size-full ${isFlipped ? "flipped" : ""}`}>
                {/* front (hidden) */}
                <div
                  className={`flip-face absolute inset-0 grid place-items-center rounded-2xl ${
                    isMatched
                      ? "bg-lime-neon/25 ring-2 ring-lime-neon"
                      : "bg-gradient-to-br from-night-700 to-night-800 ring-1 ring-white/12"
                  }`}
                  style={{ boxShadow: "0 4px 0 rgb(0 0 0 / 0.35)" }}
                >
                  {isMatched ? (
                    <span className="size-2.5 rounded-full bg-lime-neon" />
                  ) : (
                    <span className="font-display text-2xl font-bold text-violet-neon/60">?</span>
                  )}
                </div>
                {/* back (revealed) */}
                <div
                  className={`flip-face flip-back absolute inset-0 grid place-items-center rounded-2xl p-1.5 ${
                    card.side === "en"
                      ? "bg-gradient-to-br from-violet-neon to-violet-deep text-white"
                      : "bg-gradient-to-br from-pink-neon to-rose text-white"
                  }`}
                  style={{ boxShadow: "0 4px 0 rgb(0 0 0 / 0.35)" }}
                >
                  <span className="text-center font-display text-[13px] font-bold leading-tight">
                    {card.text}
                  </span>
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
