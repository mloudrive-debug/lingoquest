"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Award, BookMarked, BookOpen, Brain, Crown, Flame, GraduationCap, Home, Languages, Library, PenLine, Rocket, RotateCcw, Sparkles, Star, Target, Trophy, Zap } from "lucide-react";
import type { SessionSummary } from "@/lib/types";
import { levelUpStorm, winBurst } from "@/lib/confetti";
import { playSound } from "@/lib/audio";

const BADGE_ICONS: Record<string, typeof Star> = {
  Rocket, Target, Flame, Zap, BookOpen, Library, PenLine, BookMarked, Brain, Trophy,
  GraduationCap, Crown,
};

function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      setValue(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

export default function ResultScreen({
  summary,
  modeLabel,
  onReplay,
  onHome,
}: {
  summary: SessionSummary;
  modeLabel: string;
  onReplay: () => void;
  onHome: () => void;
}) {
  const xp = useCountUp(summary.xpGained);
  const stars = summary.total === 0 ? 1 : summary.accuracy >= 100 ? 3 : summary.accuracy >= 60 ? 2 : 1;

  useEffect(() => {
    playSound(summary.levelUp || summary.gradeUp ? "levelup" : "win");
    const t1 = setTimeout(() => winBurst(), 250);
    const t2 = summary.levelUp || summary.gradeUp ? setTimeout(() => levelUpStorm(), 500) : undefined;
    return () => {
      clearTimeout(t1);
      if (t2) clearTimeout(t2);
    };
  }, [summary.levelUp, summary.gradeUp]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex min-h-[70dvh] flex-col items-center justify-center px-6 py-8 text-center"
    >
      {/* stars */}
      <div className="mb-4 flex items-end gap-2">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            initial={{ scale: 0, rotate: -30 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.25 + i * 0.18, type: "spring", stiffness: 300, damping: 12 }}
            className={i === 1 ? "-translate-y-3" : ""}
          >
            <Star
              className={`${i === 1 ? "size-14" : "size-10"} ${
                i < stars ? "text-gold text-glow-gold" : "text-white/15"
              }`}
              fill="currentColor"
            />
          </motion.span>
        ))}
      </div>

      <h1 className="font-display text-3xl font-bold">
        {summary.accuracy >= 100 ? "Parfait !" : summary.accuracy >= 60 ? "Bravo !" : "Bien joué !"}
      </h1>
      <p className="mt-1 text-sm font-semibold text-white/60">
        {modeLabel} terminé · {summary.correct}/{summary.total} correctes
      </p>

      {/* XP card */}
      <motion.div
        initial={{ y: 24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="card-night card-pop mt-6 w-full max-w-xs rounded-3xl p-5"
      >
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="size-5 text-violet-neon" />
          <span className="font-display text-4xl font-bold tabular-nums text-violet-neon text-glow-violet">
            +{xp}
          </span>
          <span className="font-display text-xl font-bold text-white/40">XP</span>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
            <div className="flex items-center justify-center gap-1.5">
              <Flame className="size-4 text-gold" fill="currentColor" />
              <span className="font-display text-xl font-bold tabular-nums">{summary.streak}</span>
            </div>
            <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-white/50">
              jours d&apos;affilée
            </p>
          </div>
          <div className="rounded-2xl bg-white/5 p-3 ring-1 ring-white/10">
            <span className="font-display text-xl font-bold tabular-nums text-lime-neon text-glow-lime">
              {summary.accuracy}%
            </span>
            <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-white/50">précision</p>
          </div>
        </div>

        {summary.gradeUp && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.8, type: "spring", stiffness: 260, damping: 14 }}
            className="mt-4 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-lime-neon to-cyan-neon p-3"
          >
            <Languages className="size-5 text-night-950" strokeWidth={2.6} />
            <span className="font-display text-lg font-bold text-night-950">
              Niveau {summary.cefrGrade} débloqué !
            </span>
          </motion.div>
        )}
        {summary.levelUp && !summary.gradeUp && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.8, type: "spring", stiffness: 260, damping: 14 }}
            className="mt-4 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-gold to-pink-neon p-3"
          >
            <Trophy className="size-5 text-white" fill="currentColor" />
            <span className="font-display text-lg font-bold text-white">
              Niveau {summary.level} atteint !
            </span>
          </motion.div>
        )}

        {/* CEFR mini-progress */}
        <div className="mt-4">
          <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-white/45">
            <span>{summary.cefrGrade}</span>
            <span>{Math.round(summary.cefrProgress * 100)}%</span>
          </div>
          <div className="track h-2">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-cyan-neon to-violet-neon"
              initial={{ width: 0 }}
              animate={{ width: `${summary.cefrProgress * 100}%` }}
              transition={{ duration: 0.9, ease: "easeOut", delay: 0.6 }}
            />
          </div>
        </div>
      </motion.div>

      {/* badges */}
      {summary.newBadges.length > 0 && (
        <div className="mt-5 flex w-full max-w-xs flex-col gap-2">
          {summary.newBadges.map((b, i) => {
            const Icon = BADGE_ICONS[b.icon] ?? Star;
            return (
              <motion.div
                key={b.key}
                initial={{ x: -40, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.9 + i * 0.2 }}
                className="flex items-center gap-3 rounded-2xl bg-white/5 p-3 ring-1 ring-white/15"
              >
                <span
                  className="grid size-11 shrink-0 place-items-center rounded-xl"
                  style={{ backgroundColor: b.color + "33" }}
                >
                  <Icon className="size-5" style={{ color: b.color }} fill="currentColor" />
                </span>
                <span className="text-left">
                  <span className="flex items-center gap-1.5 text-sm font-extrabold">
                    <Award className="size-3.5 text-gold" /> Badge débloqué : {b.name}
                  </span>
                  <span className="text-xs font-semibold text-white/50">{b.description}</span>
                </span>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* actions */}
      <div className="mt-7 grid w-full max-w-xs grid-cols-2 gap-3">
        <button
          onClick={() => {
            playSound("tap");
            onHome();
          }}
          className="btn3d flex items-center justify-center gap-2 rounded-2xl bg-white/10 px-4 py-3.5 font-display font-bold ring-1 ring-white/15"
          style={{ ["--sh" as string]: "rgb(255 255 255 / 0.08)" }}
        >
          <Home className="size-4" /> Accueil
        </button>
        <button
          onClick={() => {
            playSound("tap");
            onReplay();
          }}
          className="btn3d flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon px-4 py-3.5 font-display font-bold"
          style={{ ["--sh" as string]: "#4c2a85" }}
        >
          <RotateCcw className="size-4" /> Rejouer
        </button>
      </div>
    </motion.div>
  );
}
