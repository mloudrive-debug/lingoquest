"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  BookMarked,
  Check,
  ChevronRight,
  Flame,
  Lightbulb,
  Volume2,
  X,
} from "lucide-react";
import type { CefrGrade, McqQuestion, SessionSummary } from "@/lib/types";
import { playSound, speak } from "@/lib/audio";
import { smallPop } from "@/lib/confetti";

type Payload = {
  mode: "vocab" | "grammar" | "comprehension";
  total: number;
  grade: CefrGrade;
  questions: McqQuestion[];
  text?: { id: number; title: string; content: string; cefr: string };
};

export default function SessionGame({
  payload,
  modeLabel,
  onExit,
  onDone,
}: {
  payload: Payload;
  modeLabel: string;
  onExit: () => void;
  onDone: (s: SessionSummary) => void;
}) {
  const { mode, questions } = payload;
  const total = questions.length;

  const [stage, setStage] = useState<"reading" | "playing">(
    mode === "comprehension" ? "reading" : "playing",
  );
  const [showText, setShowText] = useState(false);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [combo, setCombo] = useState(0);
  const [xpFloat, setXpFloat] = useState(0);
  const answersRef = useRef<{ itemId: number; correct: boolean }[]>([]);
  const submittedRef = useRef(false);

  const q = questions[index];
  const answered = selected !== null;
  const isCorrect = answered && selected === q?.answerIndex;
  const progress = useMemo(
    () => (index + (answered ? 1 : 0)) / total,
    [index, answered, total],
  );

  const submit = useCallback(async () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    const res = await fetch("/api/session/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode,
        answers: answersRef.current,
        textId: payload.text?.id,
      }),
    });
    if (res.ok) {
      const summary = (await res.json()) as SessionSummary;
      onDone(summary);
    }
  }, [mode, payload.text?.id, onDone]);

  const pick = (i: number) => {
    if (answered || !q) return;
    setSelected(i);
    const good = i === q.answerIndex;
    answersRef.current.push({ itemId: q.itemId, correct: good });
    if (good) {
      playSound("correct");
      setCombo((c) => c + 1);
      setXpFloat((x) => x + 1);
      smallPop(0.5, 0.55);
    } else {
      playSound("wrong");
      setCombo(0);
    }
  };

  const next = () => {
    playSound("tap");
    if (index + 1 >= total) void submit();
    else {
      setIndex((i) => i + 1);
      setSelected(null);
    }
  };

  // Auto-pronounce English prompt for vocab en2fr
  useEffect(() => {
    if (
      stage === "playing" &&
      mode === "vocab" &&
      q?.subtype === "translate" &&
      q.direction === "en2fr" &&
      !answered
    ) {
      const t = setTimeout(() => speak(q.prompt), 350);
      return () => clearTimeout(t);
    }
  }, [stage, mode, q, answered, index]);

  if (stage === "reading" && payload.text) {
    return (
      <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8">
        <GameHeader progress={0} combo={combo} grade={payload.grade} onExit={onExit} xpFloat={xpFloat} />
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-night card-pop mt-6 flex-1 rounded-3xl p-6"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full bg-pink-neon/15 px-3 py-1 text-xs font-bold text-pink-neon ring-1 ring-pink-neon/30">
            <BookMarked className="size-3.5" /> Histoire · niveau {payload.text.cefr}
          </span>
          <h2 className="mt-3 font-display text-2xl font-bold">{payload.text.title}</h2>
          <p className="mt-4 text-[17px] leading-8 text-white/85">{payload.text.content}</p>
          <button
            onClick={() => speak(payload.text!.content)}
            className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-white/70 ring-1 ring-white/15 active:scale-95"
          >
            <Volume2 className="size-4" /> Écouter l&apos;histoire
          </button>
        </motion.div>
        <button
          onClick={() => {
            playSound("tap");
            setStage("playing");
          }}
          className="btn3d mt-5 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon py-4 font-display text-lg font-bold"
          style={{ ["--sh" as string]: "#4c2a85" }}
        >
          J&apos;ai fini de lire <ChevronRight className="size-5" />
        </button>
      </div>
    );
  }

  if (!q) return null;

  const isClozeLike = q.prompt.includes("___");

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8">
      <GameHeader
        progress={progress}
        combo={combo}
        grade={payload.grade}
        onExit={onExit}
        xpFloat={xpFloat}
        onReRead={mode === "comprehension" && payload.text ? () => setShowText(true) : undefined}
      />

      {/* re-read sheet */}
      <AnimatePresence>
        {showText && payload.text && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm"
              onClick={() => setShowText(false)}
            />
            <motion.div
              initial={{ y: "110%" }}
              animate={{ y: 0 }}
              exit={{ y: "110%" }}
              transition={{ type: "spring", damping: 26, stiffness: 300 }}
              className="safe-bottom fixed inset-x-0 bottom-0 z-50 mx-auto max-h-[75dvh] w-full max-w-md overflow-y-auto px-4"
            >
              <div className="card-night card-pop rounded-t-3xl p-6">
                <h3 className="font-display text-xl font-bold">{payload.text.title}</h3>
                <p className="mt-3 text-base leading-7 text-white/85">{payload.text.content}</p>
                <button
                  onClick={() => {
                    playSound("tap");
                    setShowText(false);
                  }}
                  className="btn3d mt-5 w-full rounded-2xl bg-white/10 py-3.5 font-display font-bold ring-1 ring-white/15"
                  style={{ ["--sh" as string]: "rgb(255 255 255 / 0.08)" }}
                >
                  Retour aux questions
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* question */}
      <div className="mt-2 flex flex-1 flex-col">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -60 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`card-night card-pop mt-4 rounded-3xl p-6 ${answered && !isCorrect ? "animate-shake" : ""}`}
          >
            {q.subPrompt && (
              <span className="inline-block rounded-full bg-white/8 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white/60 ring-1 ring-white/10">
                {q.subPrompt}
                {q.subtype === "translate" && q.direction === "en2fr" && " · traduis en français"}
                {q.subtype === "translate" && q.direction === "fr2en" && " · traduis en anglais"}
                {q.subtype === "cloze" && " · complète en anglais"}
                {q.subtype === "grammar" && " · complète la phrase"}
              </span>
            )}

            <div className="mt-4 flex items-start justify-between gap-3">
              <p className="font-display text-[24px] font-bold leading-snug">
                {isClozeLike ? <Blanked text={q.prompt} answered={answered} /> : q.prompt}
              </p>
              {mode === "vocab" && (q.direction === "en2fr" || answered || q.subtype === "cloze") && (
                <button
                  aria-label="Écouter"
                  onClick={() =>
                    speak(
                      answered && q.exampleEn
                        ? q.exampleEn
                        : q.direction === "en2fr"
                          ? q.prompt
                          : (q.answerWord ?? q.prompt),
                    )
                  }
                  className="grid size-11 shrink-0 place-items-center rounded-xl bg-violet-neon/15 ring-1 ring-violet-neon/40 transition active:scale-90"
                >
                  <Volume2 className="size-5 text-violet-neon" />
                </button>
              )}
            </div>

            {/* hint under cloze (French translation of the sentence) */}
            {q.subtype === "cloze" && q.hint && (
              <p className="mt-3 text-sm font-semibold italic text-white/45">« {q.hint} »</p>
            )}

            {/* feedback info */}
            <AnimatePresence>
              {answered && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="overflow-hidden"
                >
                  {mode === "vocab" && q.exampleEn ? (
                    <div className="mt-4 rounded-2xl bg-white/5 p-4 ring-1 ring-white/10">
                      <p className="text-sm font-bold text-white/90">« {q.exampleEn} »</p>
                      <p className="mt-1 text-xs font-semibold text-white/50">{q.exampleFr}</p>
                    </div>
                  ) : null}
                  {mode === "grammar" && q.explanation ? (
                    <div className="mt-4 flex gap-2.5 rounded-2xl bg-gold/10 p-4 ring-1 ring-gold/25">
                      <Lightbulb className="mt-0.5 size-4 shrink-0 text-gold" />
                      <p className="text-sm font-semibold leading-relaxed text-gold/90">{q.explanation}</p>
                    </div>
                  ) : null}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>

        {/* options */}
        <div className="mt-5 grid gap-3">
          {q.options.map((opt, i) => {
            const isRight = answered && i === q.answerIndex;
            const isPickedWrong = answered && i === selected && !isCorrect;
            return (
              <motion.button
                key={`${index}-${i}`}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.06 * i }}
                disabled={answered}
                onClick={() => pick(i)}
                className={`btn3d flex items-center justify-between gap-3 rounded-2xl px-5 py-4 text-left font-display text-lg font-bold ${
                  isRight
                    ? "bg-lime-neon text-night-950"
                    : isPickedWrong
                      ? "bg-rose text-white"
                      : "bg-night-700 text-white ring-1 ring-white/10"
                }`}
                style={{
                  ["--sh" as string]: isRight ? "#3f6212" : isPickedWrong ? "#8f2f44" : "#0d0a1d",
                }}
              >
                <span className="flex items-center gap-3">
                  <span
                    className={`grid size-8 shrink-0 place-items-center rounded-lg text-sm font-extrabold ${
                      isRight
                        ? "bg-night-950/15 text-night-950"
                        : isPickedWrong
                          ? "bg-white/20"
                          : "bg-white/8 text-white/60"
                    }`}
                  >
                    {String.fromCharCode(65 + i)}
                  </span>
                  {opt}
                </span>
                {isRight && <Check className="size-5 shrink-0" strokeWidth={3} />}
                {isPickedWrong && <X className="size-5 shrink-0" strokeWidth={3} />}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* continue */}
      <AnimatePresence>
        {answered && (
          <motion.button
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            onClick={next}
            className={`btn3d mt-6 flex items-center justify-center gap-2 rounded-2xl py-4 font-display text-lg font-bold ${
              isCorrect ? "bg-lime-neon text-night-950" : "bg-gradient-to-br from-violet-neon to-pink-neon text-white"
            }`}
            style={{ ["--sh" as string]: isCorrect ? "#3f6212" : "#4c2a85" }}
          >
            {index + 1 >= total ? "Voir le résultat" : "Continuer"} <ChevronRight className="size-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}

function Blanked({ text, answered }: { text: string; answered: boolean }) {
  const parts = text.split("___");
  return (
    <span>
      {parts[0]}
      <span
        className={`mx-1 inline-block min-w-14 rounded-lg border-b-4 px-2 text-center align-baseline ${
          answered ? "border-lime-neon/60 bg-lime-neon/15 text-lime-neon" : "border-violet-neon/50 bg-violet-neon/10 text-violet-neon/60"
        }`}
      >
        {answered ? "" : "??"}
      </span>
      {parts[1]}
    </span>
  );
}

export function GameHeader({
  progress,
  combo,
  grade,
  onExit,
  xpFloat,
  onReRead,
}: {
  progress: number;
  combo: number;
  grade: CefrGrade;
  onExit: () => void;
  xpFloat: number;
  onReRead?: () => void;
}) {
  return (
    <div className="safe-top sticky top-0 z-30 -mx-5 bg-night-950/85 px-5 pb-2 pt-3 backdrop-blur-md">
      <div className="flex items-center gap-3">
        <button
          onClick={onExit}
          aria-label="Quitter"
          className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
        >
          <X className="size-4.5" />
        </button>

        <div className="track relative h-4 flex-1">
          <motion.div
            className="absolute inset-y-0 left-0 overflow-hidden rounded-full bg-gradient-to-r from-violet-neon to-pink-neon"
            animate={{ width: `${Math.min(100, Math.round(progress * 100))}%` }}
            transition={{ type: "spring", stiffness: 140, damping: 22 }}
          >
            <div className="fill-shine absolute inset-0" />
          </motion.div>
        </div>

        <AnimatePresence>
          {combo >= 3 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="flex shrink-0 items-center gap-1 rounded-full bg-gold/15 px-2.5 py-1 text-xs font-extrabold text-gold ring-1 ring-gold/30"
            >
              <Flame className="size-3.5 animate-flame" fill="currentColor" /> x{combo}
            </motion.span>
          )}
        </AnimatePresence>

        {onReRead && (
          <button
            onClick={onReRead}
            aria-label="Relire l'histoire"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
          >
            <BookMarked className="size-4.5 text-pink-neon" />
          </button>
        )}

        <span className="shrink-0 rounded-full bg-gradient-to-r from-violet-neon/25 to-pink-neon/25 px-2.5 py-1 text-xs font-extrabold text-violet-neon ring-1 ring-violet-neon/40">
          {grade}
        </span>
      </div>

      {/* floating XP */}
      <AnimatePresence>
        {xpFloat > 0 && (
          <motion.span
            key={xpFloat}
            initial={{ opacity: 0, y: 0, scale: 0.6 }}
            animate={{ opacity: 1, y: 34, scale: 1.1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 font-display text-2xl font-bold text-lime-neon text-glow-lime"
          >
            +10
          </motion.span>
        )}
      </AnimatePresence>
    </div>
  );
}
