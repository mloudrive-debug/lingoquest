"use client";

import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Flame, Languages, Sparkles, Volume2, VolumeX } from "lucide-react";
import { useProfile } from "@/lib/hooks";
import { isMuted, playSound, setMuted } from "@/lib/audio";

export default function TopBar() {
  const pathname = usePathname();
  const { profile } = useProfile();
  const [muted, setMutedState] = useState(false);

  useEffect(() => {
    setMutedState(isMuted());
    const onChange = () => setMutedState(isMuted());
    window.addEventListener("lq-mute-changed", onChange);
    return () => window.removeEventListener("lq-mute-changed", onChange);
  }, []);

  if (pathname.startsWith("/play")) return null;

  return (
    <header className="safe-top sticky top-0 z-30 mx-auto flex w-full max-w-md items-center justify-between px-4 py-3 backdrop-blur-md">
      <div className="flex items-center gap-2">
        <div className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-violet-neon to-pink-neon shadow-[0_4px_14px_rgba(139,124,255,0.45)]">
          <Sparkles className="size-5 text-white" strokeWidth={2.5} />
        </div>
        <span className="font-display text-xl font-bold tracking-tight">
          Lingo<span className="text-violet-neon">Quest</span>
        </span>
      </div>

      <div className="flex items-center gap-2">
        <button
          aria-label="Activer / couper le son"
          onClick={() => {
            const next = !muted;
            setMuted(next);
            if (!next) playSound("tap");
          }}
          className="grid size-9 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
        >
          {muted ? (
            <VolumeX className="size-4 text-white/50" />
          ) : (
            <Volume2 className="size-4 text-white/80" />
          )}
        </button>

        <div className="flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 ring-1 ring-white/10">
          <motion.span
            key={`streak-${profile?.streak ?? 0}`}
            initial={{ scale: 1.5 }}
            animate={{ scale: 1 }}
            className="grid place-items-center"
          >
            <Flame className="size-4 animate-flame text-gold" fill="currentColor" />
          </motion.span>
          <span className="text-sm font-extrabold tabular-nums">{profile?.streak ?? 0}</span>
        </div>

        <motion.div
          key={profile?.cefr.grade ?? "A1"}
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-violet-neon/25 to-pink-neon/25 px-3 py-1.5 ring-1 ring-violet-neon/40"
          title="Ton niveau d'anglais (CECRL)"
        >
          <Languages className="size-4 text-violet-neon" />
          <span className="text-sm font-extrabold tabular-nums text-violet-neon text-glow-violet">
            {profile?.cefr.grade ?? "A1"}
          </span>
        </motion.div>
      </div>
    </header>
  );
}
