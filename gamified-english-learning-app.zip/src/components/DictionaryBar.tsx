"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, BookA, Target } from "lucide-react";
import { playSound } from "@/lib/audio";

export type DictionaryStats = {
  total: number;
  known: number;
  coverage: number;
  bands: { band: number; label: string; total: number; known: number; coverage: number }[];
  milestones: { count: number; label: string; desc: string; reached: boolean }[];
  nextMilestone: { count: number; label: string; desc: string };
  milestoneProgress: number;
  lastMilestone: { count: number; label: string; desc: string } | null;
};

export function useDictionary() {
  const [stats, setStats] = useState<DictionaryStats | null>(null);
  useEffect(() => {
    let alive = true;
    fetch("/api/dictionary", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => alive && setStats(d))
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  return stats;
}

export default function DictionaryBar({ stats }: { stats: DictionaryStats | null }) {
  const known = stats?.known ?? 0;
  const total = stats?.total ?? 370063;
  const next = stats?.nextMilestone;
  const pct = stats ? stats.milestoneProgress * 100 : 0;

  return (
    <Link
      href="/dictionary"
      onClick={() => playSound("tap")}
      className="card-night card-pop group relative mt-4 block overflow-hidden rounded-[2rem] p-5"
    >
      <div className="pointer-events-none absolute -right-14 -top-14 size-44 rounded-full bg-gold/15 blur-3xl" />

      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold">
          <BookA className="size-5 text-gold" /> Le dictionnaire
        </h2>
        <ArrowRight className="size-5 text-white/40 transition group-hover:translate-x-1 group-hover:text-gold" />
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <motion.span
          key={known}
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="font-display text-4xl font-bold tabular-nums text-gold text-glow-gold"
        >
          {known.toLocaleString("fr-FR")}
        </motion.span>
        <span className="font-display text-lg font-bold text-white/35">
          / {total.toLocaleString("fr-FR")} mots
        </span>
      </div>
      <p className="mt-0.5 text-xs font-semibold text-white/50">
        {stats ? `${(stats.coverage * 100).toFixed(2)} % du dictionnaire anglais` : "Chargement…"}
      </p>

      {/* milestone progress */}
      <div className="mt-4">
        <div className="mb-1.5 flex items-center justify-between text-[11px] font-bold">
          <span className="flex items-center gap-1.5 text-white/55">
            <Target className="size-3.5 text-lime-neon" />
            {stats?.lastMilestone ? stats.lastMilestone.label : "Premiers mots"}
          </span>
          <span className="text-white/55">
            {next ? `${next.label} · ${next.count.toLocaleString("fr-FR")}` : ""}
          </span>
        </div>
        <div className="track h-3">
          <motion.div
            className="relative h-full rounded-full bg-gradient-to-r from-gold via-pink-neon to-violet-neon"
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 1.2, ease: "easeOut", delay: 0.2 }}
          >
            <div className="fill-shine absolute inset-0 rounded-full" />
          </motion.div>
        </div>
        {next && (
          <p className="mt-1.5 text-[11px] font-semibold text-white/45">
            Encore{" "}
            <span className="font-extrabold text-gold">
              {Math.max(0, next.count - known).toLocaleString("fr-FR")}
            </span>{" "}
            mots pour « {next.desc} »
          </p>
        )}
      </div>
    </Link>
  );
}
