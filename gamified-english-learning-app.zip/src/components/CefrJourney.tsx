"use client";

import { motion } from "framer-motion";
import { Check, Languages } from "lucide-react";
import type { CefrData } from "@/lib/types";

const GRADES = ["A1", "A2", "B1", "B2", "C1", "C2"] as const;

const GRADE_LABELS: Record<string, string> = {
  A1: "Débutant",
  A2: "Élémentaire",
  B1: "Autonome",
  B2: "Indépendant",
  C1: "Avancé",
  C2: "Presque natif",
};

export default function CefrJourney({ cefr }: { cefr: CefrData }) {
  const overallPct = Math.min(100, cefr.overallProgress * 100);

  return (
    <section className="card-night card-pop relative mt-4 overflow-hidden rounded-[2rem] p-5">
      <div className="pointer-events-none absolute -right-12 -top-12 size-40 rounded-full bg-cyan-neon/15 blur-3xl" />

      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold">
          <Languages className="size-5 text-cyan-neon" /> Ton parcours d&apos;anglais
        </h2>
        <span className="text-[10px] font-bold uppercase tracking-wider text-white/40">CECRL</span>
      </div>

      {/* current grade spotlight */}
      <div className="mt-4 flex items-center gap-4">
        <div className="relative grid size-20 shrink-0 place-items-center">
          <motion.span
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 12, ease: "linear" }}
            className="absolute inset-0 rounded-3xl bg-[conic-gradient(from_0deg,#8b7cff,#ff5ca8,#5cd2ff,#8b7cff)] p-[3px]"
            style={{ mask: "none", opacity: 0.9 }}
          />
          <span className="absolute inset-[3px] rounded-[1.3rem] bg-night-900" />
          <span className="relative font-display text-3xl font-bold text-transparent">
            <motion.span
              key={cefr.grade}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-gradient-to-br from-violet-neon to-pink-neon bg-clip-text text-glow-violet"
            >
              {cefr.grade}
            </motion.span>
          </span>
        </div>
        <div className="min-w-0">
          <p className="font-display text-xl font-bold leading-tight">
            {GRADE_LABELS[cefr.grade]}
          </p>
          <p className="text-xs font-semibold text-white/55">
            {cefr.isMax
              ? "Niveau maximum atteint. Respect absolu."
              : cefr.nextGrade
                ? `Encore ${cefr.xpToNextGrade} XP pour passer ${cefr.nextGrade}`
                : ""}
          </p>
          <p className="mt-1 text-[11px] font-bold text-cyan-neon/90">
            La difficulté s&apos;adapte automatiquement à ce niveau
          </p>
        </div>
      </div>

      {/* journey bar with nodes */}
      <div className="mt-6 px-1">
        <div className="relative">
          <div className="track h-3 w-full">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-violet-neon via-pink-neon to-gold"
              initial={{ width: 0 }}
              animate={{ width: `${overallPct}%` }}
              transition={{ duration: 1.4, ease: [0.34, 1.2, 0.5, 1], delay: 0.2 }}
            />
          </div>
          {/* pulsing position marker */}
          <motion.span
            className="absolute -top-1 size-5 -translate-x-1/2"
            initial={{ left: "0%" }}
            animate={{ left: `${overallPct}%` }}
            transition={{ duration: 1.4, ease: [0.34, 1.2, 0.5, 1], delay: 0.2 }}
          >
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-gold/50" />
            <span className="absolute inset-1 rounded-full bg-gold ring-2 ring-night-950" />
          </motion.span>
          {/* nodes */}
          {GRADES.map((g, i) => {
            const pos = (i / (GRADES.length - 1)) * 100;
            const passed = overallPct >= pos - 0.01 && pos > 0;
            const isCurrent = cefr.grade === g;
            return (
              <div key={g} className="absolute top-0 -translate-x-1/2" style={{ left: `${pos}%` }}>
                <div
                  className={`mx-auto mt-5 grid size-7 place-items-center rounded-full border-2 font-display text-[11px] font-bold transition ${
                    passed || isCurrent
                      ? "border-gold bg-gold/20 text-gold"
                      : "border-white/15 bg-night-800 text-white/40"
                  } ${isCurrent ? "scale-110 shadow-[0_0_16px_rgba(255,194,75,0.4)]" : ""}`}
                >
                  {passed && !isCurrent ? <Check className="size-3.5" strokeWidth={3.5} /> : g.slice(0, 1)}
                </div>
                <p
                  className={`mt-1 text-center font-display text-[10px] font-bold ${
                    isCurrent ? "text-gold" : passed ? "text-white/70" : "text-white/35"
                  }`}
                >
                  {g}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* real mastery per grade */}
      <div className="mb-1 mt-[4.6rem]">
        <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-white/40">
          Maîtrise réelle du vocabulaire
        </p>
        <div className="grid grid-cols-3 gap-2">
          {GRADES.map((g) => {
            const m = Math.round((cefr.masteryByGrade[g] ?? 0) * 100);
            const active = GRADES.indexOf(g) <= cefr.gradeIndex + 1;
            return (
              <div
                key={g}
                className={`rounded-xl p-2 ring-1 ${
                  active ? "bg-white/5 ring-white/10" : "bg-white/[0.02] ring-white/5"
                }`}
              >
                <div className="flex items-baseline justify-between">
                  <span className={`font-display text-xs font-bold ${active ? "text-white/80" : "text-white/30"}`}>
                    {g}
                  </span>
                  <span className={`text-[10px] font-extrabold tabular-nums ${m > 50 ? "text-lime-neon" : active ? "text-white/50" : "text-white/25"}`}>
                    {m}%
                  </span>
                </div>
                <div className="track mt-1.5 h-1.5">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-neon to-lime-neon transition-all duration-700"
                    style={{ width: `${m}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
