import { NextRequest, NextResponse } from "next/server";

/**
 * Optional personal lock: when APP_PASSWORD is set (production deploy),
 * every page/API requires one unlock. In this sandbox the variable is
 * unset, so the app stays open.
 */

export const config = {
  matcher: ["/((?!_next|icons|sw.js|manifest.webmanifest|favicon.ico).*)"],
};

async function hash(input: string): Promise<string> {
  const data = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode("lq-lock:" + input),
  );
  return Array.from(new Uint8Array(data))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export default async function middleware(req: NextRequest) {
  const pwd = process.env.APP_PASSWORD;
  if (!pwd) return NextResponse.next();

  const { pathname } = req.nextUrl;
  const open =
    pathname === "/unlock" ||
    pathname.startsWith("/api/unlock") ||
    pathname.startsWith("/api/health");
  if (open) return NextResponse.next();

  const cookie = req.cookies.get("lq-auth")?.value;
  if (cookie && cookie === (await hash(pwd))) return NextResponse.next();

  if (pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "locked" }, { status: 401 });
  }
  return NextResponse.redirect(new URL("/unlock", req.url));
}
