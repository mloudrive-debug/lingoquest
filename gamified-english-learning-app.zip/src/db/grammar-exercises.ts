/**
 * Banque d'exercices de grammaire, chacun rattaché à une leçon du cours.
 * Tuple: [lessonSlug, cefr, difficulté, phrase (avec ___), options (bonne réponse EN PREMIER), explication]
 * Les options sont mélangées au moment de servir la question.
 */
export type ExerciseRow = [string, string, number, string, string[], string];

export const EXERCISES: ExerciseRow[] = [
  // ---------- simple-present ----------
  ["simple-present", "A1", 1, "She ___ to work by bus every day.", ["goes", "go", "going", "went"], "He/she/it prennent un -s : she goes."],
  ["simple-present", "A1", 1, "They ___ football on Saturdays.", ["play", "plays", "playing", "played"], "Avec « they », le verbe garde sa base."],
  ["simple-present", "A1", 1, "___ she like pizza?", ["Does", "Do", "Is", "Has"], "Avec he/she/it : Does + base verbale."],
  ["simple-present", "A2", 1, "He ___ coffee in the morning.", ["doesn't drink", "doesn't drinks", "don't drink", "not drink"], "Après « doesn't », le verbe perd son -s."],
  ["simple-present", "A2", 1, "My sister ___ English at university.", ["studies", "studys", "study", "studing"], "Consonne + y → -ies : studies."],
  ["simple-present", "A2", 1, "He is ___ late for class.", ["always", "always be", "be always", "the always"], "Les adverbes de fréquence suivent le verbe « be »."],

  // ---------- present-continuous ----------
  ["present-continuous", "A1", 1, "Look! It ___ raining outside.", ["is", "are", "am", "be"], "be + verbe-ing : It is raining."],
  ["present-continuous", "A1", 1, "We ___ dinner right now.", ["are cooking", "cook", "cooks", "cooked"], "« Right now » = action en cours."],
  ["present-continuous", "A2", 1, "I ___ the answer to that question.", ["know", "am knowing", "knowing", "knows"], "« Know » est un verbe d'état : pas de -ing."],
  ["present-continuous", "A2", 1, "She ___ with her parents this month.", ["is staying", "stays", "stay", "stayed"], "Situation temporaire → présent continu."],
  ["present-continuous", "A2", 2, "They ___ Paul tomorrow evening.", ["are meeting", "meet", "are meet", "will meeting"], "Rendez-vous prévu → présent continu à valeur de futur."],

  // ---------- present-perfect ----------
  ["present-perfect", "B1", 2, "I have lived in Lyon ___ 2015.", ["since", "for", "from", "during"], "SINCE + point de départ. FOR + durée."],
  ["present-perfect", "B1", 2, "She has ___ finished her project.", ["already", "yet", "since", "ago"], "« Already » se place entre have et le participe."],
  ["present-perfect", "B1", 2, "I ___ my keys. I can't find them anywhere!", ["have lost", "lost", "was losing", "lose"], "Résultat visible maintenant → present perfect."],
  ["present-perfect", "B1", 2, "We ___ that restaurant two years ago.", ["tried", "have tried", "try", "are trying"], "« Ago » = moment passé précis → prétérit."],
  ["present-perfect", "B1", 2, "He has ___ to Japan three times.", ["been", "gone", "went", "being"], "« Has been » = y est allé et revenu."],
  ["present-perfect", "B1", 2, "I ___ here for ten years.", ["have worked", "work", "am working", "worked"], "Le français « je travaille ici depuis » devient un present perfect."],

  // ---------- present-perfect-continuous ----------
  ["present-perfect-continuous", "B2", 2, "I ___ for the bus for an hour!", ["have been waiting", "am waiting", "wait", "waited"], "Durée qui continue → have been + -ing."],
  ["present-perfect-continuous", "B2", 2, "Your hands are dirty! What ___ ?", ["have you been doing", "do you do", "have you done", "are you did"], "L'activité explique l'état présent."],
  ["present-perfect-continuous", "B2", 3, "I ___ her since high school.", ["have known", "have been knowing", "am knowing", "know"], "« Know » est un state verb : pas de forme continue."],

  // ---------- simple-past ----------
  ["simple-past", "A2", 1, "Yesterday, we ___ a great movie.", ["saw", "see", "seen", "seeing"], "Passé irrégulier de « see » = saw."],
  ["simple-past", "A2", 1, "I ___ to Paris last year.", ["went", "go", "goes", "gone"], "Passé irrégulier de « go » = went."],
  ["simple-past", "A2", 1, "She ___ her homework after school.", ["did", "do", "does", "done"], "Passé de « do » = did."],
  ["simple-past", "A2", 1, "I ___ him at the party.", ["didn't see", "didn't saw", "not saw", "didn't seen"], "Après « didn't », base verbale."],
  ["simple-past", "A2", 2, "He ___ a new car last month.", ["bought", "buyed", "buys", "has bought"], "« Buy » est irrégulier : bought."],
  ["simple-past", "A2", 1, "___ you enjoy the concert?", ["Did", "Do", "Have", "Was"], "Question au prétérit : Did + sujet + base."],

  // ---------- past-continuous ----------
  ["past-continuous", "B1", 2, "I ___ when she arrived.", ["was reading", "read", "have read", "am reading"], "Action en cours interrompue → was/were + -ing."],
  ["past-continuous", "B1", 2, "While I was cooking, the phone ___.", ["rang", "was ringing", "has rung", "ring"], "Le fond est au continu, l'événement court au prétérit."],
  ["past-continuous", "B1", 2, "They ___ TV at ten o'clock last night.", ["were watching", "was watching", "watched", "are watching"], "« They » → were + -ing."],

  // ---------- past-perfect ----------
  ["past-perfect", "B2", 2, "When I arrived, she ___ already left.", ["had", "has", "was", "did"], "Antériorité dans le passé → had + participe."],
  ["past-perfect", "B2", 2, "I ___ never seen snow before that winter.", ["had", "have", "did", "was"], "Expérience antérieure à un moment passé."],
  ["past-perfect", "B2", 3, "He told me he ___ the film the week before.", ["had seen", "has seen", "saw", "was seeing"], "Discours rapporté au passé → past perfect."],

  // ---------- used-to ----------
  ["used-to", "B1", 2, "I ___ smoke, but I quit five years ago.", ["used to", "use to", "am used to", "was used"], "Habitude passée révolue : used to + base."],
  ["used-to", "B1", 2, "I'm used to ___ up early now.", ["getting", "get", "got", "gets"], "« Be used to » + -ing = être habitué à."],
  ["used-to", "B1", 2, "Did you ___ live in Spain?", ["use to", "used to", "using to", "uses to"], "Après « did », on écrit « use to » sans -d."],

  // ---------- future-will-going-to ----------
  ["future-will-going-to", "A2", 1, "Tomorrow, I ___ my grandmother.", ["will visit", "visit", "visited", "visits"], "Décision / prévision : will + base."],
  ["future-will-going-to", "A2", 2, "Look at those clouds! It ___ rain.", ["is going to", "will to", "goes to", "is go"], "Indice visible → be going to."],
  ["future-will-going-to", "A2", 1, "I promise I ___ careful.", ["will be", "will being", "am will", "be will"], "Après will, base verbale."],
  ["future-will-going-to", "B1", 2, "I'll call you when I ___.", ["arrive", "will arrive", "am arriving", "arrived"], "Pas de « will » après « when » temporel."],
  ["future-will-going-to", "B1", 2, "If it ___ tomorrow, we'll stay home.", ["rains", "will rain", "rained", "is raining"], "Pas de « will » dans la proposition en « if »."],
  ["future-will-going-to", "B1", 2, "She ___ medicine next year — it's decided.", ["is going to study", "will study", "studies", "is studying to"], "Intention déjà décidée → be going to."],

  // ---------- future-perfect-continuous ----------
  ["future-perfect-continuous", "C1", 3, "This time tomorrow, we ___ on the beach.", ["will be lying", "will lie", "lie", "are lie"], "Action en cours dans le futur : will be + -ing."],
  ["future-perfect-continuous", "C1", 3, "By June, I ___ the course.", ["will have finished", "will finish", "finish", "have finished"], "« By + date » → futur antérieur."],
  ["future-perfect-continuous", "C1", 3, "By 2030 she ___ for twenty years.", ["will have been teaching", "will teach", "teaches", "will be teach"], "Durée accumulée jusqu'à un repère futur."],

  // ---------- conditionals-0-1 ----------
  ["conditionals-0-1", "B1", 2, "If you heat ice, it ___.", ["melts", "would melt", "melted", "will melting"], "Vérité générale : if + présent, présent."],
  ["conditionals-0-1", "B1", 2, "If he is late, I ___ angry.", ["will be", "am", "would be", "was"], "Conditionnel 1 : if + présent, will + base."],
  ["conditionals-0-1", "B1", 2, "You can't enter ___ you have a ticket.", ["unless", "if", "without", "except"], "« Unless » = sauf si / à moins que."],

  // ---------- conditionals-2-3-mixed ----------
  ["conditionals-2-3-mixed", "B2", 2, "If I ___ rich, I'd travel the world.", ["were", "am", "will be", "would be"], "Conditionnel 2 : if + prétérit (were à toutes les personnes)."],
  ["conditionals-2-3-mixed", "B2", 2, "If she had studied, she ___ the exam.", ["would have passed", "would pass", "will have passed", "passed"], "Conditionnel 3 : would have + participe."],
  ["conditionals-2-3-mixed", "B2", 3, "If I ___ more time, I would learn the piano.", ["had", "would have", "have", "will have"], "Jamais « would » après « if »."],
  ["conditionals-2-3-mixed", "C1", 3, "If I hadn't missed the train, I ___ there now.", ["would be", "would have been", "will be", "am"], "Mixte : cause passée, conséquence présente."],
  ["conditionals-2-3-mixed", "C2", 3, "___ I known, I would have helped.", ["Had", "Did", "Would", "Should"], "Inversion soutenue : Had I known = If I had known."],

  // ---------- wish-if-only ----------
  ["wish-if-only", "B2", 2, "I wish I ___ play the piano.", ["could", "can", "will", "would"], "Regret présent : le temps recule d'un cran."],
  ["wish-if-only", "B2", 2, "I wish I ___ harder for the exam.", ["had studied", "studied", "have studied", "would study"], "Regret sur le passé → wish + past perfect."],
  ["wish-if-only", "B2", 3, "I wish you ___ shouting!", ["would stop", "stopped", "will stop", "had stopped"], "Agacement envers quelqu'un : wish + would."],

  // ---------- modals-basics ----------
  ["modals-basics", "A2", 1, "She ___ swim very well.", ["can", "cans", "can to", "is can"], "Un modal ne prend ni -s ni « to »."],
  ["modals-basics", "B1", 2, "You ___ wear a seatbelt. It's the law.", ["must", "mustn't", "don't have to", "couldn't"], "Obligation forte : must + base."],
  ["modals-basics", "B1", 2, "It's free — you ___ pay.", ["don't have to", "mustn't", "must not", "shouldn't have to"], "Pas d'obligation ≠ interdiction."],
  ["modals-basics", "B1", 2, "You ___ smoke in the hospital. It's forbidden.", ["mustn't", "don't have to", "needn't", "wouldn't"], "Interdiction : mustn't."],
  ["modals-basics", "B1", 2, "Yesterday I ___ work late.", ["had to", "must", "must to", "musted"], "« Must » n'a pas de passé : had to."],

  // ---------- modals-deduction ----------
  ["modals-deduction", "C1", 3, "He ___ tired — he worked all night.", ["must be", "must to be", "can be", "should being"], "Déduction quasi certaine : must be."],
  ["modals-deduction", "C1", 3, "She ___ forgotten our meeting.", ["must have", "must", "must had", "must has"], "Déduction sur le passé : must have + participe."],
  ["modals-deduction", "C1", 3, "You ___ told me earlier!", ["should have", "should", "should to", "must"], "Reproche sur le passé : should have + participe."],
  ["modals-deduction", "C1", 3, "He ___ seen us — he was asleep.", ["can't have", "mustn't have", "couldn't to", "can't has"], "Impossibilité passée : can't have + participe."],

  // ---------- passive-voice ----------
  ["passive-voice", "B1", 2, "English ___ all over the world.", ["is spoken", "speaks", "is speaking", "spoke"], "Passif présent : is + participe passé."],
  ["passive-voice", "B2", 2, "The old bridge ___ in 1902.", ["was built", "has built", "built", "was building"], "Passif passé : was + participe."],
  ["passive-voice", "B2", 2, "The car ___ already ___ .", ["has been sold", "has sold", "is selling", "had sell"], "Passif au present perfect : has been + participe."],
  ["passive-voice", "B2", 2, "This work must ___ before Friday.", ["be done", "do", "done", "be do"], "Passif avec modal : modal + be + participe."],
  ["passive-voice", "B2", 3, "I ___ a second chance by my boss.", ["was given", "was gave", "gave", "am giving"], "Passif à deux objets : la personne devient sujet."],

  // ---------- reported-speech ----------
  ["reported-speech", "B2", 2, "She said she ___ tired.", ["was", "is", "be", "being"], "Le présent recule au passé."],
  ["reported-speech", "B2", 2, "He ___ me that he was late.", ["told", "said", "says", "say"], "« Tell » prend un complément de personne."],
  ["reported-speech", "B2", 2, "She asked where I ___.", ["lived", "did live", "do live", "live"], "Pas d'inversion dans une question rapportée."],
  ["reported-speech", "B2", 3, "He asked ___ I was ready.", ["if", "that", "what", "did"], "Sans mot interrogatif : if / whether."],
  ["reported-speech", "B2", 3, "She told me ___ for her.", ["to wait", "wait", "waiting", "that wait"], "Ordre rapporté : tell + personne + to + base."],

  // ---------- gerund-infinitive ----------
  ["gerund-infinitive", "B1", 2, "I enjoy ___ novels at night.", ["reading", "to read", "read", "reads"], "« Enjoy » est suivi du -ing."],
  ["gerund-infinitive", "B1", 2, "She promised ___ me tonight.", ["to call", "calling", "call", "called"], "« Promise » est suivi de to + base."],
  ["gerund-infinitive", "B1", 2, "I like ___ to music in the evening.", ["listening", "listen", "listened", "listens"], "Après « like », le -ing est le plus courant."],
  ["gerund-infinitive", "B2", 2, "I look forward to ___ you.", ["meeting", "meet", "to meet", "met"], "Ici « to » est une préposition → -ing."],
  ["gerund-infinitive", "B2", 3, "He avoided ___ the question.", ["answering", "to answer", "answer", "answered"], "« Avoid » impose le -ing."],
  ["gerund-infinitive", "B2", 3, "Remember ___ the door when you leave.", ["to lock", "locking", "lock", "locked"], "« Remember to » = penser à faire (futur)."],
  ["gerund-infinitive", "B2", 3, "She stopped ___ when the doctor warned her.", ["smoking", "to smoke", "smoke", "smoked"], "« Stop + -ing » = arrêter cette activité."],

  // ---------- phrasal-verbs ----------
  ["phrasal-verbs", "B1", 2, "Don't ___ up! You're almost there.", ["give", "gave", "giving", "given"], "« Give up » = abandonner."],
  ["phrasal-verbs", "B2", 2, "The TV is too loud — turn ___ .", ["it off", "off it", "off", "it of"], "Le pronom se place entre le verbe et la particule."],
  ["phrasal-verbs", "B2", 2, "I can't put up ___ this noise.", ["with", "of", "for", "to"], "« Put up with » = supporter."],
  ["phrasal-verbs", "B2", 2, "She's looking ___ her little brother today.", ["after", "for", "up", "at"], "« Look after » = s'occuper de."],
  ["phrasal-verbs", "B2", 3, "We ___ of milk this morning.", ["ran out", "ran off", "run over", "ran away"], "« Run out of » = tomber à court de."],

  // ---------- nouns-plurals ----------
  ["nouns-plurals", "A1", 1, "Two ___ are playing in the park.", ["children", "childs", "child", "childrens"], "Pluriel irrégulier : children."],
  ["nouns-plurals", "A2", 1, "I need three ___ for the kitchen.", ["knives", "knifes", "knife", "knifs"], "-fe → -ves : knives."],
  ["nouns-plurals", "A2", 1, "This is ___ car.", ["my sister's", "the car of my sister", "my sister", "my sisters"], "Possession : génitif 's."],
  ["nouns-plurals", "A2", 2, "All the ___ left the building.", ["people", "peoples", "persons", "peoplas"], "« People » est déjà un pluriel."],

  // ---------- countable-uncountable ----------
  ["countable-uncountable", "B1", 2, "There isn't ___ milk left in the fridge.", ["any", "some", "many", "a few"], "Phrase négative → any."],
  ["countable-uncountable", "B1", 2, "How ___ sugar do you want?", ["much", "many", "few", "a lot"], "« Sugar » est indénombrable."],
  ["countable-uncountable", "B1", 2, "There are ___ people at the party.", ["many", "much", "a little", "an"], "« People » est dénombrable pluriel."],
  ["countable-uncountable", "B1", 2, "She gave me some good ___ .", ["advice", "advices", "advise", "an advice"], "« Advice » est toujours indénombrable."],
  ["countable-uncountable", "B2", 2, "The news ___ not good today.", ["is", "are", "were", "have"], "« News » est singulier malgré le -s."],
  ["countable-uncountable", "B2", 2, "I only have ___ time before the train.", ["a little", "a few", "many", "few of"], "« Time » indénombrable → a little."],

  // ---------- articles ----------
  ["articles", "A1", 1, "I saw ___ elephant at the zoo.", ["an", "a", "the", "some"], "Son voyelle → an."],
  ["articles", "A1", 1, "She is ___ doctor in a big hospital.", ["a", "an", "the", "one"], "Son consonne → a."],
  ["articles", "A2", 2, "Please close ___ door, it's cold.", ["the", "a", "an", "some"], "Objet identifié → the."],
  ["articles", "B1", 2, "___ is beautiful when you're young.", ["Life", "The life", "A life", "Lifes"], "Généralité abstraite → zéro article."],
  ["articles", "B1", 2, "I play ___ football every Sunday.", ["(rien)", "the", "a", "an"], "Les sports ne prennent pas d'article."],
  ["articles", "B1", 2, "He plays ___ piano beautifully.", ["the", "(rien)", "a", "an"], "Les instruments prennent « the »."],
  ["articles", "B2", 2, "It took me ___ hour to get here.", ["an", "a", "the", "one of"], "« Hour » commence par un son voyelle."],

  // ---------- determiners-quantifiers ----------
  ["determiners-quantifiers", "B1", 2, "Would you like ___ tea?", ["some", "any", "much", "a"], "Offre polie → some."],
  ["determiners-quantifiers", "B1", 2, "I don't have ___ money.", ["any", "some", "no any", "none"], "Négation → any."],
  ["determiners-quantifiers", "B1", 2, "Everybody ___ here now.", ["is", "are", "were", "have"], "Les composés sont singuliers."],
  ["determiners-quantifiers", "B2", 2, "I have ___ idea what he means.", ["no", "not", "any", "none"], "« No + nom » = not any, plus emphatique."],

  // ---------- adjectives-order ----------
  ["adjectives-order", "A2", 1, "She bought three ___ .", ["red cars", "cars red", "reds cars", "car reds"], "Adjectif invariable, placé avant le nom."],
  ["adjectives-order", "B1", 2, "This class is boring — I'm ___ .", ["bored", "boring", "bore", "bored of"], "-ed = ce que je ressens."],
  ["adjectives-order", "B1", 2, "The documentary was really ___ .", ["interesting", "interested", "interest", "interestly"], "-ing = ce qui provoque le sentiment."],
  ["adjectives-order", "B2", 3, "She has a ___ table.", ["lovely old wooden", "wooden old lovely", "old lovely wooden", "wooden lovely old"], "Ordre : opinion → âge → matière."],

  // ---------- comparatives-superlatives ----------
  ["comparatives-superlatives", "B1", 2, "My house is ___ than yours.", ["bigger", "biggest", "more big", "bigger more"], "Adjectif court + -er (consonne doublée)."],
  ["comparatives-superlatives", "B1", 2, "Everest is the ___ mountain in the world.", ["highest", "higher", "most high", "more high"], "Superlatif court : the + -est."],
  ["comparatives-superlatives", "B1", 2, "English is ___ than I thought.", ["easier", "easyer", "more easy", "easiest"], "y → -ier."],
  ["comparatives-superlatives", "B1", 2, "This film is the ___ I've ever seen.", ["most interesting", "more interesting", "interestingest", "much interesting"], "Adjectif long : the most."],
  ["comparatives-superlatives", "B2", 2, "She's ___ tall as her brother.", ["as", "so", "than", "more"], "Égalité : as + adjectif + as."],
  ["comparatives-superlatives", "B2", 3, "His work is much ___ than before.", ["better", "more better", "gooder", "best"], "Irrégulier : good → better, sans « more »."],

  // ---------- adverbs ----------
  ["adverbs", "B1", 2, "He speaks English ___ .", ["well", "good", "goodly", "better good"], "Un verbe se modifie par un adverbe : well."],
  ["adverbs", "B1", 2, "She speaks ___ .", ["English fluently", "fluently English", "fluent English very", "English fluent"], "Ne pas séparer le verbe de son complément."],
  ["adverbs", "B2", 2, "I ___ know him — we met once.", ["hardly", "hard", "hardly not", "strongly"], "« Hardly » = à peine."],
  ["adverbs", "B2", 2, "The team played ___ badly last night.", ["incredibly", "incredible", "incredibly much", "incredible very"], "Un adverbe modifie un autre adverbe."],

  // ---------- questions ----------
  ["questions", "A1", 1, "___ you speak English?", ["Do", "Does", "Is", "Are"], "Question au présent avec you : Do."],
  ["questions", "A2", 1, "___ are you from?", ["Where", "When", "Who", "Which"], "Lieu → Where."],
  ["questions", "B1", 2, "___ called you this morning?", ["Who", "Who did", "Whom did", "Who does"], "Question sur le sujet : pas d'auxiliaire."],
  ["questions", "B1", 2, "You're coming tonight, ___ ?", ["aren't you", "are you", "don't you", "isn't it"], "Tag inversé par rapport à la phrase."],
  ["questions", "B1", 2, "___ does the film last?", ["How long", "How much", "How many", "How far"], "Durée → How long."],

  // ---------- relative-clauses ----------
  ["relative-clauses", "B2", 2, "The man ___ called is my boss.", ["who", "which", "what", "whose"], "« Who » pour les personnes."],
  ["relative-clauses", "B2", 2, "The book ___ I read was great.", ["that", "who", "what", "whose"], "« That / which » pour les choses."],
  ["relative-clauses", "B2", 3, "The girl ___ bag was stolen called the police.", ["whose", "who's", "which", "of whom the"], "« Whose » exprime la possession."],
  ["relative-clauses", "B2", 3, "My brother, ___ lives in Rome, is a chef.", ["who", "that", "which", "whom he"], "Après une virgule, « that » est interdit."],
  ["relative-clauses", "C1", 3, "This is the café ___ we first met.", ["where", "which", "that", "when"], "Lieu → where."],

  // ---------- prepositions ----------
  ["prepositions", "A2", 1, "The cat is ___ the table.", ["on", "in", "at", "to"], "Surface → on."],
  ["prepositions", "A2", 1, "The meeting is ___ Monday.", ["on", "in", "at", "for"], "Jours → on."],
  ["prepositions", "A2", 1, "The shop opens ___ 9 o'clock.", ["at", "on", "in", "to"], "Heures → at."],
  ["prepositions", "A2", 1, "I was born ___ July.", ["in", "on", "at", "to"], "Mois → in."],
  ["prepositions", "B1", 2, "I'm waiting ___ the bus.", ["for", "(rien)", "to", "at"], "« Wait » exige « for »."],
  ["prepositions", "B1", 2, "It depends ___ the weather.", ["on", "of", "from", "to"], "« Depend on » est imposé par le verbe."],
  ["prepositions", "B1", 2, "I go ___ every evening at six.", ["home", "to home", "at home", "in home"], "« Home » ne prend pas « to »."],
  ["prepositions", "B2", 2, "She's very good ___ chess.", ["at", "in", "on", "with"], "« Good at » = doué pour."],

  // ---------- word-order-inversion ----------
  ["word-order-inversion", "C2", 3, "Never ___ such a beautiful sunset.", ["have I seen", "I have seen", "I saw have", "did I saw"], "Adverbe négatif en tête → inversion."],
  ["word-order-inversion", "C2", 3, "Not only ___ late, but he also forgot the keys.", ["did he arrive", "he arrived", "he did arrive", "arrived he"], "« Not only » en tête impose l'inversion."],
  ["word-order-inversion", "C1", 3, "She read the letter ___ .", ["carefully in her office last night", "last night carefully in her office", "in her office last night carefully", "carefully last night in her office"], "Ordre : manière → lieu → temps."],

  // ---------- punctuation-basics ----------
  ["punctuation-basics", "B1", 2, "Choose the correct sentence.", ["It's a nice day.", "Its a nice day.", "Its' a nice day.", "It is'nt a nice day."], "« It's » = it is ; « its » = possessif."],
  ["punctuation-basics", "B1", 2, "The dog wagged ___ tail.", ["its", "it's", "its'", "his'"], "Possessif « its » sans apostrophe."],
  ["punctuation-basics", "B1", 2, "Choose the correctly capitalised sentence.", ["I speak French on Monday.", "i speak french on monday.", "I speak french on Monday.", "I Speak French on monday."], "Majuscules : I, langues, jours."],
];

export function toDbRows() {
  return EXERCISES.map(([lessonSlug, cefr, difficulty, sentence, options, explanation]) => ({
    lessonSlug,
    topic: lessonSlug,
    cefr,
    difficulty,
    sentence,
    options,
    answerIndex: 0,
    explanation,
  }));
}
