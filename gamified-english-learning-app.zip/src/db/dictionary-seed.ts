import { createReadStream } from "node:fs";
import { createGunzip } from "node:zlib";
import path from "node:path";
import { pipeline } from "node:stream/promises";
import { from as copyFrom } from "pg-copy-streams";
import { sql } from "drizzle-orm";
import { db, pool } from "@/db";
import { dictionary } from "@/db/schema";

let importPromise: Promise<void> | null = null;

/** Rows currently in the dictionary table. */
export async function dictionaryCount(): Promise<number> {
  const [row] = (await db
    .select({ count: sql<number>`count(*)::int` })
    .from(dictionary)) as { count: number }[];
  return row?.count ?? 0;
}

/**
 * Streams data/dictionary.tsv.gz (≈370k words) into Postgres with COPY.
 * Idempotent and safe to call concurrently: the promise is memoised.
 */
export async function ensureDictionaryImported(): Promise<void> {
  if (importPromise) return importPromise;

  importPromise = (async () => {
    const existing = await dictionaryCount();
    if (existing > 100_000) return;

    const file = path.join(process.cwd(), "data", "dictionary.tsv.gz");
    const client = await pool.connect();
    try {
      await client.query("TRUNCATE dictionary RESTART IDENTITY CASCADE");
      const stream = client.query(
        copyFrom(
          "COPY dictionary (word, rank) FROM STDIN WITH (FORMAT text, NULL '\\N')",
        ) as never,
      ) as unknown as NodeJS.WritableStream;
      await pipeline(createReadStream(file), createGunzip(), stream);

      // Difficulty bands: 1 = most frequent … 8 = very rare / unranked
      await client.query(`
        UPDATE dictionary SET band = CASE
          WHEN rank IS NOT NULL AND rank <= 1000  THEN 1
          WHEN rank IS NOT NULL AND rank <= 3000  THEN 2
          WHEN rank IS NOT NULL AND rank <= 10000 THEN 3
          WHEN rank IS NOT NULL AND rank <= 25000 THEN 4
          WHEN rank IS NOT NULL                   THEN 5
          WHEN length(word) <= 7                  THEN 6
          WHEN length(word) <= 10                 THEN 7
          ELSE 8
        END
      `);
    } finally {
      client.release();
    }
  })().catch((err) => {
    importPromise = null; // allow a retry on next call
    throw err;
  });

  return importPromise;
}
