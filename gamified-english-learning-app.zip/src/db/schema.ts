import {
  pgTable,
  serial,
  integer,
  text,
  jsonb,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/**
 * Single-player profile. One row only (id = 1) for this personal app.
 * Stores global gamification state: XP, CEFR ladder position, streak, daily goal.
 * Unlimited play — no lives, no timers.
 */
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("Joueur"),
  xp: integer("xp").notNull().default(0),
  streak: integer("streak").notNull().default(0),
  lastActiveDate: text("last_active_date"), // ISO date "2026-03-04"
  dailyXp: integer("daily_xp").notNull().default(0),
  dailyXpDate: text("daily_xp_date"),
  dailyGoal: integer("daily_goal").notNull().default(60),
  totalCorrect: integer("total_correct").notNull().default(0),
  totalAnswered: integer("total_answered").notNull().default(0),
  sessionsPlayed: integer("sessions_played").notNull().default(0),
  grammarCorrect: integer("grammar_correct").notNull().default(0),
  textsRead: integer("texts_read").notNull().default(0),
  perfectMatches: integer("perfect_matches").notNull().default(0),
  knownWords: integer("known_words").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/** Vocabulary cards — words, phrasal verbs, native expressions */
export const words = pgTable("words", {
  id: serial("id").primaryKey(),
  en: text("en").notNull(),
  fr: text("fr").notNull(),
  category: text("category").notNull(),
  cefr: text("cefr").notNull().default("A1"), // A1..C2
  difficulty: integer("difficulty").notNull().default(1), // 1..3
  exampleEn: text("example_en").notNull().default(""),
  exampleFr: text("example_fr").notNull().default(""),
});

/** Spaced-repetition progress per word (mastery 0..5) */
export const wordProgress = pgTable(
  "word_progress",
  {
    id: serial("id").primaryKey(),
    wordId: integer("word_id")
      .notNull()
      .references(() => words.id, { onDelete: "cascade" }),
    mastery: integer("mastery").notNull().default(0),
    correctCount: integer("correct_count").notNull().default(0),
    wrongCount: integer("wrong_count").notNull().default(0),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("word_progress_word_idx").on(t.wordId)],
);

/** Grammar multiple-choice exercises, linked to a course lesson */
export const grammarExercises = pgTable("grammar_exercises", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  lessonSlug: text("lesson_slug").notNull().default(""),
  cefr: text("cefr").notNull().default("A1"),
  difficulty: integer("difficulty").notNull().default(1),
  sentence: text("sentence").notNull(), // contains "___" blank
  options: jsonb("options").$type<string[]>().notNull(),
  answerIndex: integer("answer_index").notNull(),
  explanation: text("explanation").notNull().default(""),
});

/** Short reading texts */
export const comprehensionTexts = pgTable("comprehension_texts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  cefr: text("cefr").notNull().default("A1"),
  difficulty: integer("difficulty").notNull().default(1),
});

/** Questions attached to a reading text (asked in French) */
export const comprehensionQuestions = pgTable("comprehension_questions", {
  id: serial("id").primaryKey(),
  textId: integer("text_id")
    .notNull()
    .references(() => comprehensionTexts.id, { onDelete: "cascade" }),
  question: text("question").notNull(),
  options: jsonb("options").$type<string[]>().notNull(),
  answerIndex: integer("answer_index").notNull(),
});

/**
 * Full English dictionary (~370k entries).
 * `rank` = frequency rank (1 = most common) when known, null otherwise.
 * `band` = difficulty band 1..8 used for sampling and vocabulary estimation.
 */
export const dictionary = pgTable(
  "dictionary",
  {
    id: serial("id").primaryKey(),
    word: text("word").notNull(),
    rank: integer("rank"),
    band: integer("band").notNull().default(8),
  },
  (t) => [
    uniqueIndex("dictionary_word_idx").on(t.word),
    index("dictionary_band_idx").on(t.band),
  ],
);

/** Dictionary entries the player has demonstrated knowing */
export const dictionaryKnown = pgTable(
  "dictionary_known",
  {
    id: serial("id").primaryKey(),
    dictionaryId: integer("dictionary_id")
      .notNull()
      .references(() => dictionary.id, { onDelete: "cascade" }),
    band: integer("band").notNull().default(8),
    source: text("source").notNull().default("sprint"),
    knownAt: timestamp("known_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("dictionary_known_idx").on(t.dictionaryId)],
);

/** Grammar course reading / practice progress, one row per lesson slug */
export const lessonProgress = pgTable(
  "lesson_progress",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    practiceCorrect: integer("practice_correct").notNull().default(0),
    practiceTotal: integer("practice_total").notNull().default(0),
    bestScore: integer("best_score").notNull().default(0), // percent
  },
  (t) => [uniqueIndex("lesson_progress_slug_idx").on(t.slug)],
);

/** Unlocked achievements */
export const userBadges = pgTable(
  "user_badges",
  {
    id: serial("id").primaryKey(),
    badgeKey: text("badge_key").notNull(),
    unlockedAt: timestamp("unlocked_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("user_badges_key_idx").on(t.badgeKey)],
);
