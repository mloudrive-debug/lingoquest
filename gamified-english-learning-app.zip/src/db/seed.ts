import { db } from "@/db";
import {
  profiles,
  words,
  grammarExercises,
  comprehensionTexts,
  comprehensionQuestions,
} from "@/db/schema";
import { toDbRows } from "@/db/grammar-exercises";
import { findLesson } from "@/content/grammar-course";

/** [en, fr, category, cefr, difficulty, exampleEn, exampleFr] */
type WordRow = [string, string, string, string, number, string, string];

const WORDS: WordRow[] = [
  // ---------- A1 : les fondations ----------
  ["hello", "bonjour", "Essentiels", "A1", 1, "Hello, how are you today?", "Bonjour, comment vas-tu aujourd'hui ?"],
  ["goodbye", "au revoir", "Essentiels", "A1", 1, "Goodbye, see you tomorrow!", "Au revoir, à demain !"],
  ["thank you", "merci", "Essentiels", "A1", 1, "Thank you for your help.", "Merci pour ton aide."],
  ["please", "s'il te plaît / s'il vous plaît", "Essentiels", "A1", 1, "A coffee, please.", "Un café, s'il vous plaît."],
  ["yes & no", "oui et non", "Essentiels", "A1", 1, "Yes, I agree. No, I don't.", "Oui, je suis d'accord. Non, je refuse."],
  ["time", "le temps", "Essentiels", "A1", 1, "What time is it?", "Quelle heure est-il ?"],
  ["today", "aujourd'hui", "Essentiels", "A1", 1, "Today is a beautiful day.", "Aujourd'hui est une belle journée."],
  ["tomorrow", "demain", "Essentiels", "A1", 1, "See you tomorrow morning.", "À demain matin."],
  ["yesterday", "hier", "Essentiels", "A1", 1, "I saw a great movie yesterday.", "J'ai vu un super film hier."],
  ["friend", "l'ami", "Essentiels", "A1", 1, "She is my best friend.", "C'est ma meilleure amie."],
  ["family", "la famille", "Essentiels", "A1", 1, "I love spending time with my family.", "J'adore passer du temps avec ma famille."],
  ["water", "l'eau", "Essentiels", "A1", 1, "Can I have some water, please?", "Puis-je avoir de l'eau, s'il vous plaît ?"],
  ["house", "la maison", "Essentiels", "A1", 1, "Our house has a big garden.", "Notre maison a un grand jardin."],
  ["to eat", "manger", "Essentiels", "A1", 1, "Let's eat something together.", "Mangeons quelque chose ensemble."],
  ["to drink", "boire", "Essentiels", "A1", 1, "I drink tea every morning.", "Je bois du thé chaque matin."],
  ["to sleep", "dormir", "Essentiels", "A1", 1, "The baby sleeps ten hours a night.", "Le bébé dort dix heures par nuit."],
  ["to speak", "parler", "Essentiels", "A1", 1, "She speaks three languages.", "Elle parle trois langues."],
  ["beautiful", "beau / belle", "Essentiels", "A1", 1, "What a beautiful day!", "Quelle belle journée !"],
  ["big", "grand", "Essentiels", "A1", 1, "They live in a big city.", "Ils vivent dans une grande ville."],
  ["small", "petit", "Essentiels", "A1", 1, "This is a small boat.", "C'est un petit bateau."],
  ["fast", "rapide", "Essentiels", "A1", 1, "He is a very fast runner.", "C'est un coureur très rapide."],
  ["slow", "lent", "Essentiels", "A1", 1, "The bus is slow this morning.", "Le bus est lent ce matin."],
  ["happy", "heureux", "Essentiels", "A1", 1, "I am so happy to see you.", "Je suis si heureux de te voir."],
  ["to help", "aider", "Essentiels", "A1", 1, "Can you help me, please?", "Peux-tu m'aider, s'il te plaît ?"],
  ["bread", "le pain", "Nourriture", "A1", 1, "I buy fresh bread every day.", "J'achète du pain frais chaque jour."],
  ["cheese", "le fromage", "Nourriture", "A1", 1, "This cheese is really good.", "Ce fromage est vraiment bon."],
  ["apple", "la pomme", "Nourriture", "A1", 1, "She eats an apple at break time.", "Elle mange une pomme à la pause."],
  ["rice", "le riz", "Nourriture", "A1", 1, "Rice goes well with chicken.", "Le riz accompagne bien le poulet."],
  ["egg", "l'œuf", "Nourriture", "A1", 1, "I like my eggs boiled.", "J'aime mes œufs à la coque."],
  ["milk", "le lait", "Nourriture", "A1", 1, "The milk is in the fridge.", "Le lait est dans le frigo."],
  ["coffee", "le café", "Nourriture", "A1", 1, "I need a coffee to wake up.", "J'ai besoin d'un café pour me réveiller."],
  ["breakfast", "le petit-déjeuner", "Nourriture", "A1", 1, "Breakfast is my favorite meal.", "Le petit-déjeuner est mon repas préféré."],
  ["dinner", "le dîner", "Nourriture", "A1", 1, "Dinner is at eight o'clock.", "Le dîner est servi à vingt heures."],
  ["hungry", "affamé", "Nourriture", "A1", 1, "The kids are always hungry.", "Les enfants ont toujours faim."],
  ["thirsty", "assoiffé", "Nourriture", "A1", 1, "I am so thirsty after running.", "J'ai tellement soif après avoir couru."],
  ["bed", "le lit", "Maison", "A1", 1, "I go to bed at eleven.", "Je me couche à onze heures."],
  ["door", "la porte", "Maison", "A1", 1, "Close the door, please.", "Ferme la porte, s'il te plaît."],
  ["window", "la fenêtre", "Maison", "A1", 1, "Open the window, it's hot.", "Ouvre la fenêtre, il fait chaud."],
  ["kitchen", "la cuisine", "Maison", "A1", 1, "She is cooking in the kitchen.", "Elle est en train de cuisiner."],
  ["shower", "la douche", "Maison", "A1", 1, "I take a shower every morning.", "Je prends une douche chaque matin."],
  ["key", "la clé", "Maison", "A1", 1, "I can't find my keys!", "Je ne trouve pas mes clés !"],
  ["book", "le livre", "Loisirs", "A1", 1, "I am reading a great book.", "Je lis un super livre."],
  ["movie", "le film", "Loisirs", "A1", 1, "This movie is very funny.", "Ce film est très drôle."],
  ["song", "la chanson", "Loisirs", "A1", 1, "This song is my favorite.", "Cette chanson est ma préférée."],
  ["game", "le jeu", "Loisirs", "A1", 1, "The children invent a new game.", "Les enfants inventent un nouveau jeu."],
  ["train", "le train", "Voyage", "A1", 1, "The train leaves at ten.", "Le train part à dix heures."],
  ["ticket", "le billet", "Voyage", "A1", 1, "I can't find my train ticket.", "Je ne trouve pas mon billet de train."],
  ["hotel", "l'hôtel", "Voyage", "A1", 1, "Our hotel is near the beach.", "Notre hôtel est près de la plage."],
  ["beach", "la plage", "Voyage", "A1", 1, "The children play on the beach.", "Les enfants jouent sur la plage."],
  ["weather", "la météo / le temps", "Nature", "A1", 1, "The weather is nice today.", "Le temps est beau aujourd'hui."],

  // ---------- A2 : les bases solides ----------
  ["to borrow", "emprunter", "Quotidien", "A2", 1, "Can I borrow your pen?", "Je peux emprunter ton stylo ?"],
  ["to lend", "prêter", "Quotidien", "A2", 1, "I can lend you my bike.", "Je peux te prêter mon vélo."],
  ["to decide", "décider", "Quotidien", "A2", 1, "We decided to stay home.", "Nous avons décidé de rester à la maison."],
  ["to hope", "espérer", "Quotidien", "A2", 1, "I hope it doesn't rain.", "J'espère qu'il ne pleuvra pas."],
  ["to wait", "attendre", "Quotidien", "A2", 1, "Wait for me at the door.", "Attends-moi à la porte."],
  ["to try", "essayer", "Quotidien", "A2", 1, "Try this soup, it's great.", "Essaie cette soupe, elle est super."],
  ["early", "tôt", "Quotidien", "A2", 1, "I woke up early today.", "Je me suis réveillé tôt aujourd'hui."],
  ["late", "en retard", "Quotidien", "A2", 1, "The train is late again.", "Le train est encore en retard."],
  ["often", "souvent", "Quotidien", "A2", 1, "She often sings in the car.", "Elle chante souvent en voiture."],
  ["sometimes", "parfois", "Quotidien", "A2", 1, "I sometimes work from home.", "Je travaille parfois depuis la maison."],
  ["enough", "assez", "Quotidien", "A2", 1, "We have enough time.", "Nous avons assez de temps."],
  ["almost", "presque", "Quotidien", "A2", 1, "The movie is almost over.", "Le film est presque fini."],
  ["advice", "un conseil", "Quotidien", "A2", 1, "Can you give me some advice?", "Tu peux me donner un conseil ?"],
  ["to forget", "oublier", "Quotidien", "A2", 1, "Don't forget your umbrella.", "N'oublie pas ton parapluie."],
  ["to remember", "se souvenir", "Quotidien", "A2", 1, "Do you remember her name?", "Tu te souviens de son nom ?"],
  ["to need", "avoir besoin", "Quotidien", "A2", 1, "I need a break.", "J'ai besoin d'une pause."],
  ["to lose", "perdre", "Quotidien", "A2", 1, "Don't lose hope.", "Ne perds pas espoir."],
  ["to win", "gagner", "Quotidien", "A2", 1, "Our team won the match.", "Notre équipe a gagné le match."],
  ["to cry", "pleurer", "Émotions", "A2", 1, "The baby is crying again.", "Le bébé pleure encore."],
  ["to smile", "sourire", "Émotions", "A2", 1, "She smiled at me in the street.", "Elle m'a souri dans la rue."],
  ["to sell", "vendre", "Quotidien", "A2", 1, "They sell fresh bread here.", "Ils vendent du pain frais ici."],
  ["to buy", "acheter", "Quotidien", "A2", 1, "I bought a new phone last week.", "J'ai acheté un nouveau téléphone la semaine dernière."],
  ["to carry", "porter", "Quotidien", "A2", 1, "Let me carry your bag.", "Laisse-moi porter ton sac."],
  ["careful", "prudent", "Quotidien", "A2", 1, "Be careful, the floor is wet.", "Fais attention, le sol est mouillé."],
  ["to travel", "voyager", "Voyage", "A2", 1, "I love to travel by train.", "J'adore voyager en train."],
  ["suitcase", "la valise", "Voyage", "A2", 1, "My suitcase is too heavy.", "Ma valise est trop lourde."],
  ["airport", "l'aéroport", "Voyage", "A2", 1, "We arrived at the airport early.", "Nous sommes arrivés tôt à l'aéroport."],
  ["journey", "le voyage", "Voyage", "A2", 2, "The journey takes two hours.", "Le voyage dure deux heures."],
  ["map", "la carte", "Voyage", "A2", 1, "Let's look at the map first.", "Regardons d'abord la carte."],
  ["passport", "le passeport", "Voyage", "A2", 1, "Don't forget your passport!", "N'oublie pas ton passeport !"],
  ["to book", "réserver", "Voyage", "A2", 1, "I booked a room for two nights.", "J'ai réservé une chambre pour deux nuits."],
  ["to cook", "cuisiner", "Nourriture", "A2", 1, "My father loves to cook.", "Mon père adore cuisiner."],
  ["sweet", "sucré", "Nourriture", "A2", 1, "This tea is too sweet for me.", "Ce thé est trop sucré pour moi."],
  ["salty", "salé", "Nourriture", "A2", 1, "The soup is a little salty.", "La soupe est un peu salée."],
  ["fish", "le poisson", "Nourriture", "A2", 1, "We had fish for dinner last night.", "Nous avons mangé du poisson hier soir."],
  ["meat", "la viande", "Nourriture", "A2", 1, "He doesn't eat meat anymore.", "Il ne mange plus de viande."],
  ["bottle", "la bouteille", "Nourriture", "A2", 1, "A bottle of water, please.", "Une bouteille d'eau, s'il vous plaît."],
  ["mirror", "le miroir", "Maison", "A2", 1, "He looks at himself in the mirror.", "Il se regarde dans le miroir."],
  ["sofa", "le canapé", "Maison", "A2", 1, "The cat sleeps on the sofa.", "Le chat dort sur le canapé."],
  ["garden", "le jardin", "Maison", "A2", 1, "We have lunch in the garden.", "Nous déjeunons dans le jardin."],
  ["neighbor", "le voisin", "Maison", "A2", 1, "Our neighbors are very kind.", "Nos voisins sont très gentils."],
  ["to clean", "nettoyer", "Maison", "A2", 1, "I clean the house on Saturdays.", "Je nettoie la maison le samedi."],
  ["alarm clock", "le réveil", "Maison", "A2", 1, "My alarm clock rings at six.", "Mon réveil sonne à six heures."],
  ["tree", "l'arbre", "Nature", "A2", 1, "This tree is one hundred years old.", "Cet arbre a cent ans."],
  ["rain", "la pluie", "Nature", "A2", 1, "The rain stops at noon.", "La pluie s'arrête à midi."],
  ["snow", "la neige", "Nature", "A2", 1, "The snow covers the streets.", "La neige couvre les rues."],
  ["sky", "le ciel", "Nature", "A2", 1, "The sky is so blue this morning.", "Le ciel est si bleu ce matin."],
  ["flower", "la fleur", "Nature", "A2", 1, "This flower smells wonderful.", "Cette fleur sent merveilleusement bon."],
  ["concert", "le concert", "Loisirs", "A2", 1, "The concert starts at eight.", "Le concert commence à vingt heures."],
  ["hobby", "le passe-temps", "Loisirs", "A2", 2, "Gardening is my favorite hobby.", "Le jardinage est mon passe-temps préféré."],
  ["free time", "le temps libre", "Loisirs", "A2", 1, "What do you do in your free time?", "Que fais-tu pendant ton temps libre ?"],
  ["to relax", "se détendre", "Loisirs", "A2", 1, "I relax with music after work.", "Je me détends avec de la musique après le travail."],
  ["to walk", "se promener", "Loisirs", "A2", 1, "We walk along the river on Sundays.", "Nous nous promenons le long de la rivière le dimanche."],
  ["to laugh", "rire", "Loisirs", "A2", 1, "We laugh a lot together.", "Nous rions beaucoup ensemble."],

  // ---------- B1 : l'indépendance ----------
  ["delay", "le retard", "Voyage", "B1", 2, "The flight has a long delay.", "Le vol a un long retard."],
  ["platform", "le quai", "Voyage", "B1", 2, "The train is on platform three.", "Le train est au quai numéro trois."],
  ["seat", "le siège", "Voyage", "B1", 2, "Is this seat free?", "Cette place est-elle libre ?"],
  ["luggage", "les bagages", "Voyage", "B1", 2, "Where is my luggage?", "Où sont mes bagages ?"],
  ["souvenir", "le souvenir", "Voyage", "B1", 2, "She buys a souvenir for her sister.", "Elle achète un souvenir pour sa sœur."],
  ["delicious", "délicieux", "Nourriture", "B1", 2, "This cake is absolutely delicious!", "Ce gâteau est absolument délicieux !"],
  ["recipe", "la recette", "Nourriture", "B1", 2, "This recipe is easy to follow.", "Cette recette est facile à suivre."],
  ["angry", "en colère", "Émotions", "B1", 2, "He is angry about the delay.", "Il est en colère à cause du retard."],
  ["proud", "fier", "Émotions", "B1", 2, "We are very proud of you.", "Nous sommes très fiers de toi."],
  ["shy", "timide", "Émotions", "B1", 2, "The new student is a bit shy.", "Le nouvel élève est un peu timide."],
  ["bored", "ennuyé", "Émotions", "B1", 2, "The kids are bored at home.", "Les enfants s'ennuient à la maison."],
  ["excited", "très enthousiaste", "Émotions", "B1", 2, "I am so excited about the trip!", "Je suis tellement enthousiaste pour ce voyage !"],
  ["worried", "inquiet", "Émotions", "B1", 2, "She is worried about the exam.", "Elle est inquiète pour l'examen."],
  ["surprised", "surpris", "Émotions", "B1", 2, "We were surprised by the news.", "Nous avons été surpris par la nouvelle."],
  ["disappointed", "déçu", "Émotions", "B1", 2, "He is disappointed with the result.", "Il est déçu du résultat."],
  ["jealous", "jaloux", "Émotions", "B1", 2, "The cat is jealous of the dog.", "Le chat est jaloux du chien."],
  ["lonely", "seul", "Émotions", "B1", 2, "The old man often feels lonely.", "Le vieil homme se sent souvent seul."],
  ["to feel", "ressentir", "Émotions", "B1", 2, "How do you feel today?", "Comment te sens-tu aujourd'hui ?"],
  ["fear", "la peur", "Émotions", "B1", 2, "She has a fear of spiders.", "Elle a peur des araignées."],
  ["joy", "la joie", "Émotions", "B1", 2, "Her eyes are full of joy.", "Ses yeux sont pleins de joie."],
  ["sadness", "la tristesse", "Émotions", "B1", 2, "Time slowly heals sadness.", "Le temps guérit doucement la tristesse."],
  ["meeting", "la réunion", "Travail", "B1", 2, "The meeting starts at nine.", "La réunion commence à neuf heures."],
  ["salary", "le salaire", "Travail", "B1", 2, "He is happy with his new salary.", "Il est content de son nouveau salaire."],
  ["boss", "le patron", "Travail", "B1", 2, "My boss is very understanding.", "Mon patron est très compréhensif."],
  ["colleague", "le collègue", "Travail", "B1", 2, "I have lunch with my colleagues.", "Je déjeune avec mes collègues."],
  ["office", "le bureau", "Travail", "B1", 2, "The office is on the second floor.", "Le bureau est au deuxième étage."],
  ["deadline", "la date limite", "Travail", "B1", 2, "The deadline is this Friday.", "La date limite est ce vendredi."],
  ["schedule", "l'emploi du temps", "Travail", "B1", 2, "My schedule is completely full today.", "Mon emploi du temps est plein aujourd'hui."],
  ["task", "la tâche", "Travail", "B1", 2, "Finish this task before noon.", "Termine cette tâche avant midi."],
  ["goal", "l'objectif", "Travail", "B1", 2, "Our goal is perfectly clear.", "Notre objectif est parfaitement clair."],
  ["decision", "la décision", "Travail", "B1", 2, "This is a very important decision.", "C'est une décision très importante."],
  ["rent", "le loyer", "Maison", "B1", 2, "The rent is due on Monday.", "Le loyer est dû lundi."],
  ["river", "la rivière", "Nature", "B1", 2, "They swim in the river in summer.", "Ils nagent dans la rivière en été."],
  ["mountain", "la montagne", "Nature", "B1", 2, "We climb the mountain in July.", "Nous gravissons la montagne en juillet."],
  ["wind", "le vent", "Nature", "B1", 2, "The wind is strong tonight.", "Le vent est fort ce soir."],
  ["forest", "la forêt", "Nature", "B1", 2, "The forest is quiet and dark.", "La forêt est calme et sombre."],
  ["to achieve", "accomplir", "Travail", "B1", 2, "She achieved her goals this year.", "Elle a accompli ses objectifs cette année."],
  ["to complain", "se plaindre", "Quotidien", "B1", 2, "Customers complained about the noise.", "Les clients se sont plaints du bruit."],
  ["to compare", "comparer", "Quotidien", "B1", 2, "Compare the prices before buying.", "Compare les prix avant d'acheter."],
  ["to suggest", "suggérer", "Quotidien", "B1", 2, "I suggest we take the train.", "Je suggère qu'on prenne le train."],
  ["to explain", "expliquer", "Quotidien", "B1", 2, "Can you explain the rule again?", "Tu peux réexpliquer la règle ?"],
  ["to avoid", "éviter", "Quotidien", "B1", 2, "I avoid driving during rush hour.", "J'évite de conduire aux heures de pointe."],
  ["to refuse", "refuser", "Quotidien", "B1", 2, "He refused to answer the question.", "Il a refusé de répondre à la question."],
  ["to promise", "promettre", "Quotidien", "B1", 2, "She promised to call me tonight.", "Elle a promis de m'appeler ce soir."],
  ["to notice", "remarquer", "Quotidien", "B1", 2, "Did you notice her new haircut?", "Tu as remarqué sa nouvelle coupe ?"],
  ["to apologize", "s'excuser", "Quotidien", "B1", 2, "He apologized for being late.", "Il s'est excusé pour son retard."],
  ["to seem", "sembler", "Quotidien", "B1", 2, "You seem tired today.", "Tu sembles fatigué aujourd'hui."],
  ["to belong", "appartenir", "Quotidien", "B1", 2, "This book belongs to my sister.", "Ce livre appartient à ma sœur."],
  ["to disappear", "disparaître", "Quotidien", "B1", 2, "My keys disappear every morning!", "Mes clés disparaissent chaque matin !"],
  ["to struggle", "galérer", "Quotidien", "B1", 2, "I struggle with English grammar.", "Je galère avec la grammaire anglaise."],
  ["traffic", "la circulation", "Voyage", "B1", 2, "The traffic is terrible this morning.", "La circulation est terrible ce matin."],
  ["crowded", "bondé", "Quotidien", "B1", 2, "The beach is too crowded in August.", "La plage est trop bondée en août."],
  ["pollution", "la pollution", "Société", "B1", 2, "Air pollution is a real problem.", "La pollution de l'air est un vrai problème."],
  ["environment", "l'environnement", "Société", "B1", 2, "We must protect the environment.", "Nous devons protéger l'environnement."],
  ["average", "moyen", "Quotidien", "B1", 2, "The average price is twenty euros.", "Le prix moyen est de vingt euros."],
  ["similar", "similaire", "Quotidien", "B1", 2, "Our ideas are very similar.", "Nos idées sont très similaires."],
  ["convenient", "pratique", "Quotidien", "B1", 2, "This app is really convenient.", "Cette appli est vraiment pratique."],
  ["delighted", "ravi", "Émotions", "B1", 2, "I'm delighted to meet you.", "Je suis ravi de te rencontrer."],
  ["furious", "furieux", "Émotions", "B1", 2, "My dad was furious about the car.", "Mon père était furieux à cause de la voiture."],
  ["huge", "énorme", "Quotidien", "B1", 2, "They live in a huge apartment.", "Ils vivent dans un appartement énorme."],
  ["tiny", "minuscule", "Quotidien", "B1", 2, "The kitchen is tiny but cute.", "La cuisine est minuscule mais mignonne."],
  ["empty", "vide", "Quotidien", "B1", 2, "The fridge is completely empty.", "Le frigo est complètement vide."],
  ["heavy", "lourd", "Quotidien", "B1", 2, "This box is too heavy for me.", "Cette boîte est trop lourde pour moi."],
  ["countryside", "la campagne", "Nature", "B1", 2, "I grew up in the countryside.", "J'ai grandi à la campagne."],
  ["foreign", "étranger", "Société", "B1", 2, "She speaks two foreign languages.", "Elle parle deux langues étrangères."],

  // ---------- B2 : l'autonomie ----------
  ["despite", "malgré", "Structure", "B2", 2, "Despite the rain, we went out.", "Malgré la pluie, nous sommes sortis."],
  ["whereas", "alors que", "Structure", "B2", 2, "I like tea, whereas he prefers coffee.", "J'aime le thé, alors qu'il préfère le café."],
  ["roughly", "approximativement", "Structure", "B2", 2, "The trip takes roughly two hours.", "Le trajet prend approximativement deux heures."],
  ["significant", "significatif", "Structure", "B2", 2, "There is a significant difference.", "Il y a une différence significative."],
  ["eventually", "finalement", "Structure", "B2", 2, "We eventually found the hotel.", "Nous avons finalement trouvé l'hôtel."],
  ["currently", "actuellement", "Structure", "B2", 2, "She is currently living in Spain.", "Elle vit actuellement en Espagne."],
  ["beforehand", "à l'avance", "Structure", "B2", 2, "You should book the tickets beforehand.", "Tu devrais réserver les billets à l'avance."],
  ["briefly", "brièvement", "Structure", "B2", 2, "He briefly explained the plan.", "Il a brièvement expliqué le plan."],
  ["to assume", "supposer", "Quotidien", "B2", 2, "I assume you're coming tonight?", "Je suppose que tu viens ce soir ?"],
  ["to postpone", "reporter", "Travail", "B2", 2, "They postponed the meeting to Friday.", "Ils ont reporté la réunion à vendredi."],
  ["to convince", "convaincre", "Quotidien", "B2", 2, "She convinced me to try sushi.", "Elle m'a convaincu de goûter les sushis."],
  ["to negotiate", "négocier", "Travail", "B2", 2, "He negotiated a better salary.", "Il a négocié un meilleur salaire."],
  ["to deny", "nier", "Quotidien", "B2", 2, "He denied breaking the window.", "Il a nié avoir cassé la fenêtre."],
  ["to confirm", "confirmer", "Travail", "B2", 2, "Please confirm your booking by email.", "Merci de confirmer ta réservation par email."],
  ["to announce", "annoncer", "Travail", "B2", 2, "They announced the results yesterday.", "Ils ont annoncé les résultats hier."],
  ["to handle", "gérer", "Travail", "B2", 2, "She handles stress really well.", "Elle gère très bien le stress."],
  ["to blame", "reprocher à", "Quotidien", "B2", 2, "Don't blame me for the traffic!", "Ne me reproche pas les bouchons !"],
  ["to demand", "exiger", "Société", "B2", 2, "The workers demanded better pay.", "Les ouvriers ont exigé de meilleurs salaires."],
  ["to seek", "chercher", "Travail", "B2", 2, "They're seeking volunteers for the project.", "Ils cherchent des bénévoles pour le projet."],
  ["to raise awareness", "sensibiliser", "Société", "B2", 2, "The campaign raises awareness about recycling.", "La campagne sensibilise au recyclage."],
  ["awkward", "gênant / maladroit", "Émotions", "B2", 2, "There was an awkward silence.", "Il y a eu un silence gênant."],
  ["deliberate", "délibéré", "Quotidien", "B2", 2, "It was a deliberate choice.", "C'était un choix délibéré."],
  ["reliable", "fiable", "Quotidien", "B2", 2, "The train is not very reliable here.", "Le train n'est pas très fiable ici."],
  ["efficient", "efficace", "Travail", "B2", 2, "This method is fast and efficient.", "Cette méthode est rapide et efficace."],
  ["curious", "curieux", "Émotions", "B2", 2, "I'm curious about the result.", "Je suis curieux de connaître le résultat."],
  ["widespread", "répandu", "Société", "B2", 2, "Smartphones are widespread today.", "Les smartphones sont répandus aujourd'hui."],
  ["countless", "innombrable", "Quotidien", "B2", 2, "I've watched countless tutorials.", "J'ai regardé d'innombrables tutoriels."],
  ["steady", "stable / régulier", "Quotidien", "B2", 2, "He has a steady job now.", "Il a un emploi stable maintenant."],
  ["threat", "la menace", "Société", "B2", 2, "Climate change is a real threat.", "Le changement climatique est une vraie menace."],
  ["awareness", "la conscience / la sensibilisation", "Société", "B2", 2, "Awareness of the issue is growing.", "La conscience du problème grandit."],
  ["guilty", "coupable", "Émotions", "B2", 2, "He felt guilty about lying.", "Il se sentait coupable d'avoir menti."],
  ["innocent", "innocent", "Quotidien", "B2", 2, "The dog looks totally innocent.", "Le chien a l'air totalement innocent."],
  ["income", "le revenu", "Travail", "B2", 2, "Her income allows her to travel.", "Ses revenus lui permettent de voyager."],
  ["skill", "la compétence", "Travail", "B2", 2, "English is a very useful skill.", "L'anglais est une compétence très utile."],
  ["to hire", "embaucher", "Travail", "B2", 2, "They want to hire an engineer.", "Ils veulent embaucher un ingénieur."],
  ["interview", "l'entretien", "Travail", "B2", 2, "I have a job interview tomorrow.", "J'ai un entretien d'embauche demain."],
  ["to improve", "améliorer", "Travail", "B2", 2, "Practice improves your skills.", "La pratique améliore tes compétences."],
  ["storm", "l'orage", "Nature", "B2", 2, "A big storm is coming tonight.", "Un gros orage arrive ce soir."],

  // ---------- C1 : l'aisance ----------
  ["to procrastinate", "procrastiner", "Quotidien", "C1", 3, "Stop procrastinating and study!", "Arrête de procrastiner et travaille !"],
  ["ubiquitous", "omniprésent", "Société", "C1", 3, "Screens are ubiquitous in our lives.", "Les écrans sont omniprésents dans nos vies."],
  ["meticulous", "méticuleux", "Quotidien", "C1", 3, "She is meticulous about details.", "Elle est méticuleuse sur les détails."],
  ["resilient", "résilient", "Émotions", "C1", 3, "Children are surprisingly resilient.", "Les enfants sont étonnamment résilients."],
  ["ambiguous", "ambigu", "Quotidien", "C1", 3, "His answer was totally ambiguous.", "Sa réponse était totalement ambiguë."],
  ["eloquent", "éloquent", "Quotidien", "C1", 3, "The speech was clear and eloquent.", "Le discours était clair et éloquent."],
  ["tenacious", "tenace", "Quotidien", "C1", 3, "You need to be tenacious to succeed.", "Il faut être tenace pour réussir."],
  ["to thrive", "prospérer / s'épanouir", "Quotidien", "C1", 3, "Plants thrive in this climate.", "Les plantes prospèrent dans ce climat."],
  ["nuance", "la nuance", "Quotidien", "C1", 3, "There's a subtle nuance in her tone.", "Il y a une nuance subtile dans son ton."],
  ["compelling", "captivant / convaincant", "Quotidien", "C1", 3, "The book makes a compelling argument.", "Le livre avance un argument convaincant."],
  ["breakthrough", "la percée", "Société", "C1", 3, "Scientists announced a major breakthrough.", "Les scientifiques ont annoncé une percée majeure."],
  ["to undermine", "saper", "Quotidien", "C1", 3, "Rumors can undermine confidence.", "Les rumeurs peuvent saper la confiance."],
  ["to leverage", "tirer parti de", "Travail", "C1", 3, "We leverage technology to teach better.", "Nous tirons parti de la technologie pour mieux enseigner."],
  ["tedious", "fastidieux", "Quotidien", "C1", 3, "Filling forms is tedious work.", "Remplir des formulaires est un travail fastidieux."],
  ["charisma", "le charisme", "Quotidien", "C1", 3, "The singer has incredible charisma.", "Le chanteur a un charisme incroyable."],
  ["witty", "spirituel", "Quotidien", "C1", 3, "She always has a witty reply.", "Elle a toujours une réplique spirituelle."],
  ["subtle", "subtil", "Quotidien", "C1", 3, "There's a subtle hint of lemon.", "Il y a une subtile note de citron."],
  ["flawless", "irréprochable", "Quotidien", "C1", 3, "Her English is flawless.", "Son anglais est irréprochable."],
  ["ruthless", "impitoyable", "Quotidien", "C1", 3, "The competition is ruthless.", "La compétition est impitoyable."],
  ["to soar", "monter en flèche", "Société", "C1", 3, "Prices have soared this year.", "Les prix ont monté en flèche cette année."],
  ["hindsight", "le recul a posteriori", "Quotidien", "C1", 3, "In hindsight, it was a bad idea.", "Avec le recul, c'était une mauvaise idée."],
  ["to grasp", "saisir / comprendre", "Quotidien", "C1", 3, "I finally grasped the concept.", "J'ai enfin saisi le concept."],
  ["fascinated", "fasciné", "Émotions", "C1", 3, "I'm fascinated by history.", "Je suis fasciné par l'histoire."],
  ["to foster", "encourager / développer", "Société", "C1", 3, "Games foster teamwork.", "Les jeux développent l'esprit d'équipe."],
  ["outrageous", "scandaleux", "Quotidien", "C1", 3, "The price is simply outrageous.", "Le prix est tout simplement scandaleux."],
  ["to convey", "transmettre / exprimer", "Quotidien", "C1", 3, "A smile conveys more than words.", "Un sourire transmet plus que des mots."],
  ["staggering", "stupéfiant", "Quotidien", "C1", 3, "The cost is staggering.", "Le coût est stupéfiant."],
  ["to alleviate", "soulager", "Quotidien", "C1", 3, "This tea will alleviate the pain.", "Ce thé va soulager la douleur."],
  ["feasible", "faisable", "Travail", "C1", 3, "Is this plan really feasible?", "Ce plan est-il vraiment faisable ?"],
  ["mundane", "banal / quotidien", "Quotidien", "C1", 3, "Even mundane tasks become fun together.", "Même les tâches banales deviennent funs à deux."],
  ["impeccable", "impeccable", "Quotidien", "C1", 3, "His taste in music is impeccable.", "Son goût musical est impeccable."],

  // ---------- C2 : la maîtrise ----------
  ["oblivious", "sans s'en rendre compte", "Quotidien", "C2", 3, "He was oblivious to the danger.", "Il ne se rendait pas compte du danger."],
  ["adamant", "inflexible", "Quotidien", "C2", 3, "She was adamant about her decision.", "Elle était inflexible sur sa décision."],
  ["to scrutinize", "passer au crible", "Quotidien", "C2", 3, "Experts scrutinized every detail.", "Les experts ont passé au crible chaque détail."],
  ["inevitable", "inéluctable", "Quotidien", "C2", 3, "Change is inevitable.", "Le changement est inéluctable."],
  ["plight", "le sort tragique", "Société", "C2", 3, "The film shows the plight of refugees.", "Le film montre le sort des réfugiés."],
  ["to succumb", "succomber", "Quotidien", "C2", 3, "I succumbed to the chocolate cake.", "J'ai succombé au gâteau au chocolat."],
  ["to dwindle", "fondre / diminuer", "Quotidien", "C2", 3, "Our savings are dwindling fast.", "Nos économies fondent rapidement."],
  ["quintessential", "archétypal", "Quotidien", "C2", 3, "It's the quintessential English village.", "C'est l'archétype du village anglais."],
  ["relentless", "implacable / incessant", "Quotidien", "C2", 3, "The relentless rain ruined the weekend.", "La pluie incessante a gâché le week-end."],
  ["to fathom", "cerner / comprendre", "Quotidien", "C2", 3, "I can't fathom why he left.", "Je n'arrive pas à cerner pourquoi il est parti."],

  // ---------- Phrasal verbs (natifs !) ----------
  ["to get up", "se lever", "Phrasal verbs", "A2", 1, "I get up at seven every day.", "Je me lève à sept heures chaque jour."],
  ["to wake up", "se réveiller", "Phrasal verbs", "A2", 1, "I woke up at seven today.", "Je me suis réveillé à sept heures aujourd'hui."],
  ["to calm down", "se calmer", "Phrasal verbs", "A2", 1, "Calm down, everything will be fine.", "Calme-toi, tout ira bien."],
  ["to watch out", "faire attention", "Phrasal verbs", "A2", 1, "Watch out, the floor is wet!", "Attention, le sol est mouillé !"],
  ["to check out", "regarder / découvrir", "Phrasal verbs", "A2", 1, "Check out this new game!", "Regarde ce nouveau jeu !"],
  ["to drop off", "déposer (qqn)", "Phrasal verbs", "A2", 1, "I'll drop you off at school.", "Je te dépose à l'école."],
  ["to give up", "abandonner", "Phrasal verbs", "B1", 2, "Never give up on your dreams.", "N'abandonne jamais tes rêves."],
  ["to look after", "s'occuper de", "Phrasal verbs", "B1", 2, "She looks after her little brother.", "Elle s'occupe de son petit frère."],
  ["to figure out", "comprendre / trouver", "Phrasal verbs", "B1", 2, "I can't figure out this puzzle.", "Je n'arrive pas à résoudre ce puzzle."],
  ["to run out of", "tomber à court de", "Phrasal verbs", "B1", 2, "We ran out of milk this morning.", "On est tombé à court de lait ce matin."],
  ["to look forward to", "avoir hâte de", "Phrasal verbs", "B1", 2, "I look forward to the holidays.", "J'ai hâte d'être en vacances."],
  ["to break down", "tomber en panne", "Phrasal verbs", "B1", 2, "Our car broke down yesterday.", "Notre voiture est tombée en panne hier."],
  ["to get along", "bien s'entendre", "Phrasal verbs", "B1", 2, "We get along really well.", "On s'entend vraiment bien."],
  ["to set up", "mettre en place", "Phrasal verbs", "B1", 2, "They set up a meeting for Friday.", "Ils ont mis en place une réunion pour vendredi."],
  ["to find out", "découvrir / apprendre", "Phrasal verbs", "B1", 2, "Find out when the train leaves.", "Renseigne-toi sur l'heure du train."],
  ["to look up", "chercher (un mot)", "Phrasal verbs", "B1", 2, "Look up the word in the dictionary.", "Cherche le mot dans le dictionnaire."],
  ["to carry on", "continuer", "Phrasal verbs", "B1", 2, "Carry on, you're doing great!", "Continue, tu t'en sors super bien !"],
  ["to work out", "faire du sport", "Phrasal verbs", "B1", 2, "I work out three times a week.", "Je fais du sport trois fois par semaine."],
  ["to pick up", "récupérer / aller chercher", "Phrasal verbs", "B1", 2, "Can you pick me up at eight?", "Tu peux passer me prendre à huit heures ?"],
  ["to hang out", "traîner / passer du temps", "Phrasal verbs", "B1", 2, "We hang out after class.", "On traîne ensemble après les cours."],
  ["to catch up", "prendre des nouvelles", "Phrasal verbs", "B1", 2, "Let's catch up over a coffee.", "Prenons un café pour nous raconter nos nouvelles."],
  ["to end up", "finir par", "Phrasal verbs", "B1", 2, "We ended up walking home.", "On a fini par rentrer à pied."],
  ["to show off", "frimer", "Phrasal verbs", "B1", 2, "Stop showing off, we get it!", "Arrête de frimer, on a compris !"],
  ["to hold on", "patienter", "Phrasal verbs", "B1", 2, "Hold on a second, please.", "Patiente une seconde, s'il te plaît."],
  ["to put off", "reporter à plus tard", "Phrasal verbs", "B2", 2, "Don't put off your homework.", "Ne repousse pas tes devoirs à plus tard."],
  ["to get over", "se remettre de", "Phrasal verbs", "B2", 2, "It took months to get over the flu.", "Il a mis des mois à se remettre de la grippe."],
  ["to come across", "tomber (sur qqn/qqch)", "Phrasal verbs", "B2", 2, "I came across an old photo.", "Je suis tombé sur une vieille photo."],
  ["to turn down", "refuser (une offre)", "Phrasal verbs", "B2", 2, "She turned down the job offer.", "Elle a refusé l'offre d'emploi."],
  ["to bring up", "aborder (un sujet)", "Phrasal verbs", "B2", 2, "He brought up an interesting point.", "Il a abordé un point intéressant."],
  ["to go through", "traverser (épreuve)", "Phrasal verbs", "B2", 2, "She's going through a hard time.", "Elle traverse une période difficile."],
  ["to take up", "se mettre à (activité)", "Phrasal verbs", "B2", 2, "I took up running last year.", "Je m'y suis mis à la course l'an dernier."],
  ["to put up with", "supporter / tolérer", "Phrasal verbs", "B2", 2, "I can't put up with this noise.", "Je ne peux plus supporter ce bruit."],
  ["to make up", "inventer (une histoire)", "Phrasal verbs", "B2", 2, "He made up a funny excuse.", "Il a inventé une excuse hilarante."],

  // ---------- Expressions natives & idioms ----------
  ["a piece of cake", "du gâteau (très facile)", "Expressions natives", "B2", 2, "The exam was a piece of cake.", "L'examen était du gâteau."],
  ["break a leg", "bonne chance !", "Expressions natives", "B2", 2, "Break a leg at your audition!", "Bonne chance pour ton audition !"],
  ["under the weather", "patraque / malade", "Expressions natives", "B2", 2, "I'm feeling a bit under the weather.", "Je me sens un peu patraque."],
  ["once in a blue moon", "très rarement", "Expressions natives", "B2", 2, "He calls me once in a blue moon.", "Il m'appelle une fois tous les 36 du mois."],
  ["to spill the beans", "vendre la mèche", "Expressions natives", "B2", 2, "Come on, spill the beans!", "Allez, vends la mèche !"],
  ["to hit the nail on the head", "mettre le doigt dessus", "Expressions natives", "B2", 2, "You hit the nail on the head.", "Tu as mis le doigt dessus."],
  ["to cost an arm and a leg", "coûter les yeux de la tête", "Expressions natives", "B2", 2, "This phone cost an arm and a leg.", "Ce téléphone a coûté les yeux de la tête."],
  ["to bite the bullet", "serrer les dents", "Expressions natives", "B2", 2, "I bit the bullet and called the bank.", "J'ai serré les dents et appelé la banque."],
  ["the ball is in your court", "à toi de jouer", "Expressions natives", "B2", 2, "I made an offer — the ball is in your court.", "J'ai fait une offre — à toi de jouer."],
  ["to hit the sack", "aller se coucher", "Expressions natives", "B2", 2, "I'm exhausted, time to hit the sack.", "Je suis épuisé, c'est l'heure d'aller me coucher."],
  ["on cloud nine", "aux anges", "Expressions natives", "B2", 2, "She's been on cloud nine since Monday.", "Elle est aux anges depuis lundi."],
  ["it's raining cats and dogs", "il pleut des cordes", "Expressions natives", "B1", 2, "It's raining cats and dogs outside!", "Il pleut des cordes dehors !"],
  ["to beat around the bush", "tourner autour du pot", "Expressions natives", "B2", 2, "Stop beating around the bush!", "Arrête de tourner autour du pot !"],
  ["speak of the devil", "quand on parle du loup", "Expressions natives", "B1", 2, "Speak of the devil, here he comes!", "Quand on parle du loup, le voilà !"],
  ["to be broke", "être fauché", "Expressions natives", "B2", 2, "I can't come out, I'm broke.", "Je ne peux pas sortir, je suis fauché."],
  ["hang in there", "accroche-toi", "Expressions natives", "B1", 2, "Hang in there, exams are almost over!", "Accroche-toi, les examens sont bientôt finis !"],
  ["you bet", "et comment ! / tu parles", "Expressions natives", "B1", 2, "«Was it fun?» «You bet!»", "« C'était bien ? » « Tu parles ! »"],
  ["no biggie", "pas grave", "Expressions natives", "B1", 2, "No biggie, it happens to everyone.", "Pas grave, ça arrive à tout le monde."],
  ["to be kidding", "plaisanter", "Expressions natives", "B1", 2, "You're kidding me, right?", "Tu plaisantes, là ?"],
  ["for real?", "sérieux ?", "Expressions natives", "B1", 2, "You won the lottery? For real?", "T'as gagné au loto ? Sérieux ?"],
  ["to chill", "se détendre / traîner", "Expressions natives", "B1", 2, "Let's just chill tonight.", "On va juste se détendre ce soir."],
  ["to hit the road", "prendre la route", "Expressions natives", "B2", 2, "It's late — let's hit the road.", "Il est tard — prenons la route."],
  ["to call it a day", "s'arrêter là", "Expressions natives", "B2", 2, "Good work, let's call it a day.", "Bon travail, on s'arrête là pour aujourd'hui."],
  ["long story short", "bref / en deux mots", "Expressions natives", "C1", 3, "Long story short: we missed the flight.", "Bref : on a raté l'avion."],
  ["no strings attached", "sans conditions", "Expressions natives", "C1", 3, "The job comes with no strings attached.", "Le boulot est sans conditions cachées."],
  ["a blessing in disguise", "un mal pour un bien", "Expressions natives", "C1", 3, "Losing that job was a blessing in disguise.", "Perdre ce travail était un mal pour un bien."],
  ["that ship has sailed", "c'est trop tard / l'occasion est passée", "Expressions natives", "C1", 3, "I wanted to apply, but that ship has sailed.", "Je voulais postuler, mais l'occasion est passée."],
];


type TextRow = { title: string; content: string; cefr: string; difficulty: number };

const TEXTS: TextRow[] = [
  {
    title: "Emma's Morning",
    cefr: "A1",
    difficulty: 1,
    content:
      "Emma wakes up at seven o'clock every morning. She drinks a big cup of coffee and eats some bread with cheese. At eight, she takes the bus to the hospital. Emma is a nurse. She loves her job because she helps people every day. In the evening, she is tired but happy.",
  },
  {
    title: "A Weekend by the Sea",
    cefr: "A1",
    difficulty: 1,
    content:
      "On Saturday, Tom and his friends drive to the sea. The weather is sunny and warm. In the morning, they swim and play games on the beach. At noon, they eat a picnic: sandwiches, apples and cold lemonade. In the afternoon, Tom reads a book under a big umbrella. They go home at six. Everyone is tired, and everyone is happy.",
  },
  {
    title: "The Little Café",
    cefr: "A2",
    difficulty: 2,
    content:
      "There is a new café in town called 'The Blue Door'. It is small but very popular. The owner, Mrs. Clark, makes all the cakes herself every morning. People love her chocolate cake and her lemon pie. The café is open from Tuesday to Sunday, and it is always full at four o'clock, thanks to the students from the school next door. 'I never planned to cook for a living,' says Mrs. Clark, 'but now I can't imagine another job.'",
  },
  {
    title: "Learning to Cook",
    cefr: "B1",
    difficulty: 2,
    content:
      "When Ben moved to London for his studies, he ate fast food every day. One evening, he called his grandmother, and she gave him three easy recipes on the phone. The first week was a disaster: the rice was black and the chicken was still cold in the middle. But Ben did not stop. After two months of practice, he could cook a good dinner for six friends. 'Now,' he says, 'I only buy fast food once a month — when I'm too tired to cook.'",
  },
  {
    title: "The Night Market",
    cefr: "B2",
    difficulty: 3,
    content:
      "The night market in Taipei is a feast for the senses. Hundreds of tiny stalls glow under strings of red lanterns, and the air smells of fried dumplings, sweet mango ice and grilled squid. Visitors bargain loudly with shopkeepers, who always seem to win in the end. Local guides recommend arriving hungry and leaving your scooter outside: the narrow lanes are far too crowded for anything but your own two feet. Despite the chaos, regulars insist the market is the most peaceful place in the city — 'Here,' one vendor laughs, 'everyone is too busy eating to be angry.'",
  },
  {
    title: "The Vanishing Voices",
    cefr: "C1",
    difficulty: 3,
    content:
      "Of the roughly seven thousand languages spoken on Earth today, linguists estimate that nearly half could disappear within a century. When a language dies, humanity loses far more than words: it loses jokes that cannot be translated, songs carried across generations, and precise knowledge of local plants and weather. In New Zealand, the Māori language was once banned in schools; today it is taught again, sung in playgrounds and heard on national radio. Technology now plays a double role — the internet flattens cultures, yet it also lets elders record bedtime stories for grandchildren they may never meet. 'Every language,' one researcher says, 'is a unique answer to the question of what it means to be human.'",
  },
];

type QuestionRow = {
  textIndex: number;
  question: string;
  options: string[];
  answerIndex: number;
};

const QUESTIONS: QuestionRow[] = [
  // Emma (A1) — questions en français
  { textIndex: 0, question: "Que boit Emma le matin ?", options: ["Du café", "Du thé", "Du jus d'orange", "De l'eau"], answerIndex: 0 },
  { textIndex: 0, question: "Où travaille Emma ?", options: ["Dans un hôpital", "Dans une école", "Dans un restaurant", "Dans un bureau"], answerIndex: 0 },
  { textIndex: 0, question: "Comment se sent Emma le soir ?", options: ["Fatiguée mais heureuse", "Malade", "Triste et seule", "En colère"], answerIndex: 0 },
  // Sea weekend (A1)
  { textIndex: 1, question: "Quel temps fait-il samedi ?", options: ["Ensoleillé et chaud", "Froid et pluvieux", "Il neige", "Orageux"], answerIndex: 0 },
  { textIndex: 1, question: "Que font Tom et ses amis le matin ?", options: ["Ils nagent et jouent sur la plage", "Ils dorment à l'hôtel", "Ils font les magasins", "Ils partent pêcher"], answerIndex: 0 },
  { textIndex: 1, question: "Que fait Tom l'après-midi ?", options: ["Il lit sous un parasol", "Il fait du surf", "Il fait la sieste", "Il prépare le dîner"], answerIndex: 0 },
  // Café (A2)
  { textIndex: 2, question: "Pourquoi le café est-il si populaire ?", options: ["Pour ses gâteaux faits maison", "Pour ses petits prix", "Pour sa grande terrasse", "Pour sa musique live"], answerIndex: 0 },
  { textIndex: 2, question: "Quel jour le café est-il fermé ?", options: ["Le lundi", "Le dimanche", "Le samedi", "Il ne ferme jamais"], answerIndex: 0 },
  { textIndex: 2, question: "Que dit Mme Clark de son métier ?", options: ["Elle ne peut pas imaginer un autre métier", "Elle veut tout arrêter", "Elle déteste cuisiner", "Elle cherche un associé"], answerIndex: 0 },
  { textIndex: 2, question: "Comment s'appelle le café ?", options: ["The Blue Door", "The Red Cup", "Clark's Place", "The Little Cake"], answerIndex: 0 },
  // Ben (B1)
  { textIndex: 3, question: "Pourquoi Ben a-t-il déménagé à Londres ?", options: ["Pour ses études", "Pour un travail", "Pour sa famille", "Pour le beau temps"], answerIndex: 0 },
  { textIndex: 3, question: "Qui aide Ben à apprendre la cuisine ?", options: ["Sa grand-mère", "Son meilleur ami", "Un grand chef", "Personne"], answerIndex: 0 },
  { textIndex: 3, question: "Que s'est-il passé la première semaine ?", options: ["Un désastre", "Un succès total", "Il a invité des amis", "Il a jeté les recettes"], answerIndex: 0 },
  { textIndex: 3, question: "Combien de fois par mois Ben achète-t-il du fast-food maintenant ?", options: ["Une fois", "Trois fois", "Jamais", "Tous les jours"], answerIndex: 0 },
  // Night market (B2)
  { textIndex: 4, question: "Pourquoi laisser son scooter dehors ?", options: ["Les ruelles sont trop bondées", "Le stationnement coûte cher", "C'est interdit la nuit", "Il n'y a pas de parking"], answerIndex: 0 },
  { textIndex: 4, question: "Que trouve-t-on dans l'air du marché ?", options: ["Des odeurs de nourriture variées", "De la fumée de cigarettes", "Le parfum des fleurs", "L'odeur de la pluie"], answerIndex: 0 },
  { textIndex: 4, question: "Selon les habitués, pourquoi le marché est-il paisible ?", options: ["Tout le monde est occupé à manger", "Il n'y a personne", "La musique est douce", "La police surveille tout"], answerIndex: 0 },
  // Vanishing voices (C1) — questions EN ANGLAIS pour corser
  { textIndex: 5, question: "What do we lose when a language dies?", options: ["Culture, knowledge and unique jokes", "Only a few rare words", "Nothing important", "International trade"], answerIndex: 0 },
  { textIndex: 5, question: "What happened to the Māori language in schools?", options: ["It was banned, then taught again", "It was always mandatory", "It replaced English", "It disappeared completely"], answerIndex: 0 },
  { textIndex: 5, question: "What is the 'double role' of technology?", options: ["It flattens cultures but can preserve languages", "It only destroys languages", "It translates everything perfectly", "It creates new languages"], answerIndex: 0 },
  { textIndex: 5, question: "According to the researcher, what is every language?", options: ["A unique answer to what it means to be human", "A tool for business", "A barrier to progress", "A list of grammar rules"], answerIndex: 0 },
];

/** Idempotent seed: fills tables only when empty. */
export async function ensureSeeded() {
  const existingProfile = await db
    .select({ id: profiles.id })
    .from(profiles)
    .limit(1);

  if (existingProfile.length === 0) {
    await db.insert(profiles).values({ id: 1, name: "Joueur" });
  }

  const existingWords = await db.select({ id: words.id }).from(words).limit(1);
  if (existingWords.length > 0) return;

  await db.insert(words).values(
    WORDS.map(([en, fr, category, cefr, difficulty, exampleEn, exampleFr]) => ({
      en,
      fr,
      category,
      cefr,
      difficulty,
      exampleEn,
      exampleFr,
    })),
  );

  await db.insert(grammarExercises).values(
    toDbRows().map((r) => ({
      ...r,
      topic: findLesson(r.lessonSlug)?.lesson.title ?? r.lessonSlug,
    })),
  );

  for (let i = 0; i < TEXTS.length; i++) {
    const t = TEXTS[i];
    const [inserted] = await db
      .insert(comprehensionTexts)
      .values({ title: t.title, content: t.content, cefr: t.cefr, difficulty: t.difficulty })
      .returning({ id: comprehensionTexts.id });

    const qs = QUESTIONS.filter((q) => q.textIndex === i).map((q) => ({
      textId: inserted.id,
      question: q.question,
      options: q.options,
      answerIndex: q.answerIndex,
    }));
    if (qs.length > 0) {
      await db.insert(comprehensionQuestions).values(qs);
    }
  }
}
