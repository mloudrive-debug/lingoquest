/**
 * Cours de grammaire anglaise complet.
 * Structure inspirée du guide de référence EF (Nouns, Adjectives, Adverbs,
 * Determiners, Verbs & verb tenses, Speech, Relative clauses, Punctuation)
 * — expliqué en français, avec exemples, pièges et règles express.
 */

export type Example = { en: string; fr: string };

export type LessonSection = {
  heading: string;
  body?: string;
  examples?: Example[];
  table?: { head: string[]; rows: string[][] };
};

export type Lesson = {
  slug: string;
  title: string;
  titleEn: string;
  cefr: "A1" | "A2" | "B1" | "B2" | "C1" | "C2";
  minutes: number;
  summary: string;
  sections: LessonSection[];
  rules: string[];
  pitfalls: { wrong: string; right: string; why: string }[];
};

export type Category = {
  slug: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  lessons: Lesson[];
};

export const GRAMMAR_COURSE: Category[] = [
  /* ================================================================== */
  {
    slug: "verbs-present",
    name: "Le présent",
    icon: "Play",
    color: "#8b7cff",
    description: "Parler de maintenant, des habitudes et des vérités générales.",
    lessons: [
      {
        slug: "simple-present",
        title: "Le présent simple",
        titleEn: "Simple present tense",
        cefr: "A1",
        minutes: 6,
        summary:
          "Le temps des habitudes, des vérités générales et des programmes fixes. Le piège : le « s » de la 3ᵉ personne.",
        sections: [
          {
            heading: "Quand l'utiliser",
            body: "Le présent simple décrit ce qui est habituel, permanent ou toujours vrai. Il ne décrit pas ce qui se passe à l'instant même (ça, c'est le présent continu).",
            examples: [
              { en: "I work in a hospital.", fr: "Je travaille dans un hôpital. (situation permanente)" },
              { en: "Water boils at 100 °C.", fr: "L'eau bout à 100 °C. (vérité générale)" },
              { en: "The train leaves at 6 p.m.", fr: "Le train part à 18 h. (horaire fixe)" },
            ],
          },
          {
            heading: "La conjugaison",
            body: "C'est la base verbale partout… sauf à la 3ᵉ personne du singulier (he, she, it) où on ajoute -s.",
            table: {
              head: ["Personne", "Affirmatif", "Négatif", "Question"],
              rows: [
                ["I / you / we / they", "work", "don't work", "Do you work?"],
                ["he / she / it", "works", "doesn't work", "Does he work?"],
              ],
            },
          },
          {
            heading: "Les variantes du -s",
            body: "Verbes en -o, -ch, -sh, -ss, -x → on ajoute -es. Verbes en consonne + y → y devient -ies.",
            examples: [
              { en: "go → he goes · watch → she watches", fr: "aller → il va · regarder → elle regarde" },
              { en: "study → he studies · fly → it flies", fr: "étudier → il étudie · voler → ça vole" },
            ],
          },
          {
            heading: "Les adverbes de fréquence",
            body: "always, usually, often, sometimes, rarely, never se placent AVANT le verbe principal, mais APRÈS le verbe « to be ».",
            examples: [
              { en: "She often works late.", fr: "Elle travaille souvent tard." },
              { en: "He is always late.", fr: "Il est toujours en retard." },
            ],
          },
        ],
        rules: [
          "He / she / it → le verbe prend -s",
          "Négation et question avec do / does + base verbale",
          "Après « does », le verbe perd son -s : Does she work? (jamais « works »)",
        ],
        pitfalls: [
          { wrong: "She work in Paris.", right: "She works in Paris.", why: "3ᵉ personne du singulier : -s obligatoire." },
          { wrong: "Does she works?", right: "Does she work?", why: "Le -s est déjà porté par « does »." },
          { wrong: "I am work every day.", right: "I work every day.", why: "Pas de « be » devant un présent simple." },
        ],
      },
      {
        slug: "present-continuous",
        title: "Le présent continu",
        titleEn: "Present continuous tense",
        cefr: "A1",
        minutes: 6,
        summary:
          "L'action en train de se dérouler, le temporaire, et… le futur planifié. Formé avec be + verbe-ing.",
        sections: [
          {
            heading: "Formation",
            body: "am / is / are + verbe + -ing. C'est tout.",
            examples: [
              { en: "I am reading a book.", fr: "Je suis en train de lire un livre." },
              { en: "They aren't listening.", fr: "Ils n'écoutent pas." },
              { en: "Is she working today?", fr: "Est-ce qu'elle travaille aujourd'hui ?" },
            ],
          },
          {
            heading: "Trois emplois",
            body: "1) Action en cours maintenant. 2) Situation temporaire. 3) Projet futur déjà organisé.",
            examples: [
              { en: "Look! It's raining.", fr: "Regarde ! Il pleut. (maintenant)" },
              { en: "I'm living with my parents this year.", fr: "J'habite chez mes parents cette année. (temporaire)" },
              { en: "We're meeting Paul tomorrow.", fr: "On voit Paul demain. (prévu)" },
            ],
          },
          {
            heading: "Orthographe du -ing",
            body: "On supprime le -e final (make → making). On double la consonne finale après une voyelle courte accentuée (sit → sitting, run → running).",
          },
          {
            heading: "Les verbes d'état (state verbs)",
            body: "Certains verbes ne se mettent presque jamais en -ing : like, love, hate, want, need, know, believe, understand, belong, seem, prefer.",
            examples: [
              { en: "I know the answer.", fr: "Je connais la réponse. (pas « I am knowing »)" },
              { en: "She wants a coffee.", fr: "Elle veut un café." },
            ],
          },
        ],
        rules: [
          "be + verbe-ing",
          "Action en cours, situation temporaire, ou futur organisé",
          "Les state verbs (know, want, like…) restent au présent simple",
        ],
        pitfalls: [
          { wrong: "I am knowing him.", right: "I know him.", why: "« Know » est un verbe d'état." },
          { wrong: "She is work now.", right: "She is working now.", why: "Le -ing est obligatoire après be." },
          { wrong: "I reading a book.", right: "I'm reading a book.", why: "L'auxiliaire be ne se supprime jamais." },
        ],
      },
      {
        slug: "present-perfect",
        title: "Le present perfect",
        titleEn: "Present perfect tense",
        cefr: "B1",
        minutes: 8,
        summary:
          "Le temps préféré des anglophones, et la bête noire des francophones : un passé qui compte encore maintenant.",
        sections: [
          {
            heading: "Formation",
            body: "have / has + participe passé (le fameux « 3ᵉ colonne » : seen, done, been, gone, written…).",
            examples: [
              { en: "I have finished my homework.", fr: "J'ai fini mes devoirs." },
              { en: "She has never been to Japan.", fr: "Elle n'est jamais allée au Japon." },
            ],
          },
          {
            heading: "La logique : le lien avec le présent",
            body: "On utilise le present perfect quand le passé a un effet visible maintenant, ou quand la période n'est pas terminée. Si on précise QUAND c'est arrivé (yesterday, in 2010, last week), on bascule au prétérit.",
            examples: [
              { en: "I have lost my keys. (je ne les ai toujours pas)", fr: "J'ai perdu mes clés." },
              { en: "I lost my keys yesterday. (moment précis → prétérit)", fr: "J'ai perdu mes clés hier." },
            ],
          },
          {
            heading: "Since et for",
            body: "SINCE + point de départ (since 2015, since Monday). FOR + durée (for three years, for ten minutes).",
            examples: [
              { en: "I have lived here since 2015.", fr: "J'habite ici depuis 2015." },
              { en: "I have lived here for ten years.", fr: "J'habite ici depuis dix ans." },
            ],
          },
          {
            heading: "Les mots qui l'accompagnent",
            body: "already (déjà), yet (encore / déjà en question et négation), just (à l'instant), ever / never, so far, recently.",
            examples: [
              { en: "I've already eaten.", fr: "J'ai déjà mangé." },
              { en: "Have you finished yet?", fr: "Tu as fini ?" },
              { en: "He has just left.", fr: "Il vient de partir." },
            ],
          },
          {
            heading: "Attention au français « depuis »",
            body: "En français on dit « j'habite ici depuis 10 ans » (présent). En anglais il FAUT le present perfect : I have lived / I have been living.",
          },
        ],
        rules: [
          "have / has + participe passé",
          "Jamais avec une date passée précise (yesterday, last year, in 2010 → prétérit)",
          "since + point de départ · for + durée",
        ],
        pitfalls: [
          { wrong: "I live here since 2015.", right: "I have lived here since 2015.", why: "« Depuis » + action qui continue = present perfect." },
          { wrong: "I have seen him yesterday.", right: "I saw him yesterday.", why: "Date précise au passé → prétérit." },
          { wrong: "She has went home.", right: "She has gone home.", why: "Participe passé de go = gone, pas went." },
        ],
      },
      {
        slug: "present-perfect-continuous",
        title: "Le present perfect continu",
        titleEn: "Present perfect continuous",
        cefr: "B2",
        minutes: 6,
        summary:
          "Insiste sur la durée de l'activité, pas sur son résultat : have been + verbe-ing.",
        sections: [
          {
            heading: "Formation et sens",
            body: "have / has been + verbe-ing. Il souligne qu'une activité dure depuis un moment (et souvent continue).",
            examples: [
              { en: "I have been waiting for an hour.", fr: "J'attends depuis une heure." },
              { en: "She's been studying all night.", fr: "Elle étudie depuis toute la nuit." },
            ],
          },
          {
            heading: "Différence avec le present perfect simple",
            body: "Le simple insiste sur le RÉSULTAT fini ; le continu sur l'ACTIVITÉ et sa durée.",
            examples: [
              { en: "I've painted the kitchen. (fini, c'est propre)", fr: "J'ai repeint la cuisine." },
              { en: "I've been painting the kitchen. (j'en ai plein les mains)", fr: "Je repeins la cuisine depuis un moment." },
            ],
          },
        ],
        rules: [
          "have / has been + verbe-ing",
          "Insiste sur la durée, souvent avec for / since / all day / lately",
          "Pas avec les state verbs (know, be, like…)",
        ],
        pitfalls: [
          { wrong: "I have been knowing her for years.", right: "I have known her for years.", why: "« Know » est un verbe d'état." },
          { wrong: "I am waiting since 2 p.m.", right: "I have been waiting since 2 p.m.", why: "« Depuis » exige le present perfect." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "verbs-past",
    name: "Le passé",
    icon: "History",
    color: "#ff5ca8",
    description: "Raconter des événements terminés, des souvenirs et des retours en arrière.",
    lessons: [
      {
        slug: "simple-past",
        title: "Le prétérit (passé simple)",
        titleEn: "Simple past tense",
        cefr: "A2",
        minutes: 7,
        summary:
          "Le temps du récit : une action terminée, à un moment identifié du passé.",
        sections: [
          {
            heading: "Formation",
            body: "Verbes réguliers : base + -ed (worked, played, lived). Verbes irréguliers : forme à apprendre (go → went, see → saw, buy → bought).",
            table: {
              head: ["Forme", "Exemple"],
              rows: [
                ["Affirmatif", "She worked late. / He went home."],
                ["Négatif", "She didn't work late. (didn't + base verbale)"],
                ["Question", "Did she work late?"],
              ],
            },
          },
          {
            heading: "Le piège du DID",
            body: "Dès que « did » apparaît, le verbe principal revient à sa base : didn't go (pas didn't went), Did you see? (pas Did you saw?).",
            examples: [
              { en: "I didn't see him.", fr: "Je ne l'ai pas vu." },
              { en: "Did you eat?", fr: "Tu as mangé ?" },
            ],
          },
          {
            heading: "Les marqueurs temporels",
            body: "yesterday, last night, two days ago, in 2010, when I was a child → tous appellent le prétérit.",
          },
        ],
        rules: [
          "Réguliers : -ed · Irréguliers : à mémoriser",
          "Négation et question : did / didn't + base verbale",
          "Toujours avec un moment passé identifié (même implicite)",
        ],
        pitfalls: [
          { wrong: "I didn't went.", right: "I didn't go.", why: "Après did, base verbale." },
          { wrong: "I have seen him last week.", right: "I saw him last week.", why: "« Last week » = moment précis." },
          { wrong: "He buyed a car.", right: "He bought a car.", why: "« Buy » est irrégulier." },
        ],
      },
      {
        slug: "past-continuous",
        title: "Le passé continu",
        titleEn: "Past continuous tense",
        cefr: "B1",
        minutes: 5,
        summary:
          "Le décor d'une scène passée : une action en cours interrompue par une autre.",
        sections: [
          {
            heading: "Formation et usage",
            body: "was / were + verbe-ing. Il plante le décor ; le prétérit apporte l'événement qui l'interrompt.",
            examples: [
              { en: "I was reading when she arrived.", fr: "Je lisais quand elle est arrivée." },
              { en: "They were sleeping at midnight.", fr: "Ils dormaient à minuit." },
            ],
          },
          {
            heading: "La combinaison classique",
            body: "WHILE + passé continu (le fond) · WHEN + prétérit (l'événement).",
            examples: [
              { en: "While I was cooking, the phone rang.", fr: "Pendant que je cuisinais, le téléphone a sonné." },
            ],
          },
        ],
        rules: ["was / were + verbe-ing", "Action longue interrompue par une action courte au prétérit"],
        pitfalls: [
          { wrong: "I was read when she came.", right: "I was reading when she came.", why: "-ing obligatoire." },
          { wrong: "While I cooked, the phone was ringing.", right: "While I was cooking, the phone rang.", why: "Le fond est au continu, l'événement au prétérit." },
        ],
      },
      {
        slug: "past-perfect",
        title: "Le past perfect (plus-que-parfait)",
        titleEn: "Past perfect tense",
        cefr: "B2",
        minutes: 6,
        summary: "Le passé du passé : ce qui s'était déjà produit avant un autre moment passé.",
        sections: [
          {
            heading: "Formation",
            body: "had + participe passé, pour toutes les personnes.",
            examples: [
              { en: "When I arrived, she had already left.", fr: "Quand je suis arrivé, elle était déjà partie." },
              { en: "I had never seen snow before that trip.", fr: "Je n'avais jamais vu la neige avant ce voyage." },
            ],
          },
          {
            heading: "Pourquoi c'est utile",
            body: "Il remet deux événements passés dans l'ordre : celui au past perfect est le plus ancien.",
          },
        ],
        rules: ["had + participe passé", "Marque l'antériorité par rapport à un autre fait passé"],
        pitfalls: [
          { wrong: "When I arrived, she already left.", right: "When I arrived, she had already left.", why: "Antériorité → past perfect." },
          { wrong: "I had went there.", right: "I had gone there.", why: "Participe passé de go = gone." },
        ],
      },
      {
        slug: "used-to",
        title: "Used to, would et be used to",
        titleEn: "Used to / would / be used to",
        cefr: "B1",
        minutes: 5,
        summary: "Trois structures proches qui piègent tout le monde — habitudes passées vs. habitude acquise.",
        sections: [
          {
            heading: "USED TO : l'habitude passée révolue",
            body: "used to + base verbale = « avant, je… (mais plus maintenant) ».",
            examples: [
              { en: "I used to smoke.", fr: "Je fumais (avant, plus maintenant)." },
              { en: "Did you use to live here?", fr: "Tu habitais ici avant ?" },
            ],
          },
          {
            heading: "WOULD : les souvenirs répétés",
            body: "would + base verbale raconte une habitude passée, mais seulement pour des actions (pas des états).",
            examples: [
              { en: "Every summer we would go to the lake.", fr: "Chaque été, on allait au lac." },
            ],
          },
          {
            heading: "BE USED TO : être habitué à",
            body: "be / get used to + nom ou verbe-ing = être / devenir habitué à quelque chose. Rien à voir avec le passé !",
            examples: [
              { en: "I'm used to getting up early.", fr: "J'ai l'habitude de me lever tôt." },
              { en: "She got used to the noise.", fr: "Elle s'est habituée au bruit." },
            ],
          },
        ],
        rules: [
          "used to + base = habitude passée terminée",
          "be used to + -ing = être habitué à",
          "Après « did », on écrit « use to » sans -d",
        ],
        pitfalls: [
          { wrong: "I'm used to get up early.", right: "I'm used to getting up early.", why: "Après « used to » (habitué), on met -ing." },
          { wrong: "I used to be living there.", right: "I used to live there.", why: "used to + base verbale simple." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "verbs-future",
    name: "Le futur",
    icon: "Rocket",
    color: "#5cd2ff",
    description: "Prédire, promettre, planifier : quatre façons de parler du futur.",
    lessons: [
      {
        slug: "future-will-going-to",
        title: "Will, be going to et présent continu",
        titleEn: "Simple future & going to",
        cefr: "A2",
        minutes: 7,
        summary:
          "L'anglais n'a pas un futur, mais plusieurs — le bon choix dépend de l'intention.",
        sections: [
          {
            heading: "WILL : décision spontanée, promesse, prédiction",
            body: "will + base verbale. On le choisit quand on décide sur le moment ou qu'on fait une prévision d'opinion.",
            examples: [
              { en: "The phone is ringing — I'll get it!", fr: "Le téléphone sonne — j'y vais !" },
              { en: "I think it will rain tomorrow.", fr: "Je pense qu'il pleuvra demain." },
            ],
          },
          {
            heading: "BE GOING TO : intention et indice visible",
            body: "Un projet déjà décidé, ou une prédiction basée sur ce qu'on observe.",
            examples: [
              { en: "I'm going to study medicine.", fr: "Je vais étudier la médecine. (décidé)" },
              { en: "Look at those clouds — it's going to rain.", fr: "Regarde ces nuages — il va pleuvoir." },
            ],
          },
          {
            heading: "Présent continu : rendez-vous fixé",
            body: "Un arrangement avec une date, une heure, d'autres personnes impliquées.",
            examples: [{ en: "I'm meeting the dentist at 3.", fr: "Je vois le dentiste à 15 h." }],
          },
          {
            heading: "Après when, if, as soon as : jamais de WILL",
            body: "Dans les subordonnées de temps et de condition, le futur se dit au présent.",
            examples: [
              { en: "I'll call you when I arrive.", fr: "Je t'appellerai quand j'arriverai." },
              { en: "If it rains, we'll stay home.", fr: "S'il pleut, on restera à la maison." },
            ],
          },
        ],
        rules: [
          "will = spontané / promesse / prédiction d'opinion",
          "be going to = intention décidée ou indice visible",
          "Après when, if, as soon as, until → présent, pas de will",
        ],
        pitfalls: [
          { wrong: "I'll call you when I will arrive.", right: "I'll call you when I arrive.", why: "Pas de will après « when » temporel." },
          { wrong: "I will to help you.", right: "I will help you.", why: "Pas de « to » après un modal." },
        ],
      },
      {
        slug: "future-perfect-continuous",
        title: "Futur antérieur et futur continu",
        titleEn: "Future perfect & future continuous",
        cefr: "C1",
        minutes: 6,
        summary: "Se projeter : ce qui sera en cours, et ce qui sera déjà accompli.",
        sections: [
          {
            heading: "Futur continu : will be + -ing",
            body: "Une action qui sera en cours à un moment futur précis.",
            examples: [
              { en: "This time tomorrow I'll be flying to Rome.", fr: "Demain à cette heure-ci, je serai en vol pour Rome." },
            ],
          },
          {
            heading: "Futur antérieur : will have + participe",
            body: "Une action qui sera terminée avant un repère futur (souvent avec « by »).",
            examples: [
              { en: "By June I will have finished the course.", fr: "D'ici juin, j'aurai terminé la formation." },
            ],
          },
          {
            heading: "Futur antérieur continu : will have been + -ing",
            body: "Insiste sur la durée accumulée jusqu'à un moment futur.",
            examples: [
              { en: "By 2030 she will have been teaching for twenty years.", fr: "En 2030, elle enseignera depuis vingt ans." },
            ],
          },
        ],
        rules: ["will be + -ing (en cours)", "will have + participe (accompli)", "« by + date » appelle le futur antérieur"],
        pitfalls: [
          { wrong: "By June I will finish.", right: "By June I will have finished.", why: "« By » = date butoir → futur antérieur." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "conditionals",
    name: "Conditionnels & hypothèses",
    icon: "GitBranch",
    color: "#a3e635",
    description: "Les quatre conditionnels, les mixtes, wish et if only.",
    lessons: [
      {
        slug: "conditionals-0-1",
        title: "Conditionnels 0 et 1",
        titleEn: "Zero & first conditional",
        cefr: "B1",
        minutes: 6,
        summary: "Le réel : ce qui est toujours vrai, et ce qui arrivera probablement.",
        sections: [
          {
            heading: "Conditionnel 0 — la vérité générale",
            body: "If + présent, présent. Une loi, une réaction automatique.",
            examples: [
              { en: "If you heat ice, it melts.", fr: "Si on chauffe la glace, elle fond." },
            ],
          },
          {
            heading: "Conditionnel 1 — le futur probable",
            body: "If + présent, will + base verbale.",
            examples: [
              { en: "If it rains, we will stay home.", fr: "S'il pleut, nous resterons à la maison." },
              { en: "If you study, you'll pass.", fr: "Si tu travailles, tu réussiras." },
            ],
          },
          {
            heading: "Unless = if not",
            body: "« Unless » signifie « sauf si / à moins que » et se construit avec une phrase affirmative.",
            examples: [
              { en: "You'll fail unless you work.", fr: "Tu échoueras à moins de travailler." },
            ],
          },
        ],
        rules: ["If + présent → présent (vérité) ou will (futur probable)", "Jamais « will » dans la partie « if »"],
        pitfalls: [
          { wrong: "If it will rain, we'll stay.", right: "If it rains, we'll stay.", why: "Pas de will après if." },
        ],
      },
      {
        slug: "conditionals-2-3-mixed",
        title: "Conditionnels 2, 3 et mixtes",
        titleEn: "Second, third & mixed conditionals",
        cefr: "B2",
        minutes: 8,
        summary: "L'irréel : le rêve présent, le regret passé, et leur combinaison.",
        sections: [
          {
            heading: "Conditionnel 2 — l'irréel du présent",
            body: "If + prétérit, would + base. On imagine une situation différente de la réalité. Avec « be », on utilise WERE à toutes les personnes dans le registre soigné.",
            examples: [
              { en: "If I were rich, I would travel the world.", fr: "Si j'étais riche, je voyagerais dans le monde entier." },
              { en: "If I had more time, I'd learn the piano.", fr: "Si j'avais plus de temps, j'apprendrais le piano." },
            ],
          },
          {
            heading: "Conditionnel 3 — le regret du passé",
            body: "If + past perfect, would have + participe passé. Ce qui ne s'est pas produit.",
            examples: [
              { en: "If she had studied, she would have passed.", fr: "Si elle avait travaillé, elle aurait réussi." },
            ],
          },
          {
            heading: "Conditionnel mixte",
            body: "Une cause passée avec une conséquence présente : If + past perfect, would + base.",
            examples: [
              { en: "If I hadn't missed the train, I would be there now.", fr: "Si je n'avais pas raté le train, je serais là maintenant." },
            ],
          },
          {
            heading: "Inversion soutenue (C1/C2)",
            body: "À l'écrit élégant, on supprime « if » et on inverse : Had I known… / Were I you… / Should you need anything…",
            examples: [
              { en: "Had I known, I would have helped.", fr: "Si j'avais su, j'aurais aidé." },
            ],
          },
        ],
        rules: [
          "C2 : if + prétérit → would + base",
          "C3 : if + had + participe → would have + participe",
          "Jamais « would » dans la proposition en if",
        ],
        pitfalls: [
          { wrong: "If I would have time, I would come.", right: "If I had time, I would come.", why: "Pas de would après if." },
          { wrong: "If she would have studied…", right: "If she had studied…", why: "Conditionnel 3 : past perfect après if." },
        ],
      },
      {
        slug: "wish-if-only",
        title: "Wish et if only",
        titleEn: "Wish & if only",
        cefr: "B2",
        minutes: 5,
        summary: "Exprimer le regret et le souhait — un système de temps « décalé ».",
        sections: [
          {
            heading: "Regret sur le présent",
            body: "wish + prétérit : la situation actuelle me déplaît.",
            examples: [
              { en: "I wish I spoke Japanese.", fr: "J'aimerais parler japonais (mais non)." },
              { en: "I wish I were taller.", fr: "J'aimerais être plus grand." },
            ],
          },
          {
            heading: "Regret sur le passé",
            body: "wish + past perfect : je regrette ce qui s'est (ou ne s'est pas) passé.",
            examples: [
              { en: "I wish I had studied harder.", fr: "J'aurais aimé travailler davantage." },
            ],
          },
          {
            heading: "Agacement : wish + would",
            body: "Pour une habitude agaçante chez quelqu'un d'autre.",
            examples: [
              { en: "I wish you would stop shouting.", fr: "J'aimerais que tu arrêtes de crier." },
            ],
          },
        ],
        rules: ["wish + prétérit = regret présent", "wish + past perfect = regret passé", "wish + would = reproche"],
        pitfalls: [
          { wrong: "I wish I can fly.", right: "I wish I could fly.", why: "Le temps recule d'un cran." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "modals",
    name: "Les modaux",
    icon: "KeyRound",
    color: "#ffc24b",
    description: "Can, must, should, might : la nuance, la politesse et la déduction.",
    lessons: [
      {
        slug: "modals-basics",
        title: "Capacité, permission et obligation",
        titleEn: "Can, may, must, have to",
        cefr: "A2",
        minutes: 7,
        summary: "Les modaux de base et la différence cruciale entre mustn't et don't have to.",
        sections: [
          {
            heading: "Règle d'or des modaux",
            body: "Un modal ne prend jamais de -s, jamais de « to » après lui, et se construit sans do / does.",
            examples: [
              { en: "She can swim.", fr: "Elle sait nager. (pas « she cans »)" },
              { en: "Can she swim?", fr: "Sait-elle nager ? (pas « Does she can »)" },
            ],
          },
          {
            heading: "Capacité et permission",
            body: "can / could (capacité, permission informelle), may (permission formelle), be able to (capacité, tous les temps).",
            examples: [
              { en: "May I come in?", fr: "Puis-je entrer ? (formel)" },
              { en: "I'll be able to help tomorrow.", fr: "Je pourrai aider demain." },
            ],
          },
          {
            heading: "Obligation : must vs have to",
            body: "MUST = obligation qui vient de moi / de la règle. HAVE TO = contrainte extérieure. Au passé, must n'existe pas : on utilise had to.",
            examples: [
              { en: "I must call my mother.", fr: "Il faut que j'appelle ma mère. (je le décide)" },
              { en: "I have to wear a uniform.", fr: "Je dois porter un uniforme. (règle imposée)" },
            ],
          },
          {
            heading: "LE piège : mustn't ≠ don't have to",
            body: "mustn't = c'est interdit. don't have to = ce n'est pas nécessaire.",
            examples: [
              { en: "You mustn't smoke here.", fr: "Il est interdit de fumer ici." },
              { en: "You don't have to come.", fr: "Tu n'es pas obligé de venir." },
            ],
          },
        ],
        rules: ["Modal + base verbale, sans to, sans -s", "mustn't = interdiction · don't have to = pas obligatoire", "Passé de must = had to"],
        pitfalls: [
          { wrong: "She must to go.", right: "She must go.", why: "Pas de « to » après un modal." },
          { wrong: "You mustn't pay, it's free.", right: "You don't have to pay, it's free.", why: "Ce n'est pas une interdiction, juste une absence d'obligation." },
        ],
      },
      {
        slug: "modals-deduction",
        title: "Déduction et modaux du passé",
        titleEn: "Modals of deduction & past modals",
        cefr: "C1",
        minutes: 7,
        summary: "must have, can't have, should have : juger, déduire et regretter.",
        sections: [
          {
            heading: "Déduire au présent",
            body: "must be (c'est sûrement), might / may / could be (c'est possible), can't be (c'est impossible).",
            examples: [
              { en: "He must be tired — he worked all night.", fr: "Il doit être fatigué — il a travaillé toute la nuit." },
              { en: "That can't be true!", fr: "Ça ne peut pas être vrai !" },
            ],
          },
          {
            heading: "Déduire au passé : modal + have + participe",
            body: "must have done (ça a sûrement eu lieu), can't have done (impossible), might have done (peut-être).",
            examples: [
              { en: "She must have forgotten.", fr: "Elle a dû oublier." },
              { en: "He can't have seen us.", fr: "Il ne peut pas nous avoir vus." },
            ],
          },
          {
            heading: "Regret et reproche : should have",
            body: "should have + participe = j'aurais dû / tu aurais dû.",
            examples: [
              { en: "You should have told me.", fr: "Tu aurais dû me le dire." },
              { en: "I shouldn't have eaten so much.", fr: "Je n'aurais pas dû manger autant." },
            ],
          },
        ],
        rules: ["modal + have + participe passé pour le passé", "must have = certitude · can't have = impossibilité", "should have = regret"],
        pitfalls: [
          { wrong: "You should have told me it. / You should tell me yesterday.", right: "You should have told me.", why: "Reproche sur le passé = should have + participe." },
          { wrong: "He must forgot.", right: "He must have forgotten.", why: "Déduction passée : must have + participe." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "passive-reported",
    name: "Passif & discours rapporté",
    icon: "Repeat",
    color: "#c9a7ff",
    description: "Changer de point de vue et rapporter les paroles des autres.",
    lessons: [
      {
        slug: "passive-voice",
        title: "La voix passive",
        titleEn: "The passive voice",
        cefr: "B1",
        minutes: 7,
        summary: "Quand l'action compte plus que celui qui la fait : be + participe passé.",
        sections: [
          {
            heading: "Construction",
            body: "On met l'objet en sujet, puis be (au temps de la phrase d'origine) + participe passé. L'auteur s'introduit avec « by » (souvent omis).",
            table: {
              head: ["Temps", "Actif", "Passif"],
              rows: [
                ["Présent", "They clean the room.", "The room is cleaned."],
                ["Prétérit", "They built it in 1902.", "It was built in 1902."],
                ["Present perfect", "They have sold the car.", "The car has been sold."],
                ["Futur", "They will repair it.", "It will be repaired."],
                ["Modal", "You must do it.", "It must be done."],
              ],
            },
          },
          {
            heading: "Pourquoi l'anglais l'adore",
            body: "L'auteur est inconnu, évident ou sans importance ; ou on veut rester neutre / formel (presse, science, consignes).",
            examples: [
              { en: "My bike was stolen.", fr: "On m'a volé mon vélo." },
              { en: "English is spoken here.", fr: "Ici, on parle anglais." },
            ],
          },
          {
            heading: "Le passif à deux objets",
            body: "Avec give, send, offer, tell… on peut mettre la personne en sujet — c'est même le plus courant.",
            examples: [
              { en: "I was given a second chance.", fr: "On m'a donné une seconde chance." },
            ],
          },
        ],
        rules: ["be (au bon temps) + participe passé", "« by + auteur » seulement si l'info est utile", "Le français « on » se traduit souvent par un passif"],
        pitfalls: [
          { wrong: "The house is build in 1900.", right: "The house was built in 1900.", why: "Participe passé + temps du passé." },
          { wrong: "It must done.", right: "It must be done.", why: "Le « be » ne disparaît jamais." },
        ],
      },
      {
        slug: "reported-speech",
        title: "Le discours rapporté",
        titleEn: "Reported (indirect) speech",
        cefr: "B2",
        minutes: 8,
        summary: "Rapporter ce qui a été dit : les temps reculent d'un cran.",
        sections: [
          {
            heading: "Le recul des temps",
            body: "Quand le verbe introducteur est au passé (said, told), chaque temps recule.",
            table: {
              head: ["Direct", "Rapporté"],
              rows: [
                ["\"I am tired\"", "He said he was tired."],
                ["\"I work here\"", "She said she worked there."],
                ["\"I saw him\"", "He said he had seen him."],
                ["\"I will call\"", "She said she would call."],
                ["\"I can swim\"", "He said he could swim."],
              ],
            },
          },
          {
            heading: "Les repères changent aussi",
            body: "now → then · today → that day · tomorrow → the next day · yesterday → the day before · here → there · this → that.",
          },
          {
            heading: "Say vs tell",
            body: "TELL exige un complément de personne (tell me, tell him) ; SAY non (say that…).",
            examples: [
              { en: "He told me he was late.", fr: "Il m'a dit qu'il était en retard." },
              { en: "He said he was late.", fr: "Il a dit qu'il était en retard." },
            ],
          },
          {
            heading: "Questions et ordres rapportés",
            body: "Question rapportée = ordre des mots d'une affirmation, avec if / whether si pas de mot interrogatif. Ordre rapporté = tell + personne + to + base.",
            examples: [
              { en: "She asked where I lived.", fr: "Elle a demandé où j'habitais." },
              { en: "She asked if I was ready.", fr: "Elle a demandé si j'étais prêt." },
              { en: "He told me to wait.", fr: "Il m'a dit d'attendre." },
            ],
          },
        ],
        rules: ["Verbe introducteur au passé → temps reculés", "tell + personne · say sans personne", "Question rapportée : pas d'inversion, pas de point d'interrogation"],
        pitfalls: [
          { wrong: "He said me that…", right: "He told me that… / He said that…", why: "« Say » ne prend pas de complément de personne direct." },
          { wrong: "She asked where did I live.", right: "She asked where I lived.", why: "Pas d'inversion dans une question rapportée." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "verb-patterns",
    name: "Gérondif & infinitif",
    icon: "Shuffle",
    color: "#7cf5c8",
    description: "-ing ou to + base ? La construction après chaque verbe.",
    lessons: [
      {
        slug: "gerund-infinitive",
        title: "Gérondif ou infinitif",
        titleEn: "Gerund & infinitive",
        cefr: "B1",
        minutes: 7,
        summary: "Le choix dépend du verbe qui précède — voici les listes qui sauvent.",
        sections: [
          {
            heading: "Verbes suivis de -ing",
            body: "enjoy, avoid, finish, mind, suggest, practise, imagine, keep, miss, deny, risk, can't help.",
            examples: [
              { en: "I enjoy reading.", fr: "J'aime lire." },
              { en: "He avoided answering.", fr: "Il a évité de répondre." },
            ],
          },
          {
            heading: "Verbes suivis de to + base",
            body: "want, decide, hope, promise, agree, refuse, learn, offer, plan, manage, afford, pretend.",
            examples: [
              { en: "She decided to leave.", fr: "Elle a décidé de partir." },
              { en: "They refused to pay.", fr: "Ils ont refusé de payer." },
            ],
          },
          {
            heading: "Les deux, avec un sens différent",
            body: "stop / remember / forget / try changent de sens selon la construction.",
            table: {
              head: ["Structure", "Sens"],
              rows: [
                ["stop smoking", "arrêter de fumer"],
                ["stop to smoke", "s'arrêter pour fumer"],
                ["remember locking", "se souvenir d'avoir fermé"],
                ["remember to lock", "penser à fermer"],
                ["try doing", "essayer (pour voir)"],
                ["try to do", "s'efforcer de faire"],
              ],
            },
          },
          {
            heading: "Après une préposition : toujours -ing",
            body: "Sans exception : good at swimming, interested in learning, instead of waiting, look forward to seeing.",
            examples: [
              { en: "I look forward to meeting you.", fr: "J'ai hâte de vous rencontrer." },
            ],
          },
        ],
        rules: ["enjoy / avoid / finish + -ing", "want / decide / hope + to + base", "Après toute préposition → -ing"],
        pitfalls: [
          { wrong: "I enjoy to read.", right: "I enjoy reading.", why: "« Enjoy » impose le -ing." },
          { wrong: "I look forward to meet you.", right: "I look forward to meeting you.", why: "Ici « to » est une préposition." },
        ],
      },
      {
        slug: "phrasal-verbs",
        title: "Les phrasal verbs",
        titleEn: "Phrasal verbs",
        cefr: "B2",
        minutes: 6,
        summary: "Le cœur de l'anglais parlé : un verbe + une particule qui change tout le sens.",
        sections: [
          {
            heading: "Ce que c'est",
            body: "Un verbe courant + une particule (up, out, on, off, in, down, over…) formant un sens nouveau, souvent imprévisible.",
            examples: [
              { en: "give up = abandonner", fr: "Don't give up!" },
              { en: "look after = s'occuper de", fr: "She looks after her brother." },
              { en: "put up with = supporter", fr: "I can't put up with the noise." },
            ],
          },
          {
            heading: "Séparables ou non",
            body: "Beaucoup acceptent le complément au milieu : turn the TV off. Mais si c'est un pronom, il DOIT être au milieu : turn it off (jamais « turn off it »).",
            examples: [
              { en: "Pick up your sister. / Pick her up.", fr: "Va chercher ta sœur. / Va la chercher." },
            ],
          },
          {
            heading: "Registre",
            body: "Les natifs préfèrent le phrasal verb à l'équivalent latin : find out plutôt que discover, put off plutôt que postpone. Les maîtriser = sonner naturel.",
          },
        ],
        rules: ["Le sens vient du couple verbe + particule", "Pronom complément toujours au milieu : turn it off", "Phrasal verb = registre naturel, verbe latin = registre formel"],
        pitfalls: [
          { wrong: "Turn off it.", right: "Turn it off.", why: "Le pronom se place entre le verbe et la particule." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "nouns-determiners",
    name: "Noms & déterminants",
    icon: "Box",
    color: "#ff9d5c",
    description: "Pluriels, dénombrables, articles et quantifieurs.",
    lessons: [
      {
        slug: "nouns-plurals",
        title: "Noms et pluriels",
        titleEn: "Nouns & plurals",
        cefr: "A1",
        minutes: 5,
        summary: "Les pluriels réguliers, les irréguliers à connaître, et le possessif.",
        sections: [
          {
            heading: "Pluriels réguliers",
            body: "+ -s · + -es après -s, -sh, -ch, -x, -o · consonne + y → -ies · -f / -fe → -ves.",
            examples: [
              { en: "box → boxes · city → cities · knife → knives", fr: "boîte · ville · couteau" },
            ],
          },
          {
            heading: "Les irréguliers incontournables",
            body: "man → men · woman → women · child → children · foot → feet · tooth → teeth · person → people · mouse → mice. Et invariables : sheep, fish, series.",
          },
          {
            heading: "Le génitif ('s)",
            body: "La possession se dit à l'envers du français : « le livre de Marie » → Mary's book. Pluriel en -s → juste l'apostrophe : the students' room.",
            examples: [
              { en: "My sister's car", fr: "La voiture de ma sœur" },
            ],
          },
        ],
        rules: ["Pluriels en -s / -es / -ies / -ves", "Irréguliers à mémoriser", "Possession : 's (ou ' au pluriel)"],
        pitfalls: [
          { wrong: "The car of my sister", right: "My sister's car", why: "Pour les personnes, on utilise le génitif." },
          { wrong: "Two childs", right: "Two children", why: "Pluriel irrégulier." },
        ],
      },
      {
        slug: "countable-uncountable",
        title: "Dénombrables & indénombrables",
        titleEn: "Countable & uncountable nouns",
        cefr: "A2",
        minutes: 6,
        summary: "La distinction qui commande much/many, few/little et l'article a/an.",
        sections: [
          {
            heading: "La frontière",
            body: "Dénombrable = on peut compter (a book, two books). Indénombrable = masse ou abstraction : water, money, advice, information, news, furniture, bread, work, luggage.",
          },
          {
            heading: "Les quantifieurs",
            table: {
              head: ["", "Dénombrable", "Indénombrable"],
              rows: [
                ["Beaucoup", "many books", "much water"],
                ["Peu", "few friends", "little time"],
                ["Un peu", "a few friends", "a little time"],
                ["Combien", "How many?", "How much?"],
              ],
            },
          },
          {
            heading: "Les faux amis du français",
            body: "Des mots pluriels en français sont indénombrables en anglais : information, advice, furniture, news, knowledge, progress, luggage, research. Jamais de -s, jamais de « an ».",
            examples: [
              { en: "She gave me some good advice.", fr: "Elle m'a donné de bons conseils." },
              { en: "The news is bad.", fr: "Les nouvelles sont mauvaises. (singulier !)" },
            ],
          },
          {
            heading: "Compter l'incomptable",
            body: "On ajoute un contenant : a piece of advice, a glass of water, two slices of bread, a bit of luck.",
          },
        ],
        rules: ["many / few + dénombrable", "much / little + indénombrable", "advice, information, news, furniture = toujours singuliers"],
        pitfalls: [
          { wrong: "I need some advices.", right: "I need some advice.", why: "« Advice » est indénombrable." },
          { wrong: "How much books?", right: "How many books?", why: "« Books » se compte." },
        ],
      },
      {
        slug: "articles",
        title: "Les articles a, an, the et Ø",
        titleEn: "Articles",
        cefr: "A2",
        minutes: 7,
        summary: "Le petit mot qui trahit immédiatement un francophone.",
        sections: [
          {
            heading: "A / AN : un parmi d'autres",
            body: "Première mention, ou catégorie. AN devant un SON voyelle (an hour, an MP3) et A devant un son consonne (a university, a European).",
            examples: [
              { en: "I saw a dog. The dog was huge.", fr: "J'ai vu un chien. Le chien était énorme." },
            ],
          },
          {
            heading: "THE : on sait duquel on parle",
            body: "Objet déjà mentionné, unique, ou précisé par un contexte : the sun, the kitchen, the book I bought.",
          },
          {
            heading: "L'article ZÉRO — le piège des francophones",
            body: "Pas d'article pour parler en général : des pluriels, des indénombrables et des abstractions.",
            examples: [
              { en: "Cats are independent.", fr: "Les chats sont indépendants." },
              { en: "Life is beautiful.", fr: "La vie est belle." },
              { en: "I like music.", fr: "J'aime la musique." },
            ],
          },
          {
            heading: "Cas particuliers utiles",
            body: "Pas d'article : go to school/work/bed/hospital (pour l'activité), les repas, les langues, la plupart des pays. Avec « the » : the UK, the USA, the Netherlands, les océans, les instruments (play the piano).",
          },
        ],
        rules: ["a/an = première mention · the = identifié", "Généralité au pluriel ou indénombrable → aucun article", "an + son voyelle, a + son consonne"],
        pitfalls: [
          { wrong: "The life is hard.", right: "Life is hard.", why: "Généralité abstraite = zéro article." },
          { wrong: "I play the football.", right: "I play football.", why: "Les sports ne prennent pas d'article." },
          { wrong: "I'm learning the English.", right: "I'm learning English.", why: "Les langues non plus." },
        ],
      },
      {
        slug: "determiners-quantifiers",
        title: "Some, any, no et compagnie",
        titleEn: "Determiners & quantifiers",
        cefr: "B1",
        minutes: 5,
        summary: "Choisir entre some, any, no, every et leurs composés.",
        sections: [
          {
            heading: "Some vs any",
            body: "SOME en phrase affirmative et dans les offres/demandes polies ; ANY en négation et en question neutre.",
            examples: [
              { en: "I have some money.", fr: "J'ai de l'argent." },
              { en: "I don't have any money.", fr: "Je n'ai pas d'argent." },
              { en: "Would you like some tea?", fr: "Voulez-vous du thé ? (offre)" },
            ],
          },
          {
            heading: "Les composés",
            body: "something / anything / nothing · somebody / anybody / nobody · somewhere / anywhere / nowhere. Ils sont singuliers : Everybody is here.",
          },
          {
            heading: "No vs not any",
            body: "« No + nom » équivaut à « not any », en plus emphatique : I have no idea = I don't have any idea.",
          },
        ],
        rules: ["some = affirmatif / offre · any = négatif / question", "Composés toujours singuliers", "no + nom = not any"],
        pitfalls: [
          { wrong: "I don't have no money.", right: "I don't have any money.", why: "Pas de double négation en anglais standard." },
          { wrong: "Everybody are happy.", right: "Everybody is happy.", why: "Les composés sont singuliers." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "adjectives-adverbs",
    name: "Adjectifs & adverbes",
    icon: "Palette",
    color: "#ff6b81",
    description: "Décrire, comparer, nuancer et placer les mots dans le bon ordre.",
    lessons: [
      {
        slug: "adjectives-order",
        title: "Adjectifs et leur ordre",
        titleEn: "Adjectives & adjective order",
        cefr: "A2",
        minutes: 5,
        summary: "Invariables, placés avant le nom, et dans un ordre très précis.",
        sections: [
          {
            heading: "Deux règles de base",
            body: "L'adjectif anglais est invariable (jamais de -s) et se place AVANT le nom.",
            examples: [
              { en: "Three beautiful red cars", fr: "Trois belles voitures rouges" },
            ],
          },
          {
            heading: "L'ordre des adjectifs",
            body: "Opinion → Taille → Âge → Forme → Couleur → Origine → Matière → But.",
            examples: [
              { en: "A lovely little old round black French wooden table.", fr: "Une jolie petite vieille table ronde noire française en bois." },
            ],
          },
          {
            heading: "-ed ou -ing ?",
            body: "L'adjectif en -ED décrit ce qu'on RESSENT ; celui en -ING décrit ce qui PROVOQUE le sentiment.",
            examples: [
              { en: "I'm bored. The film is boring.", fr: "Je m'ennuie. Le film est ennuyeux." },
              { en: "She's interested because the topic is interesting.", fr: "Elle est intéressée car le sujet est intéressant." },
            ],
          },
        ],
        rules: ["Adjectif invariable, placé avant le nom", "Ordre : opinion, taille, âge, forme, couleur, origine, matière", "-ed = ce que je ressens · -ing = ce qui le cause"],
        pitfalls: [
          { wrong: "I am boring in this class.", right: "I am bored in this class.", why: "« I'm boring » voudrait dire « je suis ennuyeux » !" },
          { wrong: "Reds cars", right: "Red cars", why: "Les adjectifs ne s'accordent jamais." },
        ],
      },
      {
        slug: "comparatives-superlatives",
        title: "Comparatifs et superlatifs",
        titleEn: "Comparatives & superlatives",
        cefr: "B1",
        minutes: 6,
        summary: "Plus grand, le plus grand, aussi grand que : toutes les comparaisons.",
        sections: [
          {
            heading: "Adjectifs courts (1 syllabe)",
            body: "+ -er … than / the + -est. Consonne finale doublée après voyelle courte : big → bigger → the biggest.",
            examples: [{ en: "My house is bigger than yours.", fr: "Ma maison est plus grande que la tienne." }],
          },
          {
            heading: "Adjectifs longs (3 syllabes et +)",
            body: "more … than / the most …",
            examples: [{ en: "This is the most interesting book.", fr: "C'est le livre le plus intéressant." }],
          },
          {
            heading: "Les deux syllabes",
            body: "En -y : y → -ier (happy → happier). Les autres prennent généralement more.",
          },
          {
            heading: "Irréguliers et égalité",
            body: "good → better → the best · bad → worse → the worst · far → further. Égalité : as + adjectif + as. Infériorité : less … than.",
            examples: [
              { en: "She's as tall as me.", fr: "Elle est aussi grande que moi." },
              { en: "The more you practise, the better you get.", fr: "Plus tu t'entraînes, meilleur tu deviens." },
            ],
          },
        ],
        rules: ["Court : -er / the -est · Long : more / the most", "than pour comparer, the pour le superlatif", "as … as pour l'égalité"],
        pitfalls: [
          { wrong: "more better", right: "better", why: "Jamais de double comparatif." },
          { wrong: "She is more tall than me.", right: "She is taller than me.", why: "Adjectif court → -er." },
        ],
      },
      {
        slug: "adverbs",
        title: "Les adverbes et leur place",
        titleEn: "Adverbs & adverb placement",
        cefr: "B1",
        minutes: 6,
        summary: "Formation en -ly, irréguliers, et la position dans la phrase.",
        sections: [
          {
            heading: "Formation",
            body: "Adjectif + -ly (quick → quickly). En -y → -ily (easy → easily). Irréguliers : good → well, fast → fast, hard → hard, late → late.",
            examples: [
              { en: "She sings beautifully.", fr: "Elle chante magnifiquement." },
              { en: "He speaks English well.", fr: "Il parle bien anglais." },
            ],
          },
          {
            heading: "Attention aux faux jumeaux",
            body: "hardly = à peine (rien à voir avec hard = dur) · lately = récemment (≠ late = en retard).",
            examples: [
              { en: "I hardly know him.", fr: "Je le connais à peine." },
            ],
          },
          {
            heading: "La place dans la phrase",
            body: "Fréquence (always, often, never) : avant le verbe principal, après « be ». Manière : généralement après le verbe ou en fin de phrase. Et surtout : on ne sépare JAMAIS le verbe de son complément d'objet.",
            examples: [
              { en: "I often play tennis.", fr: "Je joue souvent au tennis." },
              { en: "She speaks English fluently.", fr: "Elle parle couramment anglais." },
            ],
          },
        ],
        rules: ["Adjectif + -ly", "good → well (irrégulier)", "Ne jamais séparer verbe et COD par un adverbe"],
        pitfalls: [
          { wrong: "She speaks fluently English.", right: "She speaks English fluently.", why: "L'adverbe ne se glisse pas entre verbe et complément." },
          { wrong: "He plays good.", right: "He plays well.", why: "Un verbe se modifie avec un adverbe." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "sentence-structure",
    name: "Structure de la phrase",
    icon: "Blocks",
    color: "#5cd2ff",
    description: "Questions, relatives, prépositions et ordre des mots.",
    lessons: [
      {
        slug: "questions",
        title: "Poser des questions",
        titleEn: "Question formation",
        cefr: "A2",
        minutes: 6,
        summary: "L'ordre des mots, les question tags et les questions sur le sujet.",
        sections: [
          {
            heading: "La formule universelle",
            body: "(Mot interrogatif) + auxiliaire + sujet + verbe : Where do you live? · What is she doing? · Have you finished?",
            examples: [
              { en: "Where do you live?", fr: "Où habites-tu ?" },
              { en: "Why did he leave?", fr: "Pourquoi est-il parti ?" },
            ],
          },
          {
            heading: "Les mots interrogatifs",
            body: "what, who, where, when, why, which, whose, how + much/many/long/often/far.",
          },
          {
            heading: "Question sur le sujet : pas d'auxiliaire",
            body: "Quand on demande QUI ou QUOI fait l'action, l'ordre reste celui d'une affirmation.",
            examples: [
              { en: "Who called you?", fr: "Qui t'a appelé ? (pas « Who did call »)" },
              { en: "What happened?", fr: "Que s'est-il passé ?" },
            ],
          },
          {
            heading: "Question tags",
            body: "Affirmation → tag négatif, et inversement : You're coming, aren't you? · He can't swim, can he?",
          },
        ],
        rules: ["Auxiliaire + sujet + verbe", "Question sur le sujet = pas de do/does/did", "Tag inversé par rapport à la phrase"],
        pitfalls: [
          { wrong: "Where you live?", right: "Where do you live?", why: "L'auxiliaire est obligatoire." },
          { wrong: "Who did call you?", right: "Who called you?", why: "Question sur le sujet." },
        ],
      },
      {
        slug: "relative-clauses",
        title: "Les propositions relatives",
        titleEn: "Relative clauses",
        cefr: "B2",
        minutes: 7,
        summary: "who, which, that, whose : lier deux idées en une phrase fluide.",
        sections: [
          {
            heading: "Les pronoms relatifs",
            body: "who (personnes), which (choses), that (les deux, informel), whose (possession), where (lieu), when (temps).",
            examples: [
              { en: "The man who called is my boss.", fr: "L'homme qui a appelé est mon patron." },
              { en: "The book which I read was great.", fr: "Le livre que j'ai lu était super." },
              { en: "The girl whose bag was stolen…", fr: "La fille dont le sac a été volé…" },
            ],
          },
          {
            heading: "Déterminative vs explicative",
            body: "Sans virgule (déterminative), l'info est essentielle. Avec virgules (explicative), c'est un ajout — et « that » y est interdit.",
            examples: [
              { en: "My brother who lives in Rome is a chef. (j'ai plusieurs frères)", fr: "Mon frère qui habite à Rome est chef." },
              { en: "My brother, who lives in Rome, is a chef. (j'ai un seul frère)", fr: "Mon frère, qui habite à Rome, est chef." },
            ],
          },
          {
            heading: "Le pronom qu'on peut effacer",
            body: "Quand le relatif est COMPLÉMENT, on peut le supprimer : The book (that) I read. Impossible s'il est sujet.",
          },
        ],
        rules: ["who = personnes · which = choses · whose = dont", "Virgules = information non essentielle (jamais « that »)", "Relatif complément → suppression possible"],
        pitfalls: [
          { wrong: "The man which called…", right: "The man who called…", why: "« Which » ne s'emploie pas pour les personnes." },
          { wrong: "The book what I read…", right: "The book that I read…", why: "« What » n'est pas un pronom relatif." },
        ],
      },
      {
        slug: "prepositions",
        title: "Les prépositions",
        titleEn: "Prepositions of time & place",
        cefr: "A2",
        minutes: 6,
        summary: "in, on, at : la logique du plus large au plus précis.",
        sections: [
          {
            heading: "Le temps",
            table: {
              head: ["Préposition", "Usage", "Exemple"],
              rows: [
                ["in", "mois, saisons, années, siècles, parties de journée", "in July, in 2024, in the morning"],
                ["on", "jours et dates", "on Monday, on 5 May, on my birthday"],
                ["at", "heures et moments précis", "at 6 p.m., at night, at Christmas"],
              ],
            },
          },
          {
            heading: "Le lieu",
            body: "IN = à l'intérieur d'un volume (in the box, in Paris) · ON = sur une surface (on the table, on the wall) · AT = un point / une adresse (at the bus stop, at work).",
          },
          {
            heading: "Le mouvement",
            body: "to (vers), into (dedans), onto (sur), from (de), through (à travers), across (en traversant). Exception : go home, sans « to ».",
          },
          {
            heading: "Prépositions imposées par le verbe",
            body: "depend on, listen to, wait for, look for, belong to, arrive at/in, be interested in, be good at.",
            examples: [
              { en: "It depends on you.", fr: "Ça dépend de toi." },
              { en: "I'm waiting for the bus.", fr: "J'attends le bus." },
            ],
          },
        ],
        rules: ["in (mois/année) · on (jour) · at (heure)", "Du plus vaste (in) au plus précis (at)", "Certaines prépositions sont imposées par le verbe"],
        pitfalls: [
          { wrong: "I'm waiting the bus.", right: "I'm waiting for the bus.", why: "« Wait » exige « for »." },
          { wrong: "I go to home.", right: "I go home.", why: "« Home » ne prend pas « to »." },
        ],
      },
      {
        slug: "word-order-inversion",
        title: "Ordre des mots et inversions",
        titleEn: "Word order & inversion",
        cefr: "C1",
        minutes: 6,
        summary: "La colonne vertébrale SVO, et les inversions de style soutenu.",
        sections: [
          {
            heading: "L'ordre canonique",
            body: "Sujet – Verbe – Objet – Manière – Lieu – Temps. L'anglais y tient beaucoup plus que le français.",
            examples: [
              { en: "She read the letter carefully in her office last night.", fr: "Elle a lu la lettre attentivement dans son bureau hier soir." },
            ],
          },
          {
            heading: "Inversion après un adverbe négatif",
            body: "Quand la phrase commence par never, rarely, seldom, hardly, not only, no sooner, little → on inverse comme dans une question.",
            examples: [
              { en: "Never have I seen such beauty.", fr: "Jamais je n'ai vu pareille beauté." },
              { en: "Not only did he arrive late, but he also forgot the keys.", fr: "Non seulement il est arrivé en retard, mais il a aussi oublié les clés." },
            ],
          },
          {
            heading: "Inversion conditionnelle",
            body: "Had I known… · Were I you… · Should you need help… remplacent « if » à l'écrit soigné.",
          },
        ],
        rules: ["SVOMLT : sujet, verbe, objet, manière, lieu, temps", "Adverbe négatif en tête → inversion", "Registre soutenu uniquement"],
        pitfalls: [
          { wrong: "Never I have seen that.", right: "Never have I seen that.", why: "L'inversion est obligatoire après « never » en tête." },
        ],
      },
    ],
  },

  /* ================================================================== */
  {
    slug: "punctuation",
    name: "Ponctuation & écrit",
    icon: "PenLine",
    color: "#c9a7ff",
    description: "Les règles typographiques qui trahissent les francophones.",
    lessons: [
      {
        slug: "punctuation-basics",
        title: "La ponctuation anglaise",
        titleEn: "English punctuation",
        cefr: "B1",
        minutes: 5,
        summary: "Virgules, apostrophes, majuscules : tout ce qui diffère du français.",
        sections: [
          {
            heading: "Pas d'espace avant la ponctuation",
            body: "Contrairement au français, jamais d'espace avant ! ? : ; %. On écrit « Really? » et non « Really ? ».",
          },
          {
            heading: "Les majuscules obligatoires",
            body: "Le pronom I, les jours (Monday), les mois (July), les langues et nationalités (French, English), les pays, les titres.",
            examples: [
              { en: "I speak French and English on Mondays in July.", fr: "Je parle français et anglais le lundi en juillet." },
            ],
          },
          {
            heading: "L'apostrophe",
            body: "Contraction (don't, it's = it is) ou possession (Mary's). Attention : ITS (possessif) ne prend jamais d'apostrophe.",
            examples: [
              { en: "It's cold. The dog wagged its tail.", fr: "Il fait froid. Le chien a remué sa queue." },
            ],
          },
          {
            heading: "La virgule de liste (Oxford comma)",
            body: "En anglais, on sépare les éléments par des virgules et on accepte une virgule avant « and » : red, white, and blue.",
          },
        ],
        rules: ["Aucun espace avant ! ? : ;", "Majuscules : I, jours, mois, langues, pays", "its = possessif · it's = it is"],
        pitfalls: [
          { wrong: "Its a nice day.", right: "It's a nice day.", why: "Ici c'est la contraction de « it is »." },
          { wrong: "i speak english on monday.", right: "I speak English on Monday.", why: "Majuscules obligatoires." },
        ],
      },
    ],
  },
];

/* ---------------------------------------------------------------- */

export const ALL_LESSONS: Lesson[] = GRAMMAR_COURSE.flatMap((c) => c.lessons);

export function findLesson(slug: string): { lesson: Lesson; category: Category } | null {
  for (const category of GRAMMAR_COURSE) {
    const lesson = category.lessons.find((l) => l.slug === slug);
    if (lesson) return { lesson, category };
  }
  return null;
}

export function categoryOfLesson(slug: string): Category | null {
  return GRAMMAR_COURSE.find((c) => c.lessons.some((l) => l.slug === slug)) ?? null;
}

export const LESSON_COUNT = ALL_LESSONS.length;
