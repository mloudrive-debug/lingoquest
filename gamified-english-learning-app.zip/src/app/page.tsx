"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Award,
  BookMarked,
  BookOpen,
  BookOpenCheck,
  Brain,
  CalendarCheck,
  ChevronRight,
  Flame,
  PenLine,
  Sparkles,
  Star,
  Volume2,
} from "lucide-react";
import { useProfile } from "@/lib/hooks";
import { playSound, speak } from "@/lib/audio";
import CefrJourney from "@/components/CefrJourney";
import DictionaryBar, { useDictionary } from "@/components/DictionaryBar";
import { LESSON_COUNT } from "@/content/grammar-course";

const MODES = [
  {
    mode: "vocab",
    name: "Vocabulaire",
    tagline: "10 mots au défi",
    icon: BookOpen,
    grad: "from-[#8b7cff] to-[#6d28d9]",
    sh: "#4c2a85",
  },
  {
    mode: "grammar",
    name: "Grammaire",
    tagline: "Conjugaison fun",
    icon: PenLine,
    grad: "from-[#5cd2ff] to-[#2563eb]",
    sh: "#1f4e8f",
  },
  {
    mode: "match",
    name: "Memory",
    tagline: "Mode zen",
    icon: Brain,
    grad: "from-[#ffc24b] to-[#f97316]",
    sh: "#92600e",
  },
  {
    mode: "comprehension",
    name: "Lecture",
    tagline: "Petites histoires",
    icon: BookMarked,
    grad: "from-[#ff5ca8] to-[#e11d48]",
    sh: "#8f1a3f",
  },
];

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return "Encore debout ?";
  if (h < 12) return "Bonjour !";
  if (h < 18) return "Bon après-midi !";
  return "Bonsoir !";
}

export default function HomePage() {
  const { profile, loading } = useProfile();
  const dictionary = useDictionary();
  const [flipped, setFlipped] = useState(false);
  const goalPct = profile ? Math.min(100, Math.round((profile.dailyXp / profile.dailyGoal) * 100)) : 0;

  return (
    <main className="mx-auto w-full max-w-md px-4 pb-32">
      {/* ---------- HERO ---------- */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="card-night card-pop relative mt-2 overflow-hidden rounded-[2rem] p-5"
      >
        {/* deco */}
        <div className="pointer-events-none absolute -right-10 -top-10 size-44 rounded-full bg-violet-neon/25 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-14 -left-8 size-40 rounded-full bg-pink-neon/20 blur-3xl" />
        <motion.span
          animate={{ y: [0, -10, 0], rotate: [-6, 6, -6] }}
          transition={{ repeat: Infinity, duration: 5, ease: "easeInOut" }}
          className="pointer-events-none absolute right-6 top-6 font-display text-4xl font-bold text-violet-neon/30"
        >
          Aa
        </motion.span>
        <motion.span
          animate={{ y: [0, 8, 0], rotate: [8, -8, 8] }}
          transition={{ repeat: Infinity, duration: 6.5, ease: "easeInOut" }}
          className="pointer-events-none absolute right-16 top-20 font-display text-xl font-bold text-pink-neon/30"
        >
          Bb
        </motion.span>

        <p className="text-sm font-bold text-white/50">{greeting()}</p>
        <h1 className="mt-0.5 font-display text-2xl font-bold leading-tight">
          Ta dose d&apos;anglais du jour
        </h1>

        <div className="mt-5 flex items-center gap-5">
          {/* level ring */}
          <div className="relative size-28 shrink-0">
            <svg viewBox="0 0 100 100" className="size-full -rotate-90">
              <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="11" />
              <motion.circle
                cx="50"
                cy="50"
                r="42"
                fill="none"
                stroke="url(#lvlgrad)"
                strokeWidth="11"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 42}
                initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
                animate={{
                  strokeDashoffset: 2 * Math.PI * 42 * (1 - (profile?.levelProgress ?? 0)),
                }}
                transition={{ duration: 1.4, ease: [0.34, 1.3, 0.5, 1], delay: 0.3 }}
              />
              <defs>
                <linearGradient id="lvlgrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#8b7cff" />
                  <stop offset="100%" stopColor="#ff5ca8" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 grid place-items-center text-center">
              <div>
                <p className="font-display text-3xl font-bold leading-none">
                  {loading ? "–" : profile?.level}
                </p>
                <p className="text-[9px] font-bold uppercase tracking-widest text-white/45">niveau</p>
              </div>
            </div>
            <span className="absolute inset-0 -z-10 animate-pulse-ring rounded-full bg-violet-neon/25" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 rounded-2xl bg-white/5 px-3.5 py-2.5 ring-1 ring-white/10">
              <Sparkles className="size-4 shrink-0 text-violet-neon" />
              <div className="min-w-0">
                <p className="truncate text-sm font-extrabold tabular-nums">
                  {profile?.xp ?? 0} XP
                </p>
                <p className="text-[10px] font-bold text-white/45">
                  {profile ? `${profile.nextLevelXp - profile.levelRemaining} XP avant niveau ${profile.level + 1}` : "…"}
                </p>
              </div>
            </div>
            <div className="mt-2 flex items-center gap-2 rounded-2xl bg-white/5 px-3.5 py-2.5 ring-1 ring-white/10">
              <Flame className="size-4 shrink-0 animate-flame text-gold" fill="currentColor" />
              <p className="text-sm font-extrabold">
                {profile?.streak ?? 0} jour{(profile?.streak ?? 0) > 1 ? "s" : ""} de suite
              </p>
            </div>
          </div>
        </div>

        {/* daily goal */}
        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between text-xs font-bold">
            <span className="flex items-center gap-1.5 text-white/60">
              <CalendarCheck className="size-3.5 text-lime-neon" /> Objectif du jour
            </span>
            <span className={goalPct >= 100 ? "text-lime-neon" : "text-white/60"}>
              {profile?.dailyXp ?? 0}/{profile?.dailyGoal ?? 60} XP
            </span>
          </div>
          <div className="track h-3.5">
            <motion.div
              className={`relative h-full rounded-full ${
                goalPct >= 100 ? "bg-gradient-to-r from-lime-neon to-emerald-400" : "bg-gradient-to-r from-violet-neon to-pink-neon"
              }`}
              initial={{ width: 0 }}
              animate={{ width: `${goalPct}%` }}
              transition={{ duration: 1, ease: "easeOut", delay: 0.5 }}
            >
              <div className="fill-shine absolute inset-0 rounded-full" />
            </motion.div>
          </div>
          {goalPct >= 100 && (
            <motion.p initial={{ scale: 0.8 }} animate={{ scale: 1 }} className="mt-1.5 text-xs font-extrabold text-lime-neon">
              Objectif atteint — tu cartonne !
            </motion.p>
          )}
        </div>
      </motion.section>

      {/* ---------- CEFR JOURNEY ---------- */}
      {profile && (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <CefrJourney cefr={profile.cefr} />
        </motion.div>
      )}

      {/* ---------- DICTIONARY COVERAGE ---------- */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
      >
        <DictionaryBar stats={dictionary} />
      </motion.div>

      {/* ---------- WORD OF THE DAY ---------- */}
      {profile?.wordOfTheDay && (
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-4"
        >
          <div className="mb-2 flex items-center justify-between px-1">
            <h2 className="flex items-center gap-1.5 font-display text-lg font-bold">
              <Star className="size-4 text-gold" fill="currentColor" /> Mot du jour
            </h2>
            <span className="text-[11px] font-bold uppercase tracking-wider text-white/35">
              touche pour retourner
            </span>
          </div>
          <button
            onClick={() => {
              setFlipped((f) => !f);
              playSound("flip");
              if (!flipped) speak(profile.wordOfTheDay!.en);
            }}
            className="flip-scene block h-44 w-full text-left"
          >
            <div className={`flip-inner relative size-full ${flipped ? "flipped" : ""}`}>
              {/* front: english */}
              <div className="flip-face card-pop absolute inset-0 flex flex-col items-center justify-center rounded-[1.6rem] bg-gradient-to-br from-violet-neon to-violet-deep">
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">
                  {profile.wordOfTheDay.category}
                </span>
                <span className="mt-1 font-display text-4xl font-bold text-white text-glow-violet">
                  {profile.wordOfTheDay.en}
                </span>
                <span className="mt-3 flex items-center gap-1.5 text-xs font-bold text-white/70">
                  <Volume2 className="size-4" /> écoute et retourne-moi
                </span>
              </div>
              {/* back: french + example */}
              <div className="flip-face flip-back card-pop absolute inset-0 flex flex-col items-center justify-center rounded-[1.6rem] bg-gradient-to-br from-pink-neon to-rose px-5 text-center">
                <span className="font-display text-3xl font-bold text-white">{profile.wordOfTheDay.fr}</span>
                <span className="mt-2 text-sm font-semibold italic leading-snug text-white/85">
                  « {profile.wordOfTheDay.exampleEn} »
                </span>
                <span className="mt-1 text-xs font-semibold text-white/60">
                  {profile.wordOfTheDay.exampleFr}
                </span>
              </div>
            </div>
          </button>
        </motion.section>
      )}

      {/* ---------- MODES ---------- */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-6"
      >
        <div className="mb-2 flex items-center justify-between px-1">
          <h2 className="font-display text-lg font-bold">Joue et apprends</h2>
          <span className="text-[11px] font-bold uppercase tracking-wider text-white/35">
            4 missions
          </span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {MODES.map((m, i) => (
            <motion.div
              key={m.mode}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.25 + i * 0.07, type: "spring", stiffness: 260, damping: 18 }}
            >
              <Link
                href={`/play/${m.mode}`}
                onClick={() => playSound("tap")}
                className={`btn3d group relative block overflow-hidden rounded-[1.4rem] bg-gradient-to-br p-4 ${m.grad}`}
                style={{ ["--sh" as string]: m.sh }}
              >
                <m.icon
                  className="absolute -right-3 -top-3 size-20 text-white/15 transition-transform duration-300 group-hover:rotate-12 group-hover:scale-110"
                  strokeWidth={1.5}
                />
                <div className="grid size-11 place-items-center rounded-xl bg-white/25 backdrop-blur-sm">
                  <m.icon className="size-6 text-white" strokeWidth={2.4} />
                </div>
                <p className="mt-3 font-display text-lg font-bold leading-tight text-white">{m.name}</p>
                <p className="text-xs font-bold text-white/75">{m.tagline}</p>
                <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-black/25 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide text-white/85">
                  Jouer <ChevronRight className="size-3" />
                </span>
              </Link>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* ---------- REVIEW + BADGES TEASER ---------- */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="mt-6 grid gap-3"
      >
        <Link
          href="/grammar"
          onClick={() => playSound("tap")}
          className="card-night card-pop group flex items-center gap-4 rounded-3xl p-4"
        >
          <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-violet-neon/15 ring-1 ring-violet-neon/30">
            <BookOpenCheck className="size-6 text-violet-neon" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display text-lg font-bold leading-tight">
              Cours de grammaire
            </span>
            <span className="block text-xs font-semibold text-white/55">
              {LESSON_COUNT} leçons complètes, de A1 à C2, avec exercices
            </span>
          </span>
          <ArrowRight className="size-5 shrink-0 text-white/40 transition group-hover:translate-x-1 group-hover:text-violet-neon" />
        </Link>

        <Link
          href="/review"
          onClick={() => playSound("tap")}
          className="card-night card-pop group flex items-center gap-4 rounded-3xl p-4"
        >
          <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-cyan-neon/15 ring-1 ring-cyan-neon/30">
            <Sparkles className="size-6 text-cyan-neon" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display text-lg font-bold leading-tight">Révision éclair</span>
            <span className="block text-xs font-semibold text-white/55">
              {profile?.masteredWords ?? 0} mots maîtrisés sur {profile?.totalItems ?? 300} · flashcards parlantes
            </span>
          </span>
          <ArrowRight className="size-5 shrink-0 text-white/40 transition group-hover:translate-x-1 group-hover:text-cyan-neon" />
        </Link>

        <Link
          href="/badges"
          onClick={() => playSound("tap")}
          className="card-night card-pop group flex items-center gap-4 rounded-3xl p-4"
        >
          <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-gold/15 ring-1 ring-gold/30">
            <Award className="size-6 text-gold" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block font-display text-lg font-bold leading-tight">Tes succès</span>
            <span className="block text-xs font-semibold text-white/55">
              {profile?.badges.filter((b) => b.unlocked).length ?? 0}/{profile?.badges.length ?? 10} badges débloqués
            </span>
          </span>
          <ArrowRight className="size-5 shrink-0 text-white/40 transition group-hover:translate-x-1 group-hover:text-gold" />
        </Link>
      </motion.section>
    </main>
  );
}
