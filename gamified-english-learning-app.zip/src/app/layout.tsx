import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Baloo_2, Nunito } from "next/font/google";
import "./globals.css";
import TopBar from "@/components/TopBar";
import BottomNav from "@/components/BottomNav";
import PwaRegister from "@/components/PwaRegister";

const display = Baloo_2({
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
  variable: "--font-display-var",
});

const body = Nunito({
  subsets: ["latin"],
  weight: ["400", "600", "700", "800", "900"],
  variable: "--font-body-var",
});

export const metadata: Metadata = {
  title: "LingoQuest — Apprends l'anglais en jouant",
  applicationName: "LingoQuest",
  description:
    "Un jeu pour apprendre l'anglais : vocabulaire, grammaire complète, lecture, mémoire et dictionnaire de 370 000 mots. Progression CECRL de A1 à C2.",
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "LingoQuest" },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#0a0914",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr" className={`${display.variable} ${body.variable}`}>
      <body className="grain min-h-dvh bg-night-950 font-body text-white antialiased">
        {/* ambient decor */}
        <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-32 left-1/2 h-80 w-[36rem] -translate-x-1/2 rounded-full bg-violet-deep/25 blur-[110px]" />
          <div className="absolute -bottom-40 -left-24 h-72 w-72 rounded-full bg-pink-neon/12 blur-[100px]" />
          <div className="absolute -right-24 top-1/3 h-64 w-64 rounded-full bg-cyan-neon/10 blur-[100px]" />
        </div>

        <TopBar />
        {children}
        <BottomNav />
        <PwaRegister />
      </body>
    </html>
  );
}
