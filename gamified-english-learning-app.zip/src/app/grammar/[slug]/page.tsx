"use client";

import Link from "next/link";
import { use, useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Check,
  ChevronRight,
  CircleAlert,
  Clock,
  Dumbbell,
  Lightbulb,
  Sparkles,
  Volume2,
  X,
} from "lucide-react";
import { findLesson } from "@/content/grammar-course";
import type { McqQuestion } from "@/lib/types";
import { playSound, speak } from "@/lib/audio";
import { smallPop, winBurst } from "@/lib/confetti";

export default function LessonPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const router = useRouter();
  const found = findLesson(slug);
  const [practice, setPractice] = useState(false);

  useEffect(() => {
    if (!found) return;
    fetch("/api/grammar/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug }),
    }).catch(() => {});
  }, [slug, found]);

  if (!found) {
    return (
      <main className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6 text-center">
        <div>
          <p className="font-display text-xl font-bold">Leçon introuvable.</p>
          <Link
            href="/grammar"
            className="btn3d mt-4 inline-block rounded-2xl bg-violet-neon px-6 py-3 font-display font-bold"
            style={{ ["--sh" as string]: "#5848b8" }}
          >
            Retour au cours
          </Link>
        </div>
      </main>
    );
  }

  const { lesson, category } = found;

  if (practice) {
    return <LessonPractice slug={slug} title={lesson.title} onExit={() => setPractice(false)} />;
  }

  return (
    <main className="mx-auto w-full max-w-md px-4 pb-32">
      {/* header */}
      <div className="safe-top flex items-center gap-2 py-3">
        <button
          onClick={() => router.push("/grammar")}
          aria-label="Retour"
          className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
        >
          <ArrowLeft className="size-4.5" />
        </button>
        <span className="truncate text-xs font-bold uppercase tracking-wider text-white/40">
          {category.name}
        </span>
      </div>

      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2">
          <span
            className="rounded-lg px-2 py-1 text-[11px] font-extrabold"
            style={{ backgroundColor: category.color + "26", color: category.color }}
          >
            {lesson.cefr}
          </span>
          <span className="flex items-center gap-1 text-[11px] font-bold text-white/45">
            <Clock className="size-3" /> {lesson.minutes} min
          </span>
        </div>
        <h1 className="mt-2 font-display text-3xl font-bold leading-tight">{lesson.title}</h1>
        <p className="mt-0.5 font-display text-sm font-bold text-white/35">{lesson.titleEn}</p>
        <p className="mt-3 text-[15px] font-semibold leading-relaxed text-white/70">
          {lesson.summary}
        </p>
      </motion.div>

      {/* quick rules */}
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="card-night card-pop mt-5 rounded-3xl p-5"
      >
        <h2 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-lime-neon">
          <Sparkles className="size-4" /> À retenir
        </h2>
        <ul className="mt-3 space-y-2">
          {lesson.rules.map((r, i) => (
            <li key={i} className="flex gap-2.5">
              <Check className="mt-0.5 size-4 shrink-0 text-lime-neon" strokeWidth={3} />
              <span className="text-sm font-semibold leading-snug text-white/85">{r}</span>
            </li>
          ))}
        </ul>
      </motion.div>

      {/* sections */}
      <div className="mt-5 space-y-4">
        {lesson.sections.map((s, i) => (
          <motion.section
            key={i}
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.06 + i * 0.04 }}
            className="card-night rounded-3xl p-5"
          >
            <h3 className="font-display text-lg font-bold leading-tight" style={{ color: category.color }}>
              {s.heading}
            </h3>
            {s.body && (
              <p className="mt-2 text-[15px] font-medium leading-relaxed text-white/80">{s.body}</p>
            )}

            {s.table && (
              <div className="mt-3 overflow-hidden rounded-2xl ring-1 ring-white/10">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white/[0.06]">
                    <tr>
                      {s.table.head.map((h, hi) => (
                        <th key={hi} className="px-3 py-2 font-display font-bold text-white/70">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {s.table.rows.map((row, ri) => (
                      <tr key={ri} className="border-t border-white/8">
                        {row.map((cell, cidx) => (
                          <td
                            key={cidx}
                            className={`px-3 py-2 align-top font-semibold ${
                              cidx === 0 ? "text-white/80" : "text-white/60"
                            }`}
                          >
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {s.examples && (
              <div className="mt-3 space-y-2">
                {s.examples.map((ex, ei) => (
                  <div
                    key={ei}
                    className="flex items-start gap-2.5 rounded-2xl bg-white/[0.04] p-3 ring-1 ring-white/8"
                  >
                    <button
                      aria-label="Écouter"
                      onClick={() => speak(ex.en)}
                      className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg bg-violet-neon/15 ring-1 ring-violet-neon/30 active:scale-90"
                    >
                      <Volume2 className="size-3.5 text-violet-neon" />
                    </button>
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-white/90">{ex.en}</p>
                      <p className="mt-0.5 text-xs font-semibold text-white/45">{ex.fr}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.section>
        ))}
      </div>

      {/* pitfalls */}
      {lesson.pitfalls.length > 0 && (
        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-night card-pop mt-5 rounded-3xl p-5"
        >
          <h3 className="flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-rose">
            <CircleAlert className="size-4" /> Les pièges classiques
          </h3>
          <div className="mt-3 space-y-3">
            {lesson.pitfalls.map((p, i) => (
              <div key={i} className="rounded-2xl bg-white/[0.04] p-3 ring-1 ring-white/8">
                <p className="flex items-start gap-2 text-sm font-bold text-rose/90">
                  <X className="mt-0.5 size-3.5 shrink-0" strokeWidth={3} />
                  <span className="line-through decoration-rose/50">{p.wrong}</span>
                </p>
                <p className="mt-1 flex items-start gap-2 text-sm font-bold text-lime-neon">
                  <Check className="mt-0.5 size-3.5 shrink-0" strokeWidth={3} />
                  {p.right}
                </p>
                <p className="mt-1.5 flex gap-1.5 pl-5 text-xs font-semibold text-white/50">
                  <Lightbulb className="size-3.5 shrink-0 text-gold" />
                  {p.why}
                </p>
              </div>
            ))}
          </div>
        </motion.section>
      )}

      <button
        onClick={() => {
          playSound("tap");
          setPractice(true);
        }}
        className="btn3d mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon py-4 font-display text-lg font-bold"
        style={{ ["--sh" as string]: "#4c2a85" }}
      >
        <Dumbbell className="size-5" /> S&apos;entraîner sur cette leçon
      </button>
    </main>
  );
}

/* ------------------------------------------------------------------ */

function LessonPractice({
  slug,
  title,
  onExit,
}: {
  slug: string;
  title: string;
  onExit: () => void;
}) {
  const [questions, setQuestions] = useState<McqQuestion[] | null>(null);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);
  const savedRef = useRef(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/grammar/practice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug }),
    });
    if (res.ok) {
      const d = (await res.json()) as { questions: McqQuestion[] };
      setQuestions(d.questions);
    } else setQuestions([]);
  }, [slug]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!done || savedRef.current || !questions) return;
    savedRef.current = true;
    winBurst();
    playSound("win");
    fetch("/api/grammar/practice", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug, correct, total: questions.length }),
    }).catch(() => {});
  }, [done, questions, correct, slug]);

  if (!questions) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <p className="font-display font-bold text-white/60">Préparation des exercices…</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6 text-center">
        <div>
          <p className="font-display text-xl font-bold">Pas encore d&apos;exercice ici.</p>
          <button
            onClick={onExit}
            className="btn3d mt-4 rounded-2xl bg-violet-neon px-6 py-3 font-display font-bold"
            style={{ ["--sh" as string]: "#5848b8" }}
          >
            Retour à la leçon
          </button>
        </div>
      </div>
    );
  }

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="card-night card-pop w-full rounded-3xl p-7 text-center"
        >
          <p className="font-display text-5xl font-bold text-glow-lime text-lime-neon">{pct}%</p>
          <p className="mt-2 font-display text-xl font-bold">
            {correct}/{questions.length} sur « {title} »
          </p>
          <p className="mt-1 text-sm font-semibold text-white/50">
            {pct === 100
              ? "Leçon maîtrisée, impeccable !"
              : pct >= 70
                ? "Bien joué — relis les pièges pour viser 100 %."
                : "Relis la leçon, puis retente : ça rentrera."}
          </p>
          <div className="mt-6 grid gap-3">
            <button
              onClick={() => {
                playSound("tap");
                savedRef.current = false;
                setIndex(0);
                setSelected(null);
                setCorrect(0);
                setDone(false);
                setQuestions(null);
                void load();
              }}
              className="btn3d rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon py-3.5 font-display font-bold"
              style={{ ["--sh" as string]: "#4c2a85" }}
            >
              Refaire les exercices
            </button>
            <button
              onClick={onExit}
              className="btn3d rounded-2xl bg-white/10 py-3.5 font-display font-bold ring-1 ring-white/15"
              style={{ ["--sh" as string]: "rgb(255 255 255 / 0.08)" }}
            >
              Retour à la leçon
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  const q = questions[index];
  const answered = selected !== null;
  const isRight = answered && selected === q.answerIndex;

  const pick = (i: number) => {
    if (answered) return;
    setSelected(i);
    if (i === q.answerIndex) {
      setCorrect((c) => c + 1);
      playSound("correct");
      smallPop(0.5, 0.55);
    } else playSound("wrong");
  };

  const next = () => {
    playSound("tap");
    if (index + 1 >= questions.length) setDone(true);
    else {
      setIndex((i) => i + 1);
      setSelected(null);
    }
  };

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8">
      <div className="safe-top sticky top-0 z-30 -mx-5 bg-night-950/85 px-5 pb-2 pt-3 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onExit}
            aria-label="Quitter"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 active:scale-90"
          >
            <X className="size-4.5" />
          </button>
          <div className="track h-4 flex-1">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-violet-neon to-pink-neon"
              animate={{ width: `${((index + (answered ? 1 : 0)) / questions.length) * 100}%` }}
            />
          </div>
          <span className="shrink-0 text-xs font-extrabold tabular-nums text-white/50">
            {index + 1}/{questions.length}
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className={`card-night card-pop mt-5 rounded-3xl p-6 ${answered && !isRight ? "animate-shake" : ""}`}
          >
            <span className="inline-block rounded-full bg-white/8 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white/60">
              {q.subPrompt}
            </span>
            <p className="mt-3 font-display text-[22px] font-bold leading-snug">
              {q.prompt.split("___").map((part, i, arr) => (
                <span key={i}>
                  {part}
                  {i < arr.length - 1 && (
                    <span className="mx-1 inline-block min-w-12 rounded-lg border-b-4 border-violet-neon/50 bg-violet-neon/10 px-2 text-center text-violet-neon/60">
                      {answered ? "" : "??"}
                    </span>
                  )}
                </span>
              ))}
            </p>
            <AnimatePresence>
              {answered && q.explanation && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="mt-4 flex gap-2.5 overflow-hidden rounded-2xl bg-gold/10 p-4 ring-1 ring-gold/25"
                >
                  <Lightbulb className="mt-0.5 size-4 shrink-0 text-gold" />
                  <p className="text-sm font-semibold leading-relaxed text-gold/90">
                    {q.explanation}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </AnimatePresence>

        <div className="mt-5 grid gap-3">
          {q.options.map((opt, i) => {
            const right = answered && i === q.answerIndex;
            const wrong = answered && i === selected && !isRight;
            return (
              <button
                key={`${index}-${i}`}
                disabled={answered}
                onClick={() => pick(i)}
                className={`btn3d flex items-center justify-between rounded-2xl px-5 py-4 text-left font-display text-base font-bold ${
                  right
                    ? "bg-lime-neon text-night-950"
                    : wrong
                      ? "bg-rose text-white"
                      : "bg-night-700 ring-1 ring-white/10"
                }`}
                style={{ ["--sh" as string]: right ? "#3f6212" : wrong ? "#8f2f44" : "#0d0a1d" }}
              >
                {opt}
                {right && <Check className="size-5 shrink-0" strokeWidth={3} />}
                {wrong && <X className="size-5 shrink-0" strokeWidth={3} />}
              </button>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {answered && (
          <motion.button
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={next}
            className={`btn3d mt-6 flex items-center justify-center gap-2 rounded-2xl py-4 font-display text-lg font-bold ${
              isRight ? "bg-lime-neon text-night-950" : "bg-gradient-to-br from-violet-neon to-pink-neon"
            }`}
            style={{ ["--sh" as string]: isRight ? "#3f6212" : "#4c2a85" }}
          >
            {index + 1 >= questions.length ? "Voir mon score" : "Continuer"}
            <ChevronRight className="size-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
