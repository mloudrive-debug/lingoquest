"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Blocks,
  BookOpenCheck,
  Box,
  CheckCircle2,
  ChevronRight,
  Clock,
  GitBranch,
  History,
  KeyRound,
  Palette,
  PenLine,
  Play,
  Repeat,
  Rocket,
  Shuffle,
} from "lucide-react";
import { GRAMMAR_COURSE, LESSON_COUNT } from "@/content/grammar-course";
import { playSound } from "@/lib/audio";

const ICONS: Record<string, typeof Play> = {
  Play, History, Rocket, GitBranch, KeyRound, Repeat, Shuffle, Box, Palette, Blocks, PenLine,
};

type Progress = { slug: string; read: boolean; bestScore: number; practiceTotal: number };

export default function GrammarPage() {
  const [progress, setProgress] = useState<Record<string, Progress>>({});

  useEffect(() => {
    fetch("/api/grammar/progress", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { lessons: Progress[] } | null) => {
        if (d) setProgress(Object.fromEntries(d.lessons.map((l) => [l.slug, l])));
      })
      .catch(() => {});
  }, []);

  const readCount = Object.values(progress).filter((p) => p.read).length;

  return (
    <main className="mx-auto w-full max-w-md px-4 pb-32">
      <h1 className="mt-2 flex items-center gap-2 px-1 font-display text-2xl font-bold">
        <BookOpenCheck className="size-6 text-cyan-neon" /> Cours de grammaire
      </h1>
      <p className="mt-1 px-1 text-sm font-semibold text-white/50">
        Toute la grammaire anglaise, de A1 à C2 — expliquée en français, avec exercices.
      </p>

      {/* global progress */}
      <div className="card-night card-pop mt-4 rounded-3xl p-4">
        <div className="mb-2 flex items-baseline justify-between">
          <span className="font-display text-sm font-bold text-white/70">Leçons lues</span>
          <span className="font-display text-lg font-bold tabular-nums text-cyan-neon">
            {readCount}/{LESSON_COUNT}
          </span>
        </div>
        <div className="track h-3">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-cyan-neon to-violet-neon"
            initial={{ width: 0 }}
            animate={{ width: `${(readCount / LESSON_COUNT) * 100}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
      </div>

      {/* categories */}
      <div className="mt-5 space-y-5">
        {GRAMMAR_COURSE.map((cat, ci) => {
          const Icon = ICONS[cat.icon] ?? Play;
          return (
            <motion.section
              key={cat.slug}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.04 * ci }}
            >
              <div className="mb-2 flex items-center gap-2.5 px-1">
                <span
                  className="grid size-9 shrink-0 place-items-center rounded-xl"
                  style={{ backgroundColor: cat.color + "26" }}
                >
                  <Icon className="size-5" style={{ color: cat.color }} />
                </span>
                <div className="min-w-0">
                  <h2 className="font-display text-lg font-bold leading-tight">{cat.name}</h2>
                  <p className="truncate text-[11px] font-semibold text-white/45">
                    {cat.description}
                  </p>
                </div>
              </div>

              <div className="grid gap-2">
                {cat.lessons.map((lesson) => {
                  const p = progress[lesson.slug];
                  return (
                    <Link
                      key={lesson.slug}
                      href={`/grammar/${lesson.slug}`}
                      onClick={() => playSound("tap")}
                      className="card-night group flex items-center gap-3 rounded-2xl p-3.5 transition active:scale-[0.99]"
                    >
                      <span
                        className="grid size-8 shrink-0 place-items-center rounded-lg text-[10px] font-extrabold"
                        style={{
                          backgroundColor: cat.color + "22",
                          color: cat.color,
                        }}
                      >
                        {lesson.cefr}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1.5">
                          <span className="truncate font-display text-[15px] font-bold">
                            {lesson.title}
                          </span>
                          {p?.read && (
                            <CheckCircle2 className="size-3.5 shrink-0 text-lime-neon" />
                          )}
                        </span>
                        <span className="mt-0.5 flex items-center gap-2 text-[11px] font-semibold text-white/45">
                          <Clock className="size-3" /> {lesson.minutes} min
                          {p && p.bestScore > 0 && (
                            <span className="text-gold">· record {p.bestScore} %</span>
                          )}
                        </span>
                      </span>
                      <ChevronRight className="size-4 shrink-0 text-white/30 transition group-hover:translate-x-0.5 group-hover:text-white/60" />
                    </Link>
                  );
                })}
              </div>
            </motion.section>
          );
        })}
      </div>
    </main>
  );
}
