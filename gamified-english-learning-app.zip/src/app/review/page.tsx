"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Layers, RotateCw, Sparkles, Volume2, X } from "lucide-react";
import ResultScreen from "@/components/games/ResultScreen";
import type { ReviewCard, SessionSummary } from "@/lib/types";
import { playSound, speak } from "@/lib/audio";

export default function ReviewPage() {
  const router = useRouter();
  const [cards, setCards] = useState<ReviewCard[] | null>(null);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<number[]>([]);
  const [unknown, setUnknown] = useState<number[]>([]);
  const [summary, setSummary] = useState<SessionSummary | null>(null);
  const [sessionKey, setSessionKey] = useState(0);
  const submittedRef = useRef(false);

  const load = useCallback(async () => {
    setCards(null);
    setIndex(0);
    setKnown([]);
    setUnknown([]);
    setSummary(null);
    setFlipped(false);
    submittedRef.current = false;
    const res = await fetch("/api/review", { cache: "no-store" });
    if (res.ok) setCards(await res.json());
  }, []);

  useEffect(() => {
    void load();
  }, [load, sessionKey]);

  const done = cards !== null && index >= cards.length;

  useEffect(() => {
    if (!done || !cards || submittedRef.current) return;
    submittedRef.current = true;
    void (async () => {
      const res = await fetch("/api/review/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ known, unknown }),
      });
      if (res.ok) setSummary(await res.json());
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [done, cards]);

  const answer = (isKnown: boolean) => {
    const card = cards?.[index];
    if (!card) return;
    playSound(isKnown ? "correct" : "wrong");
    if (isKnown) setKnown((k) => [...k, card.id]);
    else setUnknown((u) => [...u, card.id]);
    setFlipped(false);
    setTimeout(() => setIndex((i) => i + 1), 180);
  };

  const card = cards?.[index];

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-4 pb-28">
      <header className="mt-2 flex items-center justify-between px-1">
        <h1 className="flex items-center gap-2 font-display text-2xl font-bold">
          <Layers className="size-6 text-cyan-neon" /> Révision éclair
        </h1>
        {cards && !done && (
          <span className="rounded-full bg-white/5 px-3 py-1 text-xs font-extrabold tabular-nums text-white/60 ring-1 ring-white/10">
            {Math.min(index + 1, cards.length)}/{cards.length}
          </span>
        )}
      </header>

      {cards === null && (
        <div className="grid flex-1 place-items-center py-20">
          <div className="text-center">
            <motion.div
              animate={{ rotateY: [0, 180, 360] }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
              className="mx-auto grid size-16 place-items-center rounded-2xl bg-cyan-neon/15"
            >
              <Layers className="size-8 text-cyan-neon" />
            </motion.div>
            <p className="mt-4 font-display text-lg font-bold text-white/70">Préparation des cartes…</p>
          </div>
        </div>
      )}

      {cards !== null && cards.length === 0 && (
        <div className="grid flex-1 place-items-center py-20 text-center">
          <div>
            <Sparkles className="mx-auto size-12 text-violet-neon" />
            <p className="mt-3 font-display text-xl font-bold">Tout est frais dans ta mémoire !</p>
            <p className="mt-1 text-sm font-semibold text-white/50">
              Joue une session de vocabulaire pour alimenter tes révisions.
            </p>
            <button
              onClick={() => router.push("/play/vocab")}
              className="btn3d mt-5 rounded-2xl bg-violet-neon px-6 py-3.5 font-display font-bold"
              style={{ ["--sh" as string]: "#5848b8" }}
            >
              Jouer au vocabulaire
            </button>
          </div>
        </div>
      )}

      {summary ? (
        <ResultScreen
          summary={summary}
          modeLabel="Révision éclair"
          onHome={() => router.push("/")}
          onReplay={() => setSessionKey((k) => k + 1)}
        />
      ) : (
        card && (
          <>
            {/* progress */}
            <div className="track mt-3 h-2.5">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-cyan-neon to-violet-neon"
                animate={{ width: `${((index) / (cards?.length ?? 1)) * 100}%` }}
              />
            </div>

            <div className="flex flex-1 flex-col justify-center py-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={card.id}
                  initial={{ opacity: 0, x: 80, rotate: 4 }}
                  animate={{ opacity: 1, x: 0, rotate: 0 }}
                  exit={{ opacity: 0, x: -80, rotate: -4 }}
                  transition={{ type: "spring", stiffness: 260, damping: 24 }}
                >
                  <button
                    onClick={() => {
                      setFlipped((f) => !f);
                      playSound("flip");
                      if (!flipped) speak(card.en);
                    }}
                    className="flip-scene block h-72 w-full text-left"
                  >
                    <div className={`flip-inner relative size-full ${flipped ? "flipped" : ""}`}>
                      {/* front */}
                      <div className="flip-face card-night card-pop absolute inset-0 flex flex-col items-center justify-center rounded-[2rem] p-6">
                        {card.isNew && (
                          <span className="absolute right-4 top-4 rounded-full bg-gold/15 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wider text-gold ring-1 ring-gold/30">
                            nouveau
                          </span>
                        )}
                        <span className="rounded-full bg-white/5 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white/50 ring-1 ring-white/10">
                          {card.category}
                        </span>
                        <span className="mt-4 text-center font-display text-4xl font-bold leading-tight">
                          {card.en}
                        </span>
                        {/* mastery dots */}
                        <span className="mt-4 flex gap-1.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <span
                              key={i}
                              className={`size-2 rounded-full ${i < card.mastery ? "bg-lime-neon" : "bg-white/12"}`}
                            />
                          ))}
                        </span>
                        <span className="mt-5 flex items-center gap-1.5 text-xs font-bold text-white/45">
                          <RotateCw className="size-3.5" /> touche pour voir la traduction
                        </span>
                      </div>
                      {/* back */}
                      <div className="flip-face flip-back absolute inset-0 flex flex-col items-center justify-center rounded-[2rem] bg-gradient-to-br from-cyan-neon/20 to-violet-neon/25 p-6 ring-1 ring-cyan-neon/30">
                        <span className="text-center font-display text-3xl font-bold text-cyan-neon text-glow-violet">
                          {card.fr}
                        </span>
                        <div className="mt-5 rounded-2xl bg-night-950/60 p-4 text-center ring-1 ring-white/10">
                          <p className="text-sm font-bold text-white/90">« {card.exampleEn} »</p>
                          <p className="mt-1 text-xs font-semibold text-white/50">{card.exampleFr}</p>
                        </div>
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            speak(card.exampleEn);
                          }}
                          className="btn3d mt-4 flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-bold ring-1 ring-white/15"
                        >
                          <Volume2 className="size-4" /> Écouter la phrase
                        </span>
                      </div>
                    </div>
                  </button>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* answers */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => answer(false)}
                className="btn3d flex items-center justify-center gap-2 rounded-2xl bg-rose py-4 font-display text-lg font-bold text-white"
                style={{ ["--sh" as string]: "#8f2f44" }}
              >
                <X className="size-5" strokeWidth={3} /> À revoir
              </button>
              <button
                onClick={() => answer(true)}
                className="btn3d flex items-center justify-center gap-2 rounded-2xl bg-lime-neon py-4 font-display text-lg font-bold text-night-950"
                style={{ ["--sh" as string]: "#3f6212" }}
              >
                <Check className="size-5" strokeWidth={3} /> Je sais !
              </button>
            </div>
          </>
        )
      )}
    </main>
  );
}
