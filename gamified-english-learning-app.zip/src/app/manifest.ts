import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "LingoQuest — Apprends l'anglais en jouant",
    short_name: "LingoQuest",
    description:
      "Un jeu pour apprendre l'anglais : vocabulaire, grammaire, lecture et mémoire. XP, niveaux CECRL A1→C2, dictionnaire complet, cours et badges.",
    lang: "fr",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#0a0914",
    theme_color: "#0a0914",
    categories: ["education", "games"],
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      {
        src: "/icons/icon-maskable-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
      { src: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
    ],
  };
}
