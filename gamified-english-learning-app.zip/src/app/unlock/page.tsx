"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { motion } from "framer-motion";
import { KeyRound, Lock, Sparkles } from "lucide-react";
import { playSound } from "@/lib/audio";

export default function UnlockPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || busy) return;
    setBusy(true);
    setError(false);
    try {
      const res = await fetch("/api/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (res.ok) {
        playSound("win");
        router.push("/");
        router.refresh();
      } else {
        playSound("wrong");
        setError(true);
        setPassword("");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="card-night card-pop w-full rounded-[2rem] p-7 text-center"
      >
        <div className="relative mx-auto w-fit">
          <div className="grid size-20 place-items-center rounded-3xl bg-gradient-to-br from-violet-neon to-pink-neon shadow-[0_8px_30px_rgba(139,124,255,0.5)]">
            <Sparkles className="size-10 text-white" strokeWidth={2.2} />
          </div>
          <span className="absolute -bottom-2 -right-2 grid size-9 place-items-center rounded-2xl bg-night-800 ring-1 ring-white/15">
            <Lock className="size-4 text-gold" />
          </span>
        </div>

        <h1 className="mt-4 font-display text-3xl font-bold">
          Lingo<span className="text-violet-neon">Quest</span>
        </h1>
        <p className="mt-1 text-sm font-semibold text-white/55">
          App privée — entre ton mot de passe pour jouer.
        </p>

        <form onSubmit={submit} className="mt-6">
          <div
            className={`flex items-center gap-2.5 rounded-2xl bg-white/5 px-4 ring-1 transition ${
              error ? "animate-shake ring-rose/50" : "ring-white/12 focus-within:ring-violet-neon/50"
            }`}
          >
            <KeyRound className="size-4 shrink-0 text-white/40" />
            <input
              type="password"
              autoFocus
              autoComplete="current-password"
              placeholder="Mot de passe"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent py-4 font-display text-lg font-bold tracking-wide outline-none placeholder:font-body placeholder:text-sm placeholder:font-semibold placeholder:text-white/30"
            />
          </div>
          {error && (
            <p className="mt-2 text-xs font-bold text-rose">Mot de passe incorrect — réessaie.</p>
          )}
          <button
            type="submit"
            disabled={busy || !password}
            className="btn3d mt-4 w-full rounded-2xl bg-gradient-to-br from-violet-neon to-pink-neon py-4 font-display text-lg font-bold"
            style={{ ["--sh" as string]: "#4c2a85" }}
          >
            {busy ? "Déverrouillage…" : "Débloquer ma quête"}
          </button>
        </form>
      </motion.div>
    </main>
  );
}
