"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { BookA, Check, Gauge, Layers3, ShieldAlert, Sparkles, Target, X, Zap } from "lucide-react";
import ResultScreen from "@/components/games/ResultScreen";
import { useDictionary, type DictionaryStats } from "@/components/DictionaryBar";
import type { SessionSummary } from "@/lib/types";
import { playSound, speak } from "@/lib/audio";
import { smallPop } from "@/lib/confetti";

type SprintItem = { id: number; word: string; band: number; isReal: boolean };
type Claim = SprintItem & { claimedKnown: boolean };

export default function DictionaryPage() {
  const router = useRouter();
  const stats = useDictionary();
  const [mode, setMode] = useState<"overview" | "sprint">("overview");
  const [refreshKey, setRefreshKey] = useState(0);
  const [fresh, setFresh] = useState<DictionaryStats | null>(null);

  useEffect(() => {
    if (refreshKey === 0) return;
    fetch("/api/dictionary", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then(setFresh)
      .catch(() => {});
  }, [refreshKey]);

  const data = fresh ?? stats;

  if (mode === "sprint") {
    return (
      <DictionarySprint
        onExit={() => {
          setMode("overview");
          setRefreshKey((k) => k + 1);
        }}
        onHome={() => router.push("/")}
      />
    );
  }

  return (
    <main className="mx-auto w-full max-w-md px-4 pb-32">
      <h1 className="mt-2 flex items-center gap-2 px-1 font-display text-2xl font-bold">
        <BookA className="size-6 text-gold" /> Le dictionnaire
      </h1>
      <p className="mt-1 px-1 text-sm font-semibold text-white/50">
        {data ? data.total.toLocaleString("fr-FR") : "370 063"} mots anglais réels. Combien en
        connais-tu vraiment ?
      </p>

      {/* big counter */}
      <section className="card-night card-pop relative mt-4 overflow-hidden rounded-[2rem] p-6 text-center">
        <div className="pointer-events-none absolute -left-16 -top-16 size-48 rounded-full bg-gold/15 blur-3xl" />
        <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">
          Mots maîtrisés
        </p>
        <motion.p
          key={data?.known}
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="mt-1 font-display text-6xl font-bold tabular-nums text-gold text-glow-gold"
        >
          {(data?.known ?? 0).toLocaleString("fr-FR")}
        </motion.p>
        <p className="mt-1 text-sm font-bold text-white/45">
          {data ? (data.coverage * 100).toFixed(3) : "0.000"} % du dictionnaire
        </p>

        <button
          onClick={() => {
            playSound("tap");
            setMode("sprint");
          }}
          className="btn3d mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-gold to-pink-neon py-4 font-display text-lg font-bold text-night-950"
          style={{ ["--sh" as string]: "#92600e" }}
        >
          <Zap className="size-5" fill="currentColor" /> Lancer un sprint de mots
        </button>
        <p className="mt-2 text-[11px] font-semibold text-white/40">
          24 mots à évaluer · des mots inventés se cachent dedans
        </p>
      </section>

      {/* milestones */}
      <section className="mt-5">
        <h2 className="mb-2 flex items-center gap-2 px-1 font-display text-lg font-bold">
          <Target className="size-4 text-lime-neon" /> Les paliers
        </h2>
        <div className="grid gap-2">
          {data?.milestones.map((m, i) => (
            <motion.div
              key={m.count}
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.04 * i }}
              className={`flex items-center gap-3 rounded-2xl p-3 ring-1 ${
                m.reached ? "bg-lime-neon/10 ring-lime-neon/30" : "bg-white/[0.03] ring-white/8"
              }`}
            >
              <span
                className={`grid size-9 shrink-0 place-items-center rounded-xl font-display text-xs font-bold ${
                  m.reached ? "bg-lime-neon/20 text-lime-neon" : "bg-white/5 text-white/40"
                }`}
              >
                {m.reached ? <Check className="size-4" strokeWidth={3} /> : (m.count / 1000) + "k"}
              </span>
              <span className="min-w-0 flex-1">
                <span className={`block font-display text-sm font-bold ${m.reached ? "text-lime-neon" : "text-white/70"}`}>
                  {m.label}
                </span>
                <span className="block text-[11px] font-semibold text-white/45">{m.desc}</span>
              </span>
              <span className="shrink-0 text-xs font-extrabold tabular-nums text-white/40">
                {m.count.toLocaleString("fr-FR")}
              </span>
            </motion.div>
          ))}
        </div>
      </section>

      {/* bands */}
      <section className="mt-6">
        <h2 className="mb-2 flex items-center gap-2 px-1 font-display text-lg font-bold">
          <Layers3 className="size-4 text-cyan-neon" /> Couverture par fréquence
        </h2>
        <div className="card-night rounded-3xl p-4">
          {data?.bands.map((b) => (
            <div key={b.band} className="mb-3 last:mb-0">
              <div className="mb-1 flex items-baseline justify-between gap-2">
                <span className="truncate text-xs font-bold text-white/70">{b.label}</span>
                <span className="shrink-0 text-[11px] font-extrabold tabular-nums text-white/45">
                  {b.known.toLocaleString("fr-FR")} / {b.total.toLocaleString("fr-FR")}
                </span>
              </div>
              <div className="track h-2">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-neon to-lime-neon transition-all duration-700"
                  style={{ width: `${Math.min(100, b.coverage * 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
        <p className="mt-2 px-1 text-[11px] font-semibold leading-relaxed text-white/40">
          Les mots fréquents comptent le plus : connaître les 3 000 premiers couvre déjà ~90 % de
          l&apos;anglais parlé au quotidien.
        </p>
      </section>
    </main>
  );
}

/* ------------------------------------------------------------------ */

function DictionarySprint({ onExit, onHome }: { onExit: () => void; onHome: () => void }) {
  const [items, setItems] = useState<SprintItem[] | null>(null);
  const [index, setIndex] = useState(0);
  const [summary, setSummary] = useState<SessionSummary | null>(null);
  const [honesty, setHonesty] = useState<{ honest: boolean; falseAlarms: number; fakeTotal: number; registered: number } | null>(null);
  const claimsRef = useRef<Claim[]>([]);
  const submittedRef = useRef(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/dictionary/sprint", { cache: "no-store" });
    if (res.ok) {
      const data = (await res.json()) as { items: SprintItem[] };
      setItems(data.items);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const submit = useCallback(async () => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    const res = await fetch("/api/dictionary/sprint/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ claims: claimsRef.current }),
    });
    if (res.ok) {
      const data = await res.json();
      setHonesty({
        honest: data.honest,
        falseAlarms: data.falseAlarms,
        fakeTotal: data.fakeTotal,
        registered: data.registered,
      });
      setSummary(data as SessionSummary);
    }
  }, []);

  const answer = (claimedKnown: boolean) => {
    const item = items?.[index];
    if (!item) return;
    claimsRef.current.push({ ...item, claimedKnown });
    playSound(claimedKnown ? "correct" : "tap");
    if (claimedKnown) {
      smallPop(0.5, 0.55);
      speak(item.word);
    }
    if (index + 1 >= (items?.length ?? 0)) void submit();
    else setIndex((i) => i + 1);
  };

  if (summary) {
    return (
      <main className="mx-auto w-full max-w-md px-4 pb-28">
        {honesty && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-4 flex items-start gap-3 rounded-2xl p-4 ring-1 ${
              honesty.honest
                ? "bg-lime-neon/10 ring-lime-neon/30"
                : "bg-rose/15 ring-rose/40"
            }`}
          >
            <ShieldAlert
              className={`mt-0.5 size-5 shrink-0 ${honesty.honest ? "text-lime-neon" : "text-rose"}`}
            />
            <p className="text-xs font-semibold leading-relaxed text-white/80">
              {honesty.honest ? (
                <>
                  Test validé : tu as évité {honesty.fakeTotal - honesty.falseAlarms}/
                  {honesty.fakeTotal} mots inventés.{" "}
                  <span className="font-extrabold text-lime-neon">
                    +{honesty.registered} mots
                  </span>{" "}
                  ajoutés à ton dictionnaire.
                </>
              ) : (
                <>
                  Tu as revendiqué {honesty.falseAlarms} mots qui n&apos;existent pas — le test
                  n&apos;est pas comptabilisé. Sois honnête, c&apos;est ton vrai score qui compte !
                </>
              )}
            </p>
          </motion.div>
        )}
        <ResultScreen
          summary={summary}
          modeLabel="Sprint dictionnaire"
          onHome={onHome}
          onReplay={() => {
            submittedRef.current = false;
            claimsRef.current = [];
            setSummary(null);
            setHonesty(null);
            setIndex(0);
            setItems(null);
            void load();
          }}
        />
      </main>
    );
  }

  if (!items) {
    return (
      <div className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6">
        <div className="text-center">
          <motion.div
            animate={{ scale: [1, 1.15, 1] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="mx-auto grid size-20 place-items-center rounded-3xl bg-gold/15"
          >
            <BookA className="size-10 text-gold" />
          </motion.div>
          <p className="mt-4 font-display text-lg font-bold">Sélection de mots…</p>
          <p className="mt-1 text-xs font-semibold text-white/45">
            Piochés dans 370 000 entrées
          </p>
        </div>
      </div>
    );
  }

  const item = items[index];
  const progress = index / items.length;

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8">
      <div className="safe-top sticky top-0 z-30 -mx-5 bg-night-950/85 px-5 pb-2 pt-3 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onExit}
            aria-label="Quitter"
            className="grid size-10 shrink-0 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition active:scale-90"
          >
            <X className="size-4.5" />
          </button>
          <div className="track h-4 flex-1">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-gold to-pink-neon"
              animate={{ width: `${progress * 100}%` }}
            />
          </div>
          <span className="shrink-0 text-xs font-extrabold tabular-nums text-white/50">
            {index + 1}/{items.length}
          </span>
        </div>
      </div>

      <div className="mt-6 text-center">
        <p className="flex items-center justify-center gap-1.5 text-xs font-bold uppercase tracking-wider text-white/40">
          <Gauge className="size-3.5" /> Connais-tu ce mot ?
        </p>
      </div>

      <div className="flex flex-1 flex-col justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${index}-${item.word}`}
            initial={{ opacity: 0, y: 40, rotate: 2 }}
            animate={{ opacity: 1, y: 0, rotate: 0 }}
            exit={{ opacity: 0, y: -40, rotate: -2 }}
            transition={{ type: "spring", stiffness: 280, damping: 24 }}
            className="card-night card-pop rounded-[2rem] p-8 text-center"
          >
            <p className="break-words font-display text-4xl font-bold leading-tight">
              {item.word}
            </p>
            <button
              onClick={() => speak(item.word)}
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-white/60 ring-1 ring-white/10 active:scale-95"
            >
              <Sparkles className="size-3.5" /> Prononcer
            </button>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => answer(false)}
          className="btn3d rounded-2xl bg-night-700 py-4 font-display text-lg font-bold ring-1 ring-white/10"
          style={{ ["--sh" as string]: "#0d0a1d" }}
        >
          Jamais vu
        </button>
        <button
          onClick={() => answer(true)}
          className="btn3d rounded-2xl bg-lime-neon py-4 font-display text-lg font-bold text-night-950"
          style={{ ["--sh" as string]: "#3f6212" }}
        >
          Je connais
        </button>
      </div>
      <p className="mt-3 text-center text-[11px] font-semibold text-white/35">
        Des mots inventés sont mélangés : réponds honnêtement, sinon le test est annulé.
      </p>
    </div>
  );
}
