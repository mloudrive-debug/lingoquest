"use client";

import { motion } from "framer-motion";
import {
  Award,
  BookMarked,
  BookOpen,
  Brain,
  Flame,
  Layers,
  Library,
  Lock,
  PenLine,
  Rocket,
  Sparkles,
  Star,
  Target,
  Trophy,
  Zap,
} from "lucide-react";
import { useProfile } from "@/lib/hooks";

const BADGE_ICONS: Record<string, typeof Star> = {
  Rocket, Target, Flame, Zap, BookOpen, Library, PenLine, BookMarked, Brain, Trophy,
};

export default function BadgesPage() {
  const { profile } = useProfile();
  const unlocked = profile?.badges.filter((b) => b.unlocked).length ?? 0;

  const stats = [
    { label: "XP totaux", value: profile?.xp ?? 0, icon: Sparkles, color: "#8b7cff" },
    { label: "Précision", value: `${profile?.accuracy ?? 0}%`, icon: Target, color: "#a3e635" },
    { label: "Mots maîtrisés", value: profile?.masteredWords ?? 0, icon: Layers, color: "#5cd2ff" },
    { label: "Histoires lues", value: profile?.textsRead ?? 0, icon: BookMarked, color: "#ff5ca8" },
    { label: "Sessions", value: profile?.sessionsPlayed ?? 0, icon: Zap, color: "#ffc24b" },
    { label: "Série de jours", value: profile?.streak ?? 0, icon: Flame, color: "#ff6b81" },
  ];

  return (
    <main className="mx-auto w-full max-w-md px-4 pb-32">
      <h1 className="mt-2 flex items-center gap-2 px-1 font-display text-2xl font-bold">
        <Trophy className="size-6 text-gold" /> Tes succès
      </h1>
      <p className="mt-1 px-1 text-sm font-semibold text-white/50">
        {unlocked}/{profile?.badges.length ?? 10} badges débloqués — continue de jouer !
      </p>

      {/* progress */}
      <div className="track mt-4 h-3.5">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-gold to-pink-neon"
          initial={{ width: 0 }}
          animate={{ width: `${profile ? (unlocked / profile.badges.length) * 100 : 0}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>

      {/* stats */}
      <div className="mt-5 grid grid-cols-3 gap-2.5">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 * i }}
            className="card-night rounded-2xl p-3 text-center"
          >
            <s.icon className="mx-auto size-5" style={{ color: s.color }} />
            <p className="mt-1.5 font-display text-xl font-bold tabular-nums leading-none">{s.value}</p>
            <p className="mt-1 text-[9px] font-bold uppercase tracking-wider text-white/45">{s.label}</p>
          </motion.div>
        ))}
      </div>

      {/* badges grid */}
      <div className="mt-6 grid grid-cols-2 gap-3">
        {profile?.badges.map((b, i) => {
          const Icon = BADGE_ICONS[b.icon] ?? Star;
          return (
            <motion.div
              key={b.key}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + i * 0.05, type: "spring", stiffness: 260, damping: 18 }}
              className={`card-night card-pop relative overflow-hidden rounded-3xl p-4 ${
                b.unlocked ? "" : "opacity-60 saturate-0"
              }`}
            >
              {b.unlocked && (
                <div
                  className="pointer-events-none absolute -right-8 -top-8 size-24 rounded-full blur-2xl"
                  style={{ backgroundColor: b.color + "44" }}
                />
              )}
              <div
                className="relative grid size-12 place-items-center rounded-2xl"
                style={{
                  backgroundColor: b.unlocked ? b.color + "2b" : "rgb(255 255 255 / 0.06)",
                }}
              >
                {b.unlocked ? (
                  <Icon className="size-6" style={{ color: b.color }} fill="currentColor" />
                ) : (
                  <Lock className="size-5 text-white/40" />
                )}
              </div>
              <p className="mt-3 font-display text-base font-bold leading-tight">{b.name}</p>
              <p className="mt-1 text-xs font-semibold leading-snug text-white/50">{b.description}</p>
              {b.unlocked ? (
                <p className="mt-2 flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wider" style={{ color: b.color }}>
                  <Award className="size-3" /> Débloqué
                </p>
              ) : (
                <p className="mt-2 text-[10px] font-extrabold uppercase tracking-wider text-white/30">
                  À débloquer
                </p>
              )}
            </motion.div>
          );
        })}
      </div>
    </main>
  );
}
