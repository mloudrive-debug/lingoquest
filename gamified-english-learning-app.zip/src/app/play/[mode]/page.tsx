"use client";

import { use, useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { BookOpen, Brain, PenLine, Sparkles, BookMarked } from "lucide-react";
import SessionGame from "@/components/games/SessionGame";
import MatchGame from "@/components/games/MatchGame";
import ResultScreen from "@/components/games/ResultScreen";
import type { CefrGrade, McqQuestion, SessionSummary } from "@/lib/types";
import { playSound } from "@/lib/audio";

const MODE_META: Record<string, { label: string; icon: typeof BookOpen; color: string }> = {
  vocab: { label: "Défi vocabulaire", icon: BookOpen, color: "#8b7cff" },
  grammar: { label: "Mission grammaire", icon: PenLine, color: "#5cd2ff" },
  match: { label: "Memory", icon: Brain, color: "#ffc24b" },
  comprehension: { label: "Histoire du jour", icon: BookMarked, color: "#ff5ca8" },
};

type Payload =
  | { mode: "vocab" | "grammar"; total: number; grade: CefrGrade; questions: McqQuestion[] }
  | {
      mode: "comprehension";
      total: number;
      grade: CefrGrade;
      text: { id: number; title: string; content: string; cefr: string };
      questions: McqQuestion[];
    }
  | { mode: "match"; total: number; grade: CefrGrade; pairs: { itemId: number; en: string; fr: string }[] };

export default function PlayPage({ params }: { params: Promise<{ mode: string }> }) {
  const { mode } = use(params);
  const router = useRouter();
  const meta = MODE_META[mode] ?? MODE_META.vocab;

  const [payload, setPayload] = useState<Payload | null>(null);
  const [error, setError] = useState(false);
  const [summary, setSummary] = useState<SessionSummary | null>(null);
  const [sessionKey, setSessionKey] = useState(0);
  const startedRef = useRef(false);

  const start = useCallback(async () => {
    setPayload(null);
    setSummary(null);
    setError(false);
    try {
      const res = await fetch("/api/session/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode }),
      });
      if (!res.ok) throw new Error("bad");
      setPayload((await res.json()) as Payload);
    } catch {
      setError(true);
    }
  }, [mode]);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    void start();
    return () => {
      startedRef.current = false;
    };
  }, [start]);

  const Icon = meta.icon;

  if (error) {
    return (
      <div className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6 text-center">
        <div>
          <p className="font-display text-2xl font-bold">Oups, la session n&apos;a pas pu démarrer.</p>
          <button
            onClick={() => {
              playSound("tap");
              startedRef.current = false;
              void start();
            }}
            className="btn3d mt-5 rounded-2xl bg-violet-neon px-6 py-3.5 font-display font-bold"
            style={{ ["--sh" as string]: "#5848b8" }}
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  if (summary) {
    return (
      <ResultScreen
        summary={summary}
        modeLabel={meta.label}
        onHome={() => router.push("/")}
        onReplay={() => {
          startedRef.current = false;
          setSessionKey((k) => k + 1);
          void start();
        }}
      />
    );
  }

  if (!payload) {
    return (
      <div className="mx-auto grid min-h-dvh w-full max-w-md place-items-center px-6">
        <div className="text-center">
          <motion.div
            animate={{ scale: [1, 1.15, 1], rotate: [0, 8, -8, 0] }}
            transition={{ repeat: Infinity, duration: 1.6 }}
            className="mx-auto grid size-20 place-items-center rounded-3xl"
            style={{ backgroundColor: meta.color + "26", boxShadow: `0 0 50px ${meta.color}55` }}
          >
            <Icon className="size-10" style={{ color: meta.color }} />
          </motion.div>
          <p className="mt-5 font-display text-xl font-bold">{meta.label}</p>
          <p className="mt-1 flex items-center justify-center gap-1.5 text-sm font-semibold text-white/50">
            <Sparkles className="size-4 text-violet-neon" /> Difficulté calibrée pour toi…
          </p>
        </div>
      </div>
    );
  }

  if (payload.mode === "match") {
    return (
      <MatchGame
        key={sessionKey}
        pairs={payload.pairs}
        grade={payload.grade}
        onExit={() => router.push("/")}
        onDone={setSummary}
      />
    );
  }

  return (
    <SessionGame
      key={sessionKey}
      payload={payload}
      modeLabel={meta.label}
      onExit={() => router.push("/")}
      onDone={setSummary}
    />
  );
}
