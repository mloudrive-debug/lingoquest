import { NextResponse } from "next/server";
import { gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { userBadges, wordProgress, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import {
  BADGES,
  cefrInfo,
  getProfile,
  levelFromXp,
  masteryByGrade,
  wordOfTheDay,
} from "@/lib/game";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const profile = await getProfile();

  const [{ count: mastered }] = (await db
    .select({ count: sql<number>`count(*)::int` })
    .from(wordProgress)
    .where(gte(wordProgress.mastery, 4))) as { count: number }[];

  const [{ count: totalItems }] = (await db
    .select({ count: sql<number>`count(*)::int` })
    .from(words)) as { count: number }[];

  const unlockedRows = await db
    .select({ key: userBadges.badgeKey, at: userBadges.unlockedAt })
    .from(userBadges);
  const unlockedSet = new Set(unlockedRows.map((r) => r.key));

  const lvl = levelFromXp(profile.xp);
  const cefr = cefrInfo(profile.xp);
  const mastery = await masteryByGrade();
  const wotd = await wordOfTheDay();

  return NextResponse.json({
    name: profile.name,
    xp: profile.xp,
    level: lvl.level,
    levelProgress: lvl.progress,
    levelRemaining: lvl.remaining,
    nextLevelXp: lvl.nextLevelXp,
    streak: profile.streak,
    dailyXp: profile.dailyXp,
    dailyGoal: profile.dailyGoal,
    totalCorrect: profile.totalCorrect,
    totalAnswered: profile.totalAnswered,
    sessionsPlayed: profile.sessionsPlayed,
    masteredWords: mastered,
    totalItems,
    textsRead: profile.textsRead,
    grammarCorrect: profile.grammarCorrect,
    perfectMatches: profile.perfectMatches,
    accuracy:
      profile.totalAnswered > 0
        ? Math.round((profile.totalCorrect / profile.totalAnswered) * 100)
        : 0,
    cefr: {
      ...cefr,
      masteryByGrade: mastery,
    },
    wordOfTheDay: wotd
      ? {
          en: wotd.en,
          fr: wotd.fr,
          category: wotd.category,
          exampleEn: wotd.exampleEn,
          exampleFr: wotd.exampleFr,
        }
      : null,
    badges: BADGES.map((b) => ({
      ...b,
      unlocked: unlockedSet.has(b.key),
      unlockedAt: unlockedRows.find((r) => r.key === b.key)?.at ?? null,
    })),
  });
}
