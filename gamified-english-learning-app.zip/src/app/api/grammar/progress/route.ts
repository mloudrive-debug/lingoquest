import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { lessonProgress } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(lessonProgress);
  return NextResponse.json({
    lessons: rows.map((r) => ({
      slug: r.slug,
      read: r.readAt !== null,
      bestScore: r.bestScore,
      practiceTotal: r.practiceTotal,
    })),
  });
}

/** Marks a lesson as read. */
export async function POST(req: NextRequest) {
  const { slug } = (await req.json()) as { slug: string };
  if (!slug) return NextResponse.json({ error: "slug_required" }, { status: 400 });

  const existing = await db
    .select()
    .from(lessonProgress)
    .where(eq(lessonProgress.slug, slug))
    .limit(1);

  if (existing.length === 0) {
    await db.insert(lessonProgress).values({ slug, readAt: new Date() });
  } else if (!existing[0].readAt) {
    await db
      .update(lessonProgress)
      .set({ readAt: new Date() })
      .where(eq(lessonProgress.id, existing[0].id));
  }
  return NextResponse.json({ ok: true });
}
