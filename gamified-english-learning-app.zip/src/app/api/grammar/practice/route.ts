import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { grammarExercises, lessonProgress } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { shuffle } from "@/lib/game";

export const dynamic = "force-dynamic";

/** Quiz focused on a single lesson of the course. */
export async function POST(req: NextRequest) {
  await ensureSeeded();
  const { slug } = (await req.json()) as { slug: string };

  const rows = await db
    .select()
    .from(grammarExercises)
    .where(eq(grammarExercises.lessonSlug, slug));

  if (rows.length === 0) return NextResponse.json({ error: "no_exercises" }, { status: 404 });

  const questions = shuffle(rows).map((g) => {
    const options = shuffle(g.options);
    return {
      itemId: g.id,
      type: "mcq" as const,
      subtype: "grammar" as const,
      prompt: g.sentence,
      subPrompt: `${g.topic} · ${g.cefr}`,
      options,
      answerIndex: options.indexOf(g.options[g.answerIndex]),
      explanation: g.explanation,
    };
  });

  return NextResponse.json({ total: questions.length, questions });
}

/** Stores the score obtained on a lesson quiz. */
export async function PUT(req: NextRequest) {
  const { slug, correct, total } = (await req.json()) as {
    slug: string;
    correct: number;
    total: number;
  };
  const score = total > 0 ? Math.round((correct / total) * 100) : 0;

  const existing = await db
    .select()
    .from(lessonProgress)
    .where(eq(lessonProgress.slug, slug))
    .limit(1);

  if (existing.length === 0) {
    await db.insert(lessonProgress).values({
      slug,
      readAt: new Date(),
      practiceCorrect: correct,
      practiceTotal: total,
      bestScore: score,
    });
  } else {
    const p = existing[0];
    await db
      .update(lessonProgress)
      .set({
        practiceCorrect: p.practiceCorrect + correct,
        practiceTotal: p.practiceTotal + total,
        bestScore: Math.max(p.bestScore, score),
        readAt: p.readAt ?? new Date(),
      })
      .where(eq(lessonProgress.id, p.id));
  }
  return NextResponse.json({ ok: true, bestScore: score });
}
