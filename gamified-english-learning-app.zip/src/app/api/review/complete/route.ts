import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, wordProgress } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { cefrInfo, getProfile, levelFromXp, todayStr, unlockEligibleBadges, yesterdayStr } from "@/lib/game";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  await ensureSeeded();
  const body = (await req.json()) as { known: number[]; unknown: number[] };
  const known = body.known ?? [];
  const unknown = body.unknown ?? [];
  const total = known.length + unknown.length;

  // Update mastery
  for (const id of known) {
    const rows = await db.select().from(wordProgress).where(eq(wordProgress.wordId, id)).limit(1);
    if (rows.length === 0) {
      await db.insert(wordProgress).values({ wordId: id, mastery: 2, correctCount: 1, lastSeenAt: new Date() });
    } else {
      await db
        .update(wordProgress)
        .set({
          mastery: Math.min(5, rows[0].mastery + 2),
          correctCount: rows[0].correctCount + 1,
          lastSeenAt: new Date(),
        })
        .where(eq(wordProgress.id, rows[0].id));
    }
  }
  for (const id of unknown) {
    const rows = await db.select().from(wordProgress).where(eq(wordProgress.wordId, id)).limit(1);
    if (rows.length === 0) {
      await db.insert(wordProgress).values({ wordId: id, mastery: 0, wrongCount: 1, lastSeenAt: new Date() });
    } else {
      await db
        .update(wordProgress)
        .set({
          mastery: Math.max(0, rows[0].mastery - 1),
          wrongCount: rows[0].wrongCount + 1,
          lastSeenAt: new Date(),
        })
        .where(eq(wordProgress.id, rows[0].id));
    }
  }

  const xpGained = known.length * 5 + Math.min(4, total);

  const profile = await getProfile();
  const cefrBefore = cefrInfo(profile.xp);
  const beforeLevel = levelFromXp(profile.xp).level;
  const lastActive = profile.lastActiveDate;
  let streak = profile.streak;
  if (lastActive !== todayStr()) {
    streak = lastActive === yesterdayStr() ? streak + 1 : 1;
  }
  const afterXp = profile.xp + xpGained;
  const afterLevel = levelFromXp(afterXp).level;
  const levelUp = afterLevel > beforeLevel;
  const cefrAfter = cefrInfo(afterXp);
  const gradeUp = cefrAfter.grade !== cefrBefore.grade;

  const [updatedProfile] = await db
    .update(profiles)
    .set({
      xp: afterXp,
      streak,
      lastActiveDate: todayStr(),
      dailyXp: profile.dailyXp + xpGained,
      sessionsPlayed: profile.sessionsPlayed + 1,
      knownWords: profile.knownWords + known.length,
    })
    .where(eq(profiles.id, 1))
    .returning();

  const newBadges = await unlockEligibleBadges({
    streak,
    level: afterLevel,
    grade: cefrAfter.grade,
  });

  return NextResponse.json({
    xpGained,
    correct: known.length,
    total,
    accuracy: total > 0 ? Math.round((known.length / total) * 100) : 0,
    levelUp,
    level: afterLevel,
    gradeUp,
    cefrGrade: cefrAfter.grade,
    cefrProgress: cefrAfter.gradeProgress,
    streak,
    dailyXp: updatedProfile.dailyXp,
    dailyGoal: updatedProfile.dailyGoal,
    newBadges,
  });
}
