import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { wordProgress, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getProfile } from "@/lib/game";

export const dynamic = "force-dynamic";

/** Cards due for review: unseen first, then weakest mastery. No hearts needed. */
export async function GET() {
  await ensureSeeded();
  await getProfile();

  const all = await db
    .select({
      id: words.id,
      en: words.en,
      fr: words.fr,
      category: words.category,
      exampleEn: words.exampleEn,
      exampleFr: words.exampleFr,
      mastery: wordProgress.mastery,
    })
    .from(words)
    .leftJoin(wordProgress, eq(wordProgress.wordId, words.id));

  const unseen = all
    .filter((w) => w.mastery === null)
    .sort(() => Math.random() - 0.5)
    .slice(0, 4);
  const weak = all
    .filter((w): w is typeof w & { mastery: number } => w.mastery !== null)
    .sort((a, b) => a.mastery - b.mastery || Math.random() - 0.5)
    .slice(0, 8);

  const cards = [...unseen, ...weak]
    .sort(() => Math.random() - 0.5)
    .slice(0, 10)
    .map((w) => ({
      id: w.id,
      en: w.en,
      fr: w.fr,
      category: w.category,
      exampleEn: w.exampleEn,
      exampleFr: w.exampleFr,
      mastery: w.mastery ?? 0,
      isNew: w.mastery === null,
    }));

  return NextResponse.json({ cards, total: cards.length });
}
