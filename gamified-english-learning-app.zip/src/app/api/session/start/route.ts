import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  comprehensionQuestions,
  comprehensionTexts,
  grammarExercises,
  wordProgress,
  words,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { CEFR_GRADES, cefrInfo, getProfile, gradeDistance, shuffle } from "@/lib/game";

export const dynamic = "force-dynamic";

type Mode = "vocab" | "grammar" | "match" | "comprehension";

type WordWithProgress = {
  id: number;
  en: string;
  fr: string;
  category: string;
  cefr: string;
  exampleEn: string;
  exampleFr: string;
  mastery: number | null;
};

/** Probability of EN→FR (easier) per grade index. FR→EN = harder recall. */
const EN2FR_PROBA = [0.7, 0.55, 0.4, 0.3, 0.25, 0.2];

/**
 * Adaptive word picking: mostly current CEFR grade, sprinkle of the next
 * grade (stretch zone) and of previous grades (active recall review),
 * weighted down for already mastered items.
 */
async function pickAdaptiveWords(count: number, gradeIndex: number, maxTextLen?: number) {
  const all = await db
    .select({
      id: words.id,
      en: words.en,
      fr: words.fr,
      category: words.category,
      cefr: words.cefr,
      exampleEn: words.exampleEn,
      exampleFr: words.exampleFr,
      mastery: wordProgress.mastery,
    })
    .from(words)
    .leftJoin(wordProgress, eq(wordProgress.wordId, words.id));

  const weighted: { w: WordWithProgress; weight: number }[] = [];
  for (const w of all) {
    if (maxTextLen && (w.en.length > maxTextLen || w.fr.length > maxTextLen)) continue;
    const d = gradeDistance(w.cefr, gradeIndex);
    let zone: number;
    if (d === 0) zone = 1; // sweet spot
    else if (d === 1) zone = 0.65; // stretch: next grade
    else if (d === -1) zone = 0.5; // review previous grade
    else if (d === 2) zone = 0.22; // light peek above
    else if (d <= -2) zone = 0.18; // older revision
    else zone = 0.06;

    const masteryFactor = w.mastery === null ? 1.15 : Math.max(0.15, (5.2 - w.mastery) / 5);
    weighted.push({ w, weight: zone * masteryFactor * (0.75 + Math.random() * 0.5) });
  }
  weighted.sort((a, b) => b.weight - a.weight);
  return weighted.slice(0, count).map((x) => x.w);
}

type WordItem = { id: number; en: string; fr: string; category: string };

function uniqueOptions(correct: string, distractors: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const v of [correct, ...distractors]) {
    if (!seen.has(v)) {
      seen.add(v);
      out.push(v);
    }
  }
  return out;
}

function distractorsFor(
  correct: WordItem,
  pool: WordItem[],
  field: "en" | "fr",
  n: number,
): string[] {
  const sameCat = pool.filter((w) => w.id !== correct.id && w.category === correct.category);
  const others = pool.filter((w) => w.id !== correct.id && w.category !== correct.category);
  return [...shuffle(sameCat), ...shuffle(others)].slice(0, n).map((d) => d[field]);
}

function escapeRegExp(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Replace the headword inside its example sentence with a cloze blank. */
function makeCloze(exampleEn: string, en: string): string | null {
  let core = en.replace(/^(to|a|an|the)\s+/i, "").trim();
  core = core.split("/")[0].trim(); // first variant only
  if (core.length < 3) return null;
  const re = new RegExp(`\\b${escapeRegExp(core)}\\b`, "i");
  if (!re.test(exampleEn)) return null;
  return exampleEn.replace(re, "___");
}

export async function POST(req: NextRequest) {
  await ensureSeeded();
  const body = (await req.json().catch(() => ({}))) as { mode?: Mode };
  const mode = body.mode ?? "vocab";

  const profile = await getProfile();
  const cefr = cefrInfo(profile.xp);
  const gi = cefr.gradeIndex;

  if (mode === "vocab") {
    const picked = await pickAdaptiveWords(10, gi);
    const pool = shuffle(await db.select().from(words));
    const en2fr = EN2FR_PROBA[gi];

    const questions = picked.map((w) => {
      // B1+ : some questions become cloze (fill the sentence in English)
      const clozeText = gi >= 2 && Math.random() < 0.4 ? makeCloze(w.exampleEn, w.en) : null;
      if (clozeText) {
        const options = uniqueOptions(w.en, distractorsFor(w, pool, "en", 3));
        return {
          itemId: w.id,
          type: "mcq" as const,
          subtype: "cloze" as const,
          prompt: clozeText,
          subPrompt: w.category,
          hint: w.exampleFr,
          options: shuffle(options),
          answerIndex: 0, // fixed after shuffle below
          exampleEn: w.exampleEn,
          exampleFr: w.exampleFr,
          answerWord: w.en,
        };
      }
      const direction = Math.random() < en2fr ? ("en2fr" as const) : ("fr2en" as const);
      const field = direction === "en2fr" ? "fr" : "en";
      const options = uniqueOptions(w[field], distractorsFor(w, pool, field, 3));
      const shuffled = shuffle(options);
      return {
        itemId: w.id,
        type: "mcq" as const,
        subtype: "translate" as const,
        direction,
        prompt: direction === "en2fr" ? w.en : w.fr,
        subPrompt: w.category,
        options: shuffled,
        answerIndex: shuffled.indexOf(w[field]),
        exampleEn: w.exampleEn,
        exampleFr: w.exampleFr,
        answerWord: w.en,
      };
    }).map((q) =>
      q.subtype === "cloze"
        ? { ...q, answerIndex: q.options.indexOf(q.answerWord ?? "") }
        : q,
    );

    return NextResponse.json({ mode, total: questions.length, grade: cefr.grade, questions });
  }

  if (mode === "grammar") {
    const all = await db.select().from(grammarExercises);
    // Keep exercises at or one grade above the player, biased to current grade
    const candidates = all.filter((g) =>gradeDistance(g.cefr, gi) <= 1);
    const weighted = shuffle(
      candidates.flatMap((g) => {
        const d = gradeDistance(g.cefr, gi);
        const copies = d === 0 ? 3 : d === 1 ? 2 : 1;
        return Array.from({ length: copies }, () => g);
      }),
    );
    const seen = new Set<number>();
    const picked = weighted.filter((g) => (seen.has(g.id) ? false : (seen.add(g.id), true))).slice(0, 10);

    const questions = picked.map((g) => {
      const order = shuffle(g.options.map((_, i) => i));
      const options = order.map((i) => g.options[i]);
      return {
        itemId: g.id,
        type: "mcq" as const,
        subtype: "grammar" as const,
        prompt: g.sentence,
        subPrompt: `${g.topic} · ${g.cefr}`,
        options,
        answerIndex: options.indexOf(g.options[g.answerIndex]),
        explanation: g.explanation,
      };
    });
    return NextResponse.json({ mode, total: questions.length, grade: cefr.grade, questions });
  }

  if (mode === "match") {
    const picked = await pickAdaptiveWords(8, gi, 22);
    return NextResponse.json({
      mode,
      total: picked.length,
      grade: cefr.grade,
      pairs: picked.map((w) => ({ itemId: w.id, en: w.en, fr: w.fr })),
    });
  }

  if (mode === "comprehension") {
    const texts = await db.select().from(comprehensionTexts);
    if (texts.length === 0) return NextResponse.json({ error: "no_texts" }, { status: 404 });
    // Hardest text the player is allowed to read: current grade or one above
    const allowed = texts.filter((t) => gradeDistance(t.cefr ?? "A1", gi) <= 1);
    const pool = allowed.length > 0 ? allowed : texts;
    const maxGrade = Math.max(...pool.map((t) => gradeDistance(t.cefr ?? "A1", gi)));
    const best = pool.filter((t) => gradeDistance(t.cefr ?? "A1", gi) === maxGrade);
    const text = best[Math.floor(Math.random() * best.length)];

    const qs = await db
      .select()
      .from(comprehensionQuestions)
      .where(eq(comprehensionQuestions.textId, text.id));
    const questions = shuffle(qs).map((q) => {
      const order = shuffle(q.options.map((_, i) => i));
      const options = order.map((i) => q.options[i]);
      return {
        itemId: q.id,
        type: "mcq" as const,
        subtype: "comprehension" as const,
        prompt: q.question,
        options,
        answerIndex: options.indexOf(q.options[q.answerIndex]),
      };
    });
    return NextResponse.json({
      mode,
      total: questions.length,
      grade: cefr.grade,
      text: { id: text.id, title: text.title, content: text.content, cefr: text.cefr ?? "A1" },
      questions,
    });
  }

  return NextResponse.json({ error: "unknown_mode" }, { status: 400 });
}
