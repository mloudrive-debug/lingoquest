import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, wordProgress, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { markWordsKnown } from "@/lib/dictionary";
import { getProfile, levelFromXp, todayStr, unlockEligibleBadges, yesterdayStr, cefrInfo } from "@/lib/game";

export const dynamic = "force-dynamic";

type Answer = { itemId: number; correct: boolean };
type Mode = "vocab" | "grammar" | "comprehension" | "match";

const BASE_XP: Record<Mode, number> = {
  vocab: 10,
  grammar: 10,
  comprehension: 12,
  match: 8,
};

export async function POST(req: NextRequest) {
  await ensureSeeded();
  const body = (await req.json()) as {
    mode: Mode;
    answers: Answer[];
    perfectMatch?: boolean;
    textId?: number;
  };

  const { mode, answers, perfectMatch = false } = body;
  const correct = answers.filter((a) => a.correct).length;
  const total = answers.length;
  const perfect = total > 0 && correct === total;

  // --- XP (computed server-side; harder content pays more) ---
  let xpGained = correct * (BASE_XP[mode] ?? 10);
  if (perfect && total >= 3) xpGained += 15;
  xpGained = Math.max(xpGained, Math.min(4, total)); // small consolation

  // --- Per-item spaced repetition (vocab & match touch word mastery) ---
  const masteredNow: string[] = [];
  if (mode === "vocab" || mode === "match") {
    for (const a of answers) {
      const existing = await db
        .select()
        .from(wordProgress)
        .where(eq(wordProgress.wordId, a.itemId))
        .limit(1);
      if (existing.length === 0) {
        await db.insert(wordProgress).values({
          wordId: a.itemId,
          mastery: a.correct ? 1 : 0,
          correctCount: a.correct ? 1 : 0,
          wrongCount: a.correct ? 0 : 1,
          lastSeenAt: new Date(),
        });
      } else {
        const p = existing[0];
        const newMastery = Math.max(0, Math.min(5, p.mastery + (a.correct ? 1 : -1)));
        await db
          .update(wordProgress)
          .set({
            mastery: newMastery,
            correctCount: p.correctCount + (a.correct ? 1 : 0),
            wrongCount: p.wrongCount + (a.correct ? 0 : 1),
            lastSeenAt: new Date(),
          })
          .where(eq(wordProgress.id, p.id));
        if (newMastery >= 3 && p.mastery < 3) {
          const [w] = await db
            .select({ en: words.en })
            .from(words)
            .where(eq(words.id, a.itemId))
            .limit(1);
          if (w) masteredNow.push(w.en);
        }
      }
    }
  }

  // A curated word that sticks also counts in the full dictionary coverage
  if (masteredNow.length > 0) {
    await markWordsKnown(masteredNow, "game").catch(() => 0);
  }

  // --- Profile updates ---
  const profile = await getProfile();
  const cefrBefore = cefrInfo(profile.xp);
  const beforeLevel = levelFromXp(profile.xp).level;

  const lastActive = profile.lastActiveDate;
  let streak = profile.streak;
  if (lastActive !== todayStr()) {
    streak = lastActive === yesterdayStr() ? streak + 1 : 1;
  }

  const afterXp = profile.xp + xpGained;
  const afterLevel = levelFromXp(afterXp).level;
  const levelUp = afterLevel > beforeLevel;
  const cefrAfter = cefrInfo(afterXp);
  const gradeUp = cefrAfter.grade !== cefrBefore.grade;

  const patch: Record<string, unknown> = {
    xp: afterXp,
    streak,
    lastActiveDate: todayStr(),
    dailyXp: profile.dailyXp + xpGained,
    totalCorrect: profile.totalCorrect + correct,
    totalAnswered: profile.totalAnswered + total,
    sessionsPlayed: profile.sessionsPlayed + 1,
  };
  if (mode === "grammar") patch.grammarCorrect = profile.grammarCorrect + correct;
  if (mode === "comprehension") patch.textsRead = profile.textsRead + 1;
  if (mode === "match" && perfectMatch) patch.perfectMatches = profile.perfectMatches + 1;

  const [updated] = await db.update(profiles).set(patch).where(eq(profiles.id, 1)).returning();

  // --- Badges ---
  const newBadges = await unlockEligibleBadges({
    perfect: perfect && total >= 3,
    streak,
    grammarCorrect: (patch.grammarCorrect as number | undefined) ?? profile.grammarCorrect,
    textsRead: (patch.textsRead as number | undefined) ?? profile.textsRead,
    perfectMatch: mode === "match" && perfectMatch,
    level: afterLevel,
    grade: cefrAfter.grade,
  });

  return NextResponse.json({
    xpGained,
    correct,
    total,
    accuracy: total > 0 ? Math.round((correct / total) * 100) : 0,
    perfect,
    levelUp,
    level: afterLevel,
    gradeUp,
    cefrGrade: cefrAfter.grade,
    cefrProgress: cefrAfter.gradeProgress,
    streak,
    dailyXp: updated.dailyXp,
    dailyGoal: updated.dailyGoal,
    newBadges,
  });
}
