import { NextResponse } from "next/server";
import { inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { dictionary, dictionaryKnown } from "@/db/schema";
import { ensureDictionaryImported } from "@/db/dictionary-seed";
import { cefrInfo, getProfile, shuffle } from "@/lib/game";

export const dynamic = "force-dynamic";

/** Bands sampled per CEFR grade index (A1 → C2). */
const BAND_PLAN: number[][] = [
  [1, 1, 2, 2, 3], // A1
  [1, 2, 2, 3, 3], // A2
  [2, 2, 3, 3, 4], // B1
  [2, 3, 3, 4, 5], // B2
  [3, 3, 4, 5, 6], // C1
  [3, 4, 5, 6, 7], // C2
];

const VOWELS = "aeiou";
const CONS = "bcdfgklmnprstv";

/** Build a plausible but non-existent English-looking word. */
function mutate(word: string): string {
  const chars = word.split("");
  const positions = shuffle(chars.map((_, i) => i)).slice(0, chars.length > 6 ? 2 : 1);
  for (const p of positions) {
    const c = chars[p];
    const pool = VOWELS.includes(c) ? VOWELS : CONS;
    const replacement = pool[Math.floor(Math.random() * pool.length)];
    chars[p] = replacement === c ? pool[(pool.indexOf(c) + 1) % pool.length] : replacement;
  }
  return chars.join("");
}

export async function GET() {
  await ensureDictionaryImported();
  const profile = await getProfile();
  const gi = cefrInfo(profile.xp).gradeIndex;
  const plan = BAND_PLAN[gi];

  // 18 real words spread over the planned bands, never already marked known
  const real: { id: number; word: string; band: number }[] = [];
  const perBand = Math.ceil(18 / plan.length);
  for (const band of plan) {
    const rows = (await db.execute(sql`
      SELECT d.id, d.word, d.band
      FROM dictionary d
      LEFT JOIN dictionary_known k ON k.dictionary_id = d.id
      WHERE d.band = ${band} AND k.id IS NULL
      ORDER BY random()
      LIMIT ${perBand}
    `)) as unknown as { rows: { id: number; word: string; band: number }[] };
    real.push(...rows.rows);
  }

  // 6 pseudo-words derived from real ones, checked against the dictionary
  const seedRows = (await db.execute(sql`
    SELECT word FROM dictionary WHERE band <= 4 AND length(word) BETWEEN 5 AND 9
    ORDER BY random() LIMIT 24
  `)) as unknown as { rows: { word: string }[] };

  // Keep only pronounceable-looking forms (no exotic consonant clusters)
  const UGLY = /[bcdfgjkmpqtvwxz]{3}/;
  const candidates = Array.from(
    new Set(
      seedRows.rows
        .map((r) => mutate(r.word))
        .filter((w) => /^[a-z]{4,12}$/.test(w) && !UGLY.test(w) && /[aeiou]/.test(w)),
    ),
  );
  const collisions =
    candidates.length > 0
      ? await db
          .select({ word: dictionary.word })
          .from(dictionary)
          .where(inArray(dictionary.word, candidates))
      : [];
  const taken = new Set(collisions.map((c) => c.word));
  const fakes = candidates.filter((w) => !taken.has(w)).slice(0, 6);

  const items = shuffle([
    ...real.slice(0, 18).map((r) => ({
      id: r.id,
      word: r.word,
      band: r.band,
      isReal: true as const,
    })),
    ...fakes.map((w) => ({ id: -1, word: w, band: 0, isReal: false as const })),
  ]);

  return NextResponse.json({ total: items.length, grade: cefrInfo(profile.xp).grade, items });
}


