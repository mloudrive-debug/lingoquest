import { NextRequest, NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { dictionary, dictionaryKnown, profiles } from "@/db/schema";
import { cefrInfo, getProfile, levelFromXp, todayStr, unlockEligibleBadges, yesterdayStr } from "@/lib/game";

export const dynamic = "force-dynamic";

type Claim = { id: number; isReal: boolean; claimedKnown: boolean; band: number };

export async function POST(req: NextRequest) {
  const { claims } = (await req.json()) as { claims: Claim[] };

  const realClaims = claims.filter((c) => c.isReal);
  const fakeClaims = claims.filter((c) => !c.isReal);

  const claimedReal = realClaims.filter((c) => c.claimedKnown);
  const falseAlarms = fakeClaims.filter((c) => c.claimedKnown).length;
  const falseAlarmRate = fakeClaims.length > 0 ? falseAlarms / fakeClaims.length : 0;

  // Honesty gate: too many invented words claimed → results discarded
  const honest = falseAlarmRate <= 0.34;
  let registered = 0;

  if (honest && claimedReal.length > 0) {
    const ids = claimedReal.map((c) => c.id).filter((id) => id > 0);
    if (ids.length > 0) {
      const rows = await db
        .select({ id: dictionary.id, band: dictionary.band })
        .from(dictionary)
        .where(inArray(dictionary.id, ids));
      if (rows.length > 0) {
        await db
          .insert(dictionaryKnown)
          .values(rows.map((r) => ({ dictionaryId: r.id, band: r.band, source: "sprint" })))
          .onConflictDoNothing();
        registered = rows.length;
      }
    }
  }

  // XP: rewards honesty and breadth, not blind tapping
  const xpGained = honest ? Math.round(registered * 3 + (fakeClaims.length - falseAlarms) * 2) : 5;

  const profile = await getProfile();
  const beforeLevel = levelFromXp(profile.xp).level;
  const cefrBefore = cefrInfo(profile.xp);
  let streak = profile.streak;
  if (profile.lastActiveDate !== todayStr()) {
    streak = profile.lastActiveDate === yesterdayStr() ? streak + 1 : 1;
  }
  const afterXp = profile.xp + xpGained;
  const cefrAfter = cefrInfo(afterXp);
  const afterLevel = levelFromXp(afterXp).level;

  const [updated] = await db
    .update(profiles)
    .set({
      xp: afterXp,
      streak,
      lastActiveDate: todayStr(),
      dailyXp: profile.dailyXp + xpGained,
      sessionsPlayed: profile.sessionsPlayed + 1,
    })
    .where(eq(profiles.id, 1))
    .returning();

  const newBadges = await unlockEligibleBadges({
    streak,
    level: afterLevel,
    grade: cefrAfter.grade,
  });

  return NextResponse.json({
    xpGained,
    correct: registered,
    total: realClaims.length,
    accuracy: realClaims.length > 0 ? Math.round((registered / realClaims.length) * 100) : 0,
    honest,
    falseAlarms,
    fakeTotal: fakeClaims.length,
    registered,
    levelUp: afterLevel > beforeLevel,
    level: afterLevel,
    gradeUp: cefrAfter.grade !== cefrBefore.grade,
    cefrGrade: cefrAfter.grade,
    cefrProgress: cefrAfter.gradeProgress,
    streak,
    dailyXp: updated.dailyXp,
    dailyGoal: updated.dailyGoal,
    newBadges,
  });
}
