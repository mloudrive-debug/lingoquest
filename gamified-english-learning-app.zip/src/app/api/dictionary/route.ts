import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { dictionary, dictionaryKnown } from "@/db/schema";
import { ensureDictionaryImported } from "@/db/dictionary-seed";

export const dynamic = "force-dynamic";

/** Bands weights used to extrapolate a vocabulary estimate. */
export const BAND_LABELS: Record<number, string> = {
  1: "Les 1 000 mots les plus fréquents",
  2: "Top 3 000",
  3: "Top 10 000",
  4: "Top 25 000",
  5: "Top 50 000",
  6: "Mots courants peu fréquents",
  7: "Mots rares",
  8: "Mots très rares / techniques",
};

export const MILESTONES = [
  { count: 500, label: "Survie", desc: "Se débrouiller en voyage" },
  { count: 1000, label: "Conversation", desc: "Tenir une discussion simple" },
  { count: 3000, label: "Aisance", desc: "90 % de l'anglais courant" },
  { count: 5000, label: "Confort B2", desc: "Films et séries sans sous-titres" },
  { count: 10000, label: "Avancé C1", desc: "Presse, romans, débats" },
  { count: 20000, label: "Natif cultivé", desc: "Niveau d'un adulte anglophone" },
  { count: 35000, label: "Érudit", desc: "Vocabulaire littéraire et technique" },
];

export async function GET() {
  await ensureDictionaryImported();

  const [{ total }] = (await db
    .select({ total: sql<number>`count(*)::int` })
    .from(dictionary)) as { total: number }[];

  const [{ known }] = (await db
    .select({ known: sql<number>`count(*)::int` })
    .from(dictionaryKnown)) as { known: number }[];

  // known + total per band → coverage and extrapolated estimate
  const totals = (await db
    .select({ band: dictionary.band, count: sql<number>`count(*)::int` })
    .from(dictionary)
    .groupBy(dictionary.band)) as { band: number; count: number }[];

  const knowns = (await db
    .select({ band: dictionaryKnown.band, count: sql<number>`count(*)::int` })
    .from(dictionaryKnown)
    .groupBy(dictionaryKnown.band)) as { band: number; count: number }[];

  const totalMap = new Map(totals.map((t) => [t.band, t.count]));
  const knownMap = new Map(knowns.map((k) => [k.band, k.count]));

  const bands = [1, 2, 3, 4, 5, 6, 7, 8].map((band) => {
    const t = totalMap.get(band) ?? 0;
    const k = knownMap.get(band) ?? 0;
    return {
      band,
      label: BAND_LABELS[band],
      total: t,
      known: k,
      coverage: t > 0 ? k / t : 0,
    };
  });

  const nextMilestone = MILESTONES.find((m) => m.count > known) ?? MILESTONES[MILESTONES.length - 1];
  const passedMilestones = MILESTONES.filter((m) => m.count <= known);

  return NextResponse.json({
    total,
    known,
    coverage: total > 0 ? known / total : 0,
    bands,
    milestones: MILESTONES.map((m) => ({ ...m, reached: m.count <= known })),
    nextMilestone,
    milestoneProgress:
      nextMilestone.count > 0 ? Math.min(1, known / nextMilestone.count) : 1,
    lastMilestone: passedMilestones[passedMilestones.length - 1] ?? null,
  });
}
