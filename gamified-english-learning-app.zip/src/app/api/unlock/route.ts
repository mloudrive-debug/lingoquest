import { createHash } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function hash(input: string): string {
  return createHash("sha256").update("lq-lock:" + input).digest("hex");
}

export async function POST(req: NextRequest) {
  const pwd = process.env.APP_PASSWORD;
  if (!pwd) return NextResponse.json({ ok: true });

  const { password } = (await req.json().catch(() => ({}))) as { password?: string };
  if (!password || password !== pwd) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set("lq-auth", hash(pwd), {
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    maxAge: 60 * 60 * 24 * 180, // 6 mois
    path: "/",
  });
  return res;
}
