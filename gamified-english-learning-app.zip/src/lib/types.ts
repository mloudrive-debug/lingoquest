export type Mode = "vocab" | "grammar" | "match" | "comprehension";

export type CefrGrade = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type McqQuestion = {
  itemId: number;
  type: "mcq";
  subtype?: "translate" | "cloze" | "grammar" | "comprehension";
  direction?: "en2fr" | "fr2en";
  prompt: string;
  subPrompt?: string;
  hint?: string;
  options: string[];
  answerIndex: number;
  explanation?: string;
  exampleEn?: string;
  exampleFr?: string;
  answerWord?: string;
};

export type SessionSummary = {
  xpGained: number;
  correct: number;
  total: number;
  accuracy: number;
  levelUp: boolean;
  level: number;
  gradeUp: boolean;
  cefrGrade: CefrGrade;
  cefrProgress: number;
  streak: number;
  dailyXp: number;
  dailyGoal: number;
  newBadges: { key: string; name: string; description: string; icon: string; color: string }[];
};

export type BadgeInfo = {
  key: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  unlocked: boolean;
  unlockedAt: string | null;
};

export type CefrData = {
  index: number;
  grade: CefrGrade;
  gradeIndex: number;
  gradeProgress: number;
  overallProgress: number;
  nextGrade: CefrGrade | null;
  xpToNextGrade: number;
  isMax: boolean;
  masteryByGrade: Record<CefrGrade, number>;
};

export type ProfileData = {
  name: string;
  xp: number;
  level: number;
  levelProgress: number;
  levelRemaining: number;
  nextLevelXp: number;
  streak: number;
  dailyXp: number;
  dailyGoal: number;
  totalCorrect: number;
  totalAnswered: number;
  sessionsPlayed: number;
  masteredWords: number;
  totalItems: number;
  textsRead: number;
  grammarCorrect: number;
  perfectMatches: number;
  accuracy: number;
  cefr: CefrData;
  wordOfTheDay: {
    en: string;
    fr: string;
    category: string;
    exampleEn: string;
    exampleFr: string;
  } | null;
  badges: BadgeInfo[];
};

export type ReviewCard = {
  id: number;
  en: string;
  fr: string;
  category: string;
  exampleEn: string;
  exampleFr: string;
  mastery: number;
  isNew: boolean;
};
