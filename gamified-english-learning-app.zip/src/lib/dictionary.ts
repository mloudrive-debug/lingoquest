import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { dictionary, dictionaryKnown } from "@/db/schema";

/**
 * Marks dictionary entries as known from their plain text form.
 * Used when the player masters a curated word or passes a sprint item.
 */
export async function markWordsKnown(wordTexts: string[], source: string): Promise<number> {
  const cleaned = Array.from(
    new Set(
      wordTexts
        .map((w) => w.toLowerCase().trim().replace(/^(to|a|an|the)\s+/, ""))
        .flatMap((w) => (w.includes(" ") ? w.split(/\s+/) : [w])) // expressions → mots
        .map((w) => w.replace(/[^a-z]/g, ""))
        .filter((w) => w.length >= 2 && w.length <= 24),
    ),
  );
  if (cleaned.length === 0) return 0;

  const found = await db
    .select({ id: dictionary.id, band: dictionary.band })
    .from(dictionary)
    .where(inArray(dictionary.word, cleaned));
  if (found.length === 0) return 0;

  await db
    .insert(dictionaryKnown)
    .values(found.map((f) => ({ dictionaryId: f.id, band: f.band, source })))
    .onConflictDoNothing();

  return found.length;
}
