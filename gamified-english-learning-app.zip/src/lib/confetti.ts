"use client";

import confetti from "canvas-confetti";

const PALETTE = ["#8b7cff", "#ff5ca8", "#a3e635", "#ffc24b", "#5cd2ff", "#ffffff"];

export function smallPop(x = 0.5, y = 0.5) {
  confetti({
    particleCount: 45,
    spread: 70,
    startVelocity: 32,
    origin: { x, y },
    colors: PALETTE,
    disableForReducedMotion: true,
  });
}

export function winBurst() {
  confetti({
    particleCount: 120,
    spread: 100,
    startVelocity: 42,
    origin: { y: 0.65 },
    colors: PALETTE,
    disableForReducedMotion: true,
  });
}

export function levelUpStorm() {
  const end = Date.now() + 1400;
  (function frame() {
    confetti({
      particleCount: 5,
      angle: 60,
      spread: 60,
      startVelocity: 55,
      origin: { x: 0, y: 0.7 },
      colors: PALETTE,
      disableForReducedMotion: true,
    });
    confetti({
      particleCount: 5,
      angle: 120,
      spread: 60,
      startVelocity: 55,
      origin: { x: 1, y: 0.7 },
      colors: PALETTE,
      disableForReducedMotion: true,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}
