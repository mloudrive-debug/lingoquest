"use client";

let ctx: AudioContext | null = null;
let mutedCache: boolean | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function isMuted(): boolean {
  if (typeof window === "undefined") return false;
  if (mutedCache === null) {
    mutedCache = window.localStorage.getItem("lq-muted") === "1";
  }
  return mutedCache;
}

export function setMuted(v: boolean) {
  mutedCache = v;
  if (typeof window !== "undefined") {
    window.localStorage.setItem("lq-muted", v ? "1" : "0");
    window.dispatchEvent(new Event("lq-mute-changed"));
  }
}

function tone(freq: number, startAt: number, dur: number, type: OscillatorType = "sine", vol = 0.18) {
  const ac = getCtx();
  if (!ac || isMuted()) return;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  const t0 = ac.currentTime + startAt;
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(ac.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.05);
}

export type SoundName = "tap" | "correct" | "wrong" | "win" | "flip" | "levelup";

export function playSound(name: SoundName) {
  if (isMuted()) return;
  switch (name) {
    case "tap":
      tone(520, 0, 0.07, "triangle", 0.1);
      break;
    case "flip":
      tone(340, 0, 0.09, "triangle", 0.1);
      tone(560, 0.05, 0.08, "triangle", 0.08);
      break;
    case "correct":
      tone(660, 0, 0.12, "sine", 0.16);
      tone(880, 0.09, 0.16, "sine", 0.16);
      break;
    case "wrong":
      tone(200, 0, 0.16, "sawtooth", 0.1);
      tone(150, 0.08, 0.22, "sawtooth", 0.1);
      break;

    case "win":
      [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.18, "triangle", 0.15));
      break;
    case "levelup":
      [392, 523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, i * 0.08, 0.22, "triangle", 0.15));
      break;
  }
}

/** Pronounce an English word / sentence using the device speech engine. */
export function speak(text: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = 0.92;
    u.pitch = 1.05;
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find((v) => v.lang.startsWith("en-US") && v.localService) ??
      voices.find((v) => v.lang.startsWith("en"));
    if (voice) u.voice = voice;
    window.speechSynthesis.speak(u);
  } catch {
    /* speech not available */
  }
}
