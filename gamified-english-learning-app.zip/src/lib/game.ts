import { eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles, userBadges, wordProgress, words } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import type { InferSelectModel } from "drizzle-orm";

export type Profile = InferSelectModel<typeof profiles>;

/* ------------------------------------------------------------------ */
/* CEFR ladder (A1 → C2). Progress is continuous: 100 index points    */
/* per grade, 1 index point per 20 XP.                                 */
/* ------------------------------------------------------------------ */

export const CEFR_GRADES = ["A1", "A2", "B1", "B2", "C1", "C2"] as const;
export type CefrGrade = (typeof CEFR_GRADES)[number];

export const XP_PER_INDEX_POINT = 20;
export const CEFR_MAX_INDEX = 600;

export type CefrInfo = {
  index: number; // 0..599
  grade: CefrGrade;
  gradeIndex: number; // 0..5
  gradeProgress: number; // 0..1 inside current grade
  overallProgress: number; // 0..1 of the whole ladder
  nextGrade: CefrGrade | null;
  xpToNextGrade: number;
  isMax: boolean;
};

export function cefrInfo(xp: number): CefrInfo {
  const index = Math.min(CEFR_MAX_INDEX - 1, Math.floor(xp / XP_PER_INDEX_POINT));
  const gradeIndex = Math.min(5, Math.floor(index / 100));
  const grade = CEFR_GRADES[gradeIndex];
  const isMax = grade === "C2" && index >= 599;
  const nextGrade = isMax || gradeIndex >= 5 ? null : CEFR_GRADES[gradeIndex + 1];
  const xpToNextGrade = nextGrade ? (gradeIndex + 1) * 100 * XP_PER_INDEX_POINT - xp : 0;
  return {
    index,
    grade,
    gradeIndex,
    gradeProgress: (index - gradeIndex * 100) / 100,
    overallProgress: index / CEFR_MAX_INDEX,
    nextGrade,
    xpToNextGrade,
    isMax,
  };
}

/** Distance helper: 0 = same grade, -1 = one grade below, +1 = above… */
export function gradeDistance(cefr: string, currentGradeIndex: number): number {
  const i = CEFR_GRADES.indexOf(cefr as CefrGrade);
  return i === -1 ? 0 : i - currentGradeIndex;
}

/* ------------------------------------------------------------------ */
/* Game XP levels (arcade layer on top of the CEFR ladder)            */
/* ------------------------------------------------------------------ */

export function xpForLevel(level: number): number {
  return 80 + (level - 1) * 70;
}

export function levelFromXp(xp: number): {
  level: number;
  progress: number;
  remaining: number;
  nextLevelXp: number;
} {
  let level = 1;
  let remaining = xp;
  let need = xpForLevel(level);
  while (remaining >= need && level < 99) {
    remaining -= need;
    level += 1;
    need = xpForLevel(level);
  }
  return { level, progress: Math.min(1, remaining / need), remaining, nextLevelXp: need };
}

/* ------------------------------------------------------------------ */
/* Profile                                                            */
/* ------------------------------------------------------------------ */

export function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}

export function yesterdayStr(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}

/** Loads the single profile; applies lazy daily-XP reset. Unlimited play: no hearts. */
export async function getProfile(): Promise<Profile> {
  await ensureSeeded();
  const rows = await db.select().from(profiles).where(eq(profiles.id, 1)).limit(1);
  let profile = rows[0];

  if (profile.dailyXpDate !== todayStr()) {
    const [updated] = await db
      .update(profiles)
      .set({ dailyXp: 0, dailyXpDate: todayStr() })
      .where(eq(profiles.id, 1))
      .returning();
    profile = updated;
  }
  return profile;
}

/** Real mastery % per CEFR grade (based on actual word mastery, unseen = 0). */
export async function masteryByGrade(): Promise<Record<CefrGrade, number>> {
  const rows = await db
    .select({
      cefr: words.cefr,
      total: sql<number>`count(*)::int`,
      points: sql<number>`coalesce(sum(${wordProgress.mastery}), 0)::int`,
    })
    .from(words)
    .leftJoin(wordProgress, eq(wordProgress.wordId, words.id))
    .groupBy(words.cefr);

  const result = Object.fromEntries(CEFR_GRADES.map((g) => [g, 0])) as Record<CefrGrade, number>;
  for (const r of rows) {
    if (r.cefr in result && r.total > 0) {
      result[r.cefr as CefrGrade] = Math.min(1, r.points / (r.total * 5));
    }
  }
  return result;
}

/** Deterministic word of the day among beginner content. */
export async function wordOfTheDay() {
  await ensureSeeded();
  const candidates = await db.select().from(words).where(sql`${words.cefr} in ('A1','A2')`);
  if (candidates.length === 0) return null;
  const dayIndex = Math.floor(Date.now() / 86400000);
  return candidates[dayIndex % candidates.length];
}

/* ------------------------------------------------------------------ */
/* Badges                                                             */
/* ------------------------------------------------------------------ */

export type BadgeDef = {
  key: string;
  name: string;
  description: string;
  icon: string;
  color: string;
};

export const BADGES: BadgeDef[] = [
  { key: "first-session", name: "Premiers pas", description: "Terminer une première session", icon: "Rocket", color: "#8B7CFF" },
  { key: "perfect-session", name: "Sans faute", description: "Réussir une session à 100 %", icon: "Target", color: "#A3E635" },
  { key: "streak-3", name: "En rythme", description: "Jouer 3 jours d'affilée", icon: "Flame", color: "#FF9D5C" },
  { key: "streak-7", name: "Inarrêtable", description: "Jouer 7 jours d'affilée", icon: "Zap", color: "#FFC24B" },
  { key: "words-25", name: "Collectionneur", description: "Maîtriser 25 mots", icon: "BookOpen", color: "#5CD2FF" },
  { key: "words-50", name: "Bibliothèque vivante", description: "Maîtriser 50 mots", icon: "Library", color: "#FF5CA8" },
  { key: "grammar-30", name: "Grammairien", description: "30 bonnes réponses en grammaire", icon: "PenLine", color: "#7CF5C8" },
  { key: "bookworm-5", name: "Rat de bibliothèque", description: "Lire 5 histoires en entier", icon: "BookMarked", color: "#C9A7FF" },
  { key: "match-perfect", name: "Mémoire d'éléphant", description: "Un Memory parfait, sans erreur", icon: "Brain", color: "#FFD35C" },
  { key: "cefr-b1", name: "Autonome", description: "Atteindre le niveau B1", icon: "GraduationCap", color: "#7CF5C8" },
  { key: "cefr-c1", name: "Presque natif", description: "Atteindre le niveau C1", icon: "Crown", color: "#FFC24B" },
  { key: "level-10", name: "Niveau 10", description: "Atteindre le niveau 10 de jeu", icon: "Trophy", color: "#FF7C7C" },
];

/** Unlocks all badges whose conditions are met. Returns newly unlocked definitions. */
export async function unlockEligibleBadges(input: {
  perfect?: boolean;
  streak: number;
  mastered?: number;
  grammarCorrect?: number;
  textsRead?: number;
  perfectMatch?: boolean;
  level: number;
  grade: CefrGrade;
}): Promise<BadgeDef[]> {
  const have = new Set(
    (await db.select({ k: userBadges.badgeKey }).from(userBadges)).map((r) => r.k),
  );

  let mastered = input.mastered;
  if (mastered === undefined) {
    const [{ count }] = (await db
      .select({ count: sql<number>`count(*)::int` })
      .from(wordProgress)
      .where(gte(wordProgress.mastery, 4))) as { count: number }[];
    mastered = count;
  }

  const earned: string[] = [];
  const check = (key: string, cond: boolean) => {
    if (cond && !have.has(key)) earned.push(key);
  };

  const gi = CEFR_GRADES.indexOf(input.grade);
  check("first-session", true);
  check("perfect-session", !!input.perfect);
  check("streak-3", input.streak >= 3);
  check("streak-7", input.streak >= 7);
  check("words-25", mastered >= 25);
  check("words-50", mastered >= 50);
  check("grammar-30", (input.grammarCorrect ?? 0) >= 30);
  check("bookworm-5", (input.textsRead ?? 0) >= 5);
  check("match-perfect", !!input.perfectMatch);
  check("cefr-b1", gi >= 2);
  check("cefr-c1", gi >= 4);
  check("level-10", input.level >= 10);

  if (earned.length > 0) {
    await db.insert(userBadges).values(earned.map((badgeKey) => ({ badgeKey })));
  }
  return BADGES.filter((b) => earned.includes(b.key));
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
